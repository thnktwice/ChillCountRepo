(function(){MyTopics = new Mongo.Collection("mytopics");
MyTopic = Model(MyTopics);

})();
