(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['reywood:font-awesome-sass'] = {};

})();

//# sourceMappingURL=reywood_font-awesome-sass.js.map
