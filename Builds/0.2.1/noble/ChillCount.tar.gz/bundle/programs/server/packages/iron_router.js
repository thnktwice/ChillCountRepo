(function () {

/* Imports */
var _ = Package.underscore._;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var Blaze = Package.blaze.Blaze;
var UI = Package.blaze.UI;
var Handlebars = Package.blaze.Handlebars;
var Meteor = Package.meteor.Meteor;
var Iron = Package['iron:core'].Iron;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var Router, RouteController, CurrentOptions, HTTP_METHODS, Route;

(function () {

////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                            //
// packages/iron:router/lib/current_options.js                                                //
//                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                              //
/**                                                                                           // 1
 * Allows for dynamic scoping of options variables. Primarily intended to be                  // 2
 * used in the RouteController.prototype.lookupOption method.                                 // 3
 */                                                                                           // 4
CurrentOptions = new Meteor.EnvironmentVariable;                                              // 5
                                                                                              // 6
////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                            //
// packages/iron:router/lib/http_methods.js                                                   //
//                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                              //
HTTP_METHODS = [                                                                              // 1
  'get',                                                                                      // 2
  'post',                                                                                     // 3
  'put',                                                                                      // 4
  'delete',                                                                                   // 5
];                                                                                            // 6
                                                                                              // 7
////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                            //
// packages/iron:router/lib/route_controller.js                                               //
//                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                              //
/*****************************************************************************/               // 1
/* Imports */                                                                                 // 2
/*****************************************************************************/               // 3
var Controller = Iron.Controller;                                                             // 4
var Url = Iron.Url;                                                                           // 5
var MiddlewareStack = Iron.MiddlewareStack;                                                   // 6
                                                                                              // 7
/*****************************************************************************/               // 8
/* RouteController */                                                                         // 9
/*****************************************************************************/               // 10
RouteController = Controller.extend({                                                         // 11
  constructor: function (options) {                                                           // 12
    RouteController.__super__.constructor.apply(this, arguments);                             // 13
    options = options || {};                                                                  // 14
    this.options = options;                                                                   // 15
    this._onStopCallbacks = [];                                                               // 16
    this.route = options.route;                                                               // 17
                                                                                              // 18
    // Sometimes the data property can be defined on route options,                           // 19
    // or even on the global router config. And people will expect the                        // 20
    // data function to be available on the controller instance if it                         // 21
    // is defined anywhere in the chain. This ensure that if we have                          // 22
    // a data function somewhere in the chain, you can call this.data().                      // 23
    this.data = this.lookupOption('data');                                                    // 24
    if (this.data)                                                                            // 25
      this.data = _.bind(this.data, this);                                                    // 26
                                                                                              // 27
    this.init(options);                                                                       // 28
  }                                                                                           // 29
});                                                                                           // 30
                                                                                              // 31
/**                                                                                           // 32
 * Returns an option value following an "options chain" which is this path:                   // 33
 *                                                                                            // 34
 *   this (which includes the proto chain)                                                    // 35
 *   this.options                                                                             // 36
 *   this.route.options                                                                       // 37
 *   this.router.options                                                                      // 38
 */                                                                                           // 39
RouteController.prototype.lookupOption = function (key) {                                     // 40
                                                                                              // 41
  // this.options                                                                             // 42
  if (_.has(this.options, key))                                                               // 43
    return this.options[key];                                                                 // 44
                                                                                              // 45
  // "this" object or its proto chain                                                         // 46
  if (typeof this[key] !== 'undefined')                                                       // 47
    return this[key];                                                                         // 48
                                                                                              // 49
  // see if we have the CurrentOptions dynamic variable set.                                  // 50
  var opts = CurrentOptions.get();                                                            // 51
  if (opts && _.has(opts, key))                                                               // 52
    return opts[key];                                                                         // 53
                                                                                              // 54
  // this.route.options                                                                       // 55
  if (this.route && this.route.options && _.has(this.route.options, key))                     // 56
    return this.route.options[key];                                                           // 57
                                                                                              // 58
  // this.router.options                                                                      // 59
  if (this.router && this.router.options && _.has(this.router.options, key))                  // 60
    return this.router.options[key];                                                          // 61
};                                                                                            // 62
                                                                                              // 63
/**                                                                                           // 64
 * Returns an array of hook functions for the given hook names. Hooks are                     // 65
 * collected in this order:                                                                   // 66
 *                                                                                            // 67
 * router global hooks                                                                        // 68
 * route option hooks                                                                         // 69
 * prototype of the controller                                                                // 70
 * this object for the controller                                                             // 71
 *                                                                                            // 72
 * For example, this.collectHooks('onBeforeAction', 'before')                                 // 73
 * will return an array of hook functions where the key is either onBeforeAction              // 74
 * or before.                                                                                 // 75
 *                                                                                            // 76
 * Hook values can also be strings in which case they are looked up in the                    // 77
 * Iron.Router.hooks object.                                                                  // 78
 *                                                                                            // 79
 * TODO: Add an options last argument which can specify to only collect hooks                 // 80
 * for a particular environment (client, server or both).                                     // 81
 */                                                                                           // 82
RouteController.prototype._collectHooks = function (/* hook1, alias1, ... */) {               // 83
  var self = this;                                                                            // 84
  var hookNames = _.toArray(arguments);                                                       // 85
                                                                                              // 86
  var getHookValues = function (value) {                                                      // 87
    if (!value)                                                                               // 88
      return [];                                                                              // 89
    var lookupHook = self.router.lookupHook;                                                  // 90
    var hooks = _.isArray(value) ? value : [value];                                           // 91
    return _.map(hooks, function (h) { return lookupHook(h); });                              // 92
  };                                                                                          // 93
                                                                                              // 94
  var collectInheritedHooks = function (ctor, hookName) {                                     // 95
    var hooks = [];                                                                           // 96
                                                                                              // 97
    if (ctor.__super__)                                                                       // 98
      hooks = hooks.concat(collectInheritedHooks(ctor.__super__.constructor, hookName));      // 99
                                                                                              // 100
    return _.has(ctor.prototype, hookName) ?                                                  // 101
      hooks.concat(getHookValues(ctor.prototype[hookName])) : hooks;                          // 102
  };                                                                                          // 103
                                                                                              // 104
  var eachHook = function (cb) {                                                              // 105
    for (var i = 0; i < hookNames.length; i++) {                                              // 106
      cb(hookNames[i]);                                                                       // 107
    }                                                                                         // 108
  };                                                                                          // 109
                                                                                              // 110
  var routerHooks = [];                                                                       // 111
  eachHook(function (hook) {                                                                  // 112
    var name = self.route && self.route.getName();                                            // 113
    var hooks = self.router.getHooks(hook, name);                                             // 114
    routerHooks = routerHooks.concat(hooks);                                                  // 115
  });                                                                                         // 116
                                                                                              // 117
  var protoHooks = [];                                                                        // 118
  eachHook(function (hook) {                                                                  // 119
    var hooks = collectInheritedHooks(self.constructor, hook);                                // 120
    protoHooks = protoHooks.concat(hooks);                                                    // 121
  });                                                                                         // 122
                                                                                              // 123
  var thisHooks = [];                                                                         // 124
  eachHook(function (hook) {                                                                  // 125
    if (_.has(self, hook)) {                                                                  // 126
      var hooks = getHookValues(self[hook]);                                                  // 127
      thisHooks = thisHooks.concat(hooks);                                                    // 128
    }                                                                                         // 129
  });                                                                                         // 130
                                                                                              // 131
  var routeHooks = [];                                                                        // 132
  if (self.route) {                                                                           // 133
    eachHook(function (hook) {                                                                // 134
      var hooks = getHookValues(self.route.options[hook]);                                    // 135
      routeHooks = routeHooks.concat(hooks);                                                  // 136
    });                                                                                       // 137
  }                                                                                           // 138
                                                                                              // 139
  var allHooks = routerHooks                                                                  // 140
    .concat(routeHooks)                                                                       // 141
    .concat(protoHooks)                                                                       // 142
    .concat(thisHooks);                                                                       // 143
                                                                                              // 144
  return allHooks;                                                                            // 145
};                                                                                            // 146
                                                                                              // 147
RouteController.prototype.runHooks = function (/* hook, alias1, ...*/ ) {                     // 148
  var hooks = this._collectHooks.apply(this, arguments);                                      // 149
  for (var i = 0, l = hooks.length; i < l; i++) {                                             // 150
    var h = hooks[i];                                                                         // 151
    h.call(this);                                                                             // 152
  }                                                                                           // 153
};                                                                                            // 154
                                                                                              // 155
Iron.RouteController = RouteController;                                                       // 156
                                                                                              // 157
////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                            //
// packages/iron:router/lib/route_controller_server.js                                        //
//                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                              //
/*****************************************************************************/               // 1
/* Imports */                                                                                 // 2
/*****************************************************************************/               // 3
var Fiber = Npm.require('fibers');                                                            // 4
var Controller = Iron.Controller;                                                             // 5
var Url = Iron.Url;                                                                           // 6
var MiddlewareStack = Iron.MiddlewareStack;                                                   // 7
                                                                                              // 8
/*****************************************************************************/               // 9
/* RouteController */                                                                         // 10
/*****************************************************************************/               // 11
                                                                                              // 12
/**                                                                                           // 13
 * Server specific initialization.                                                            // 14
 */                                                                                           // 15
RouteController.prototype.init = function (options) {};                                       // 16
                                                                                              // 17
/**                                                                                           // 18
 * Let this controller run a dispatch process. This function will be called                   // 19
 * from the router. That way, any state associated with the dispatch can go on                // 20
 * the controller instance. Note: no result returned from dispatch because its                // 21
 * run inside its own fiber. Might at some point move the fiber stuff to a                    // 22
 * higher layer.                                                                              // 23
 */                                                                                           // 24
RouteController.prototype.dispatch = function (stack, url, done) {                            // 25
  var self = this;                                                                            // 26
  Fiber(function () {                                                                         // 27
    stack.dispatch(url, self, done);                                                          // 28
  }).run();                                                                                   // 29
};                                                                                            // 30
                                                                                              // 31
/**                                                                                           // 32
 * Run a route on the server. When the router runs its middleware stack, it                   // 33
 * can run regular middleware functions or it can run a route. There should                   // 34
 * only one route object per path as where there may be many middleware                       // 35
 * functions.                                                                                 // 36
 *                                                                                            // 37
 * For example:                                                                               // 38
 *                                                                                            // 39
 *   "/some/path" => [middleware1, middleware2, route, middleware3]                           // 40
 *                                                                                            // 41
 * When a route is dispatched, it tells the controller to _runRoute so that                   // 42
 * the controller can control the process. At this point we should already be                 // 43
 * in a dispatch so a computation should already exist.                                       // 44
 */                                                                                           // 45
RouteController.prototype._runRoute = function (route, url, done) {                           // 46
  var self = this;                                                                            // 47
                                                                                              // 48
  this.runHooks('onRun', 'load');                                                             // 49
                                                                                              // 50
  // dispatch into the "before" hook stack and the "action" stack making sure                 // 51
  // the before stack comes first. this lets a before hook stop downstream                    // 52
  // handlers by not calling this.next().                                                     // 53
  var actionStack = new MiddlewareStack;                                                      // 54
  var beforeHooks = this._collectHooks('onBeforeAction', 'before');                           // 55
  actionStack.append(beforeHooks, {where: 'server'});                                         // 56
                                                                                              // 57
  // make sure the action stack has at least one handler on it that defaults                  // 58
  // to the 'action' method                                                                   // 59
  if (route._actionStack.length === 0) {                                                      // 60
    route._actionStack.push(route.path, 'action', route.options);                             // 61
  }                                                                                           // 62
                                                                                              // 63
  //XXX try dispatching inside a fiber in case we do something                                // 64
  //async?                                                                                    // 65
  actionStack = actionStack.concat(route._actionStack);                                       // 66
  actionStack.dispatch(url, this, done);                                                      // 67
                                                                                              // 68
  // run the after hook.                                                                      // 69
  this.next = function () {};                                                                 // 70
  this.runHooks('onAfterAction', 'after');                                                    // 71
};                                                                                            // 72
                                                                                              // 73
////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                            //
// packages/iron:router/lib/route.js                                                          //
//                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                              //
var Url = Iron.Url;                                                                           // 1
var MiddlewareStack = Iron.MiddlewareStack;                                                   // 2
var assert = Iron.utils.assert;                                                               // 3
                                                                                              // 4
/*****************************************************************************/               // 5
/* Both */                                                                                    // 6
/*****************************************************************************/               // 7
Route = function (path, fn, options) {                                                        // 8
  var route = function (req, res, next) {                                                     // 9
    var controller = this;                                                                    // 10
    controller.request = req;                                                                 // 11
    controller.response = res;                                                                // 12
    route.dispatch(req.url, controller, next);                                                // 13
  }                                                                                           // 14
                                                                                              // 15
  if (typeof fn === 'object') {                                                               // 16
    options = fn;                                                                             // 17
    fn = options.action;                                                                      // 18
  }                                                                                           // 19
                                                                                              // 20
  options = options || {};                                                                    // 21
                                                                                              // 22
  assert(typeof path === 'string',                                                            // 23
    "First parameter to Router.route must be a string.");                                     // 24
                                                                                              // 25
  if (path.charAt(0) !== '/') {                                                               // 26
    path = options.path ? options.path : '/' + path                                           // 27
  }                                                                                           // 28
                                                                                              // 29
  // extend the route function with properties from this instance and its                     // 30
  // prototype.                                                                               // 31
  _.extend(route, this);                                                                      // 32
                                                                                              // 33
  // always good to have options                                                              // 34
  options = route.options = options || {};                                                    // 35
                                                                                              // 36
  // the main action function as well as any HTTP VERB action functions will go               // 37
  // onto this stack.                                                                         // 38
  route._actionStack = new MiddlewareStack;                                                   // 39
                                                                                              // 40
  // any before hooks will go onto this stack to make sure they get executed                  // 41
  // before the action stack.                                                                 // 42
  route._beforeStack = new MiddlewareStack;                                                   // 43
  route._beforeStack.append(route.options.onBeforeAction);                                    // 44
  route._beforeStack.append(route.options.before);                                            // 45
                                                                                              // 46
  // after hooks get run after the action stack                                               // 47
  route._afterStack = new MiddlewareStack;                                                    // 48
  route._afterStack.append(route.options.onAfterAction);                                      // 49
  route._afterStack.append(route.options.after);                                              // 50
                                                                                              // 51
  route._path = Url.normalize(path);                                                          // 52
                                                                                              // 53
  // track which methods this route uses                                                      // 54
  route._methods = {};                                                                        // 55
                                                                                              // 56
  if (typeof fn === 'string') {                                                               // 57
    route._actionStack.push(route._path, _.extend(options, {                                  // 58
      template: fn                                                                            // 59
    }));                                                                                      // 60
  } else if (typeof fn === 'function' || typeof fn === 'object') {                            // 61
    route._actionStack.push(route._path, fn, options);                                        // 62
  }                                                                                           // 63
                                                                                              // 64
  return route;                                                                               // 65
};                                                                                            // 66
                                                                                              // 67
/**                                                                                           // 68
 * The name of the route is actually stored on the handler since a route is a                 // 69
 * function that has an unassignable "name" property.                                         // 70
 */                                                                                           // 71
Route.prototype.getName = function () {                                                       // 72
  return this.handler && this.handler.name;                                                   // 73
};                                                                                            // 74
                                                                                              // 75
/**                                                                                           // 76
 * Returns an appropriate RouteController constructor the this Route.                         // 77
 *                                                                                            // 78
 * There are three possibilities:                                                             // 79
 *                                                                                            // 80
 *  1. controller option provided as a string on the route                                    // 81
 *  2. a controller in the global namespace with the converted name of the route              // 82
 *  3. a default RouteController                                                              // 83
 *                                                                                            // 84
 */                                                                                           // 85
Route.prototype.findControllerConstructor = function () {                                     // 86
  var self = this;                                                                            // 87
                                                                                              // 88
  var resolve = function (name, opts) {                                                       // 89
    opts = opts || {};                                                                        // 90
    var C = Iron.utils.resolve(name);                                                         // 91
    if (!C || !RouteController.prototype.isPrototypeOf(C.prototype)) {                        // 92
      if (opts.supressErrors !== true)                                                        // 93
        throw new Error("RouteController '" + name + "' is not defined.");                    // 94
      else                                                                                    // 95
        return undefined;                                                                     // 96
    } else {                                                                                  // 97
      return C;                                                                               // 98
    }                                                                                         // 99
  };                                                                                          // 100
                                                                                              // 101
  var convert = function (name) {                                                             // 102
    return self.router.toControllerName(name);                                                // 103
  };                                                                                          // 104
                                                                                              // 105
  var result;                                                                                 // 106
  var name = this.getName();                                                                  // 107
                                                                                              // 108
  // the controller was set directly                                                          // 109
  if (typeof this.options.controller === 'object')                                            // 110
    return this.options.controller;                                                           // 111
                                                                                              // 112
  // was the controller specified precisely by name? then resolve to an actual                // 113
  // javascript constructor value                                                             // 114
  else if (typeof this.options.controller === 'string')                                       // 115
    return resolve(this.options.controller);                                                  // 116
                                                                                              // 117
  // otherwise do we have a name? try to convert the name to a controller name                // 118
  // and resolve it to a value                                                                // 119
  else if (name && (result = resolve(convert(name), {supressErrors: true})))                  // 120
    return result;                                                                            // 121
                                                                                              // 122
  // otherwise just use an anonymous route controller                                         // 123
  else                                                                                        // 124
    return RouteController;                                                                   // 125
};                                                                                            // 126
                                                                                              // 127
                                                                                              // 128
/**                                                                                           // 129
 * Create a new controller for the route.                                                     // 130
 */                                                                                           // 131
Route.prototype.createController = function (options) {                                       // 132
  options = options || {};                                                                    // 133
  var C = this.findControllerConstructor();                                                   // 134
  options.route = this;                                                                       // 135
  var instance = new C(options);                                                              // 136
  return instance;                                                                            // 137
};                                                                                            // 138
                                                                                              // 139
/**                                                                                           // 140
 * Dispatch into the route's middleware stack.                                                // 141
 */                                                                                           // 142
Route.prototype.dispatch = function (url, context, done) {                                    // 143
  // call runRoute on the controller which will behave similarly to the previous              // 144
  // version of IR.                                                                           // 145
  assert(context._runRoute, "context doesn't have a _runRoute method");                       // 146
  return context._runRoute(this, url, done);                                                  // 147
};                                                                                            // 148
                                                                                              // 149
/**                                                                                           // 150
 * Returns a relative path for the route.                                                     // 151
 */                                                                                           // 152
Route.prototype.path = function (params, options) {                                           // 153
  return this.handler.resolve(params, options);                                               // 154
};                                                                                            // 155
                                                                                              // 156
/**                                                                                           // 157
 * Return a fully qualified url for the route, given a set of parmeters and                   // 158
 * options like hash and query.                                                               // 159
 */                                                                                           // 160
Route.prototype.url = function (params, options) {                                            // 161
  var path = this.path(params, options);                                                      // 162
  var host = (options && options.host) || Meteor.absoluteUrl();                               // 163
                                                                                              // 164
  if (host.charAt(host.length-1) === '/');                                                    // 165
    host = host.slice(0, host.length-1);                                                      // 166
  return host + path;                                                                         // 167
};                                                                                            // 168
                                                                                              // 169
/**                                                                                           // 170
 * Return a params object for the route given a path.                                         // 171
 */                                                                                           // 172
Route.prototype.params = function (path) {                                                    // 173
  return this.handler.params(path);                                                           // 174
};                                                                                            // 175
                                                                                              // 176
/**                                                                                           // 177
 * Add convenience methods for each HTTP verb.                                                // 178
 *                                                                                            // 179
 * Example:                                                                                   // 180
 *  var route = router.route('/item')                                                         // 181
 *    .get(function () { })                                                                   // 182
 *    .post(function () { })                                                                  // 183
 *    .put(function () { })                                                                   // 184
 */                                                                                           // 185
HTTP_METHODS.forEach(function (method) {                                                      // 186
  Route.prototype[method] = function (fn) {                                                   // 187
    // track the method being used for OPTIONS requests.                                      // 188
    this._methods[method] = true;                                                             // 189
                                                                                              // 190
    this._actionStack.push(this._path, fn, {                                                  // 191
      // give each method a unique name so it doesn't clash with the route's                  // 192
      // name in the action stack                                                             // 193
      name: this.getName() + '_' + method.toLowerCase(),                                      // 194
      method: method,                                                                         // 195
                                                                                              // 196
      // for now just make the handler where the same as the route, presumably a              // 197
      // server route.                                                                        // 198
      where: this.handler.where,                                                              // 199
      mount: false                                                                            // 200
    });                                                                                       // 201
                                                                                              // 202
    return this;                                                                              // 203
  };                                                                                          // 204
});                                                                                           // 205
                                                                                              // 206
Iron.Route = Route;                                                                           // 207
                                                                                              // 208
////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                            //
// packages/iron:router/lib/router.js                                                         //
//                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                              //
/*****************************************************************************/               // 1
/* Imports */                                                                                 // 2
/*****************************************************************************/               // 3
var MiddlewareStack = Iron.MiddlewareStack;                                                   // 4
var Url = Iron.Url;                                                                           // 5
var Layout = Iron.Layout;                                                                     // 6
var warn = Iron.utils.warn;                                                                   // 7
var assert = Iron.utils.assert;                                                               // 8
                                                                                              // 9
Router = function (options) {                                                                 // 10
  // keep the same api throughout which is:                                                   // 11
  // fn(url, context, done);                                                                  // 12
  function router (req, res, next) {                                                          // 13
    //XXX this assumes no other routers on the parent stack which we should probably fix      // 14
    router.dispatch(req.url, {                                                                // 15
      request: req,                                                                           // 16
      response: res                                                                           // 17
    }, next);                                                                                 // 18
  }                                                                                           // 19
                                                                                              // 20
  // the main router stack                                                                    // 21
  router._stack = new MiddlewareStack;                                                        // 22
                                                                                              // 23
  // for storing global hooks like before, after, etc.                                        // 24
  router._globalHooks = {};                                                                   // 25
                                                                                              // 26
  // backward compat and quicker lookup of Route handlers vs. regular function                // 27
  // handlers.                                                                                // 28
  router.routes = [];                                                                         // 29
                                                                                              // 30
  // to make sure we don't have more than one route per path                                  // 31
  router.routes._byPath = {};                                                                 // 32
                                                                                              // 33
  // always good to have options                                                              // 34
  this.configure.call(router, options);                                                       // 35
                                                                                              // 36
  // add proto properties to the router function                                              // 37
  _.extend(router, this);                                                                     // 38
                                                                                              // 39
  // let client and server side routing doing different things here                           // 40
  this.init.call(router, options);                                                            // 41
                                                                                              // 42
  Meteor.startup(function () {                                                                // 43
    Meteor.defer(function () {                                                                // 44
      if (router.options.autoStart !== false)                                                 // 45
        router.start();                                                                       // 46
    });                                                                                       // 47
  });                                                                                         // 48
                                                                                              // 49
  return router;                                                                              // 50
};                                                                                            // 51
                                                                                              // 52
Router.prototype.init = function (options) {};                                                // 53
                                                                                              // 54
Router.prototype.configure = function (options) {                                             // 55
  var self = this;                                                                            // 56
                                                                                              // 57
  options = options || {};                                                                    // 58
                                                                                              // 59
  var toArray = function (value) {                                                            // 60
    if (!value)                                                                               // 61
      return [];                                                                              // 62
                                                                                              // 63
    if (_.isArray(value))                                                                     // 64
      return value;                                                                           // 65
                                                                                              // 66
    return [value];                                                                           // 67
  };                                                                                          // 68
                                                                                              // 69
  // e.g. before: fn OR before: [fn1, fn2]                                                    // 70
  _.each(Iron.Router.HOOK_TYPES, function eachHookType (type) {                               // 71
    if (options[type]) {                                                                      // 72
      _.each(toArray(options[type]), function eachHook (hook) {                               // 73
        self.addHook(type, hook);                                                             // 74
      });                                                                                     // 75
                                                                                              // 76
      delete options[type];                                                                   // 77
    }                                                                                         // 78
  });                                                                                         // 79
                                                                                              // 80
  this.options = this.options || {};                                                          // 81
  _.extend(this.options, options);                                                            // 82
                                                                                              // 83
  return this;                                                                                // 84
};                                                                                            // 85
                                                                                              // 86
/**                                                                                           // 87
 * Just to support legacy calling. Doesn't really serve much purpose.                         // 88
 */                                                                                           // 89
Router.prototype.map = function (fn) {                                                        // 90
  return fn.call(this);                                                                       // 91
};                                                                                            // 92
                                                                                              // 93
Router.prototype.use = function (path, fn, opts) {                                            // 94
  if (typeof path === 'function') {                                                           // 95
    opts = fn || {};                                                                          // 96
    opts.mount = true;                                                                        // 97
    opts.where = opts.where || 'server';                                                      // 98
    this._stack.push(path, opts);                                                             // 99
  } else {                                                                                    // 100
    opts = opts || {};                                                                        // 101
    opts.mount = true;                                                                        // 102
    opts.where = opts.where || 'server';                                                      // 103
    this._stack.push(path, fn, opts);                                                         // 104
  }                                                                                           // 105
                                                                                              // 106
  return this;                                                                                // 107
};                                                                                            // 108
                                                                                              // 109
Router.prototype.route = function (path, fn, opts) {                                          // 110
  var typeOf = function (val) { return Object.prototype.toString.call(val); };                // 111
  assert(typeOf(path) === '[object String]' || typeOf(path) === '[object RegExp]', "Router.route requires a path that is a string or regular expression.");
                                                                                              // 113
  if (typeof fn === 'object') {                                                               // 114
    opts = fn;                                                                                // 115
    fn = opts.action;                                                                         // 116
  }                                                                                           // 117
                                                                                              // 118
  var route = new Route(path, fn, opts);                                                      // 119
                                                                                              // 120
  opts = opts || {};                                                                          // 121
                                                                                              // 122
  // don't mount the route                                                                    // 123
  opts.mount = false;                                                                         // 124
                                                                                              // 125
  // stack expects a function which is exactly what a new Route returns!                      // 126
  var handler = this._stack.push(path, route, opts);                                          // 127
                                                                                              // 128
  handler.route = route;                                                                      // 129
  route.handler = handler;                                                                    // 130
  route.router = this;                                                                        // 131
                                                                                              // 132
  assert(!this.routes._byPath[handler.path],                                                  // 133
    "A route for the path " + JSON.stringify(handler.path) + " already exists by the name of " + JSON.stringify(handler.name) + ".");
  this.routes._byPath[handler.path] = route;                                                  // 135
                                                                                              // 136
  this.routes.push(route);                                                                    // 137
                                                                                              // 138
  if (typeof handler.name === 'string')                                                       // 139
    this.routes[handler.name] = route;                                                        // 140
                                                                                              // 141
  return route;                                                                               // 142
};                                                                                            // 143
                                                                                              // 144
/**                                                                                           // 145
 * Find the first route for the given url and options.                                        // 146
 */                                                                                           // 147
Router.prototype.findFirstRoute = function (url) {                                            // 148
  for (var i = 0; i < this.routes.length; i++) {                                              // 149
    if (this.routes[i].handler.test(url, {}))                                                 // 150
      return this.routes[i];                                                                  // 151
  }                                                                                           // 152
                                                                                              // 153
  return null;                                                                                // 154
};                                                                                            // 155
                                                                                              // 156
Router.prototype.path = function (routeName, params, options) {                               // 157
  var route = this.routes[routeName];                                                         // 158
  warn(route, "You called Router.path for a route named " + JSON.stringify(routeName) + " but that route doesn't seem to exist. Are you sure you created it?");
  return route && route.path(params, options);                                                // 160
};                                                                                            // 161
                                                                                              // 162
Router.prototype.url = function (routeName, params, options) {                                // 163
  var route = this.routes[routeName];                                                         // 164
  warn(route, "You called Router.url for a route named " + JSON.stringify(routeName) + " but that route doesn't seem to exist. Are you sure you created it?");
  return route && route.url(params, options);                                                 // 166
};                                                                                            // 167
                                                                                              // 168
/**                                                                                           // 169
 * Create a new controller for a dispatch.                                                    // 170
 */                                                                                           // 171
Router.prototype.createController = function (url, context) {                                 // 172
  // see if there's a route for this url                                                      // 173
  var route = this.findFirstRoute(url);                                                       // 174
  var controller;                                                                             // 175
                                                                                              // 176
  context = context || {};                                                                    // 177
                                                                                              // 178
  if (route)                                                                                  // 179
    // let the route decide what controller to use                                            // 180
    controller = route.createController({layout: this._layout});                              // 181
  else                                                                                        // 182
    // create an anonymous controller                                                         // 183
    controller = new RouteController({layout: this._layout});                                 // 184
                                                                                              // 185
  controller.router = this;                                                                   // 186
  controller.request = context.request;                                                       // 187
  controller.response = context.response;                                                     // 188
  controller.url = context.url || url;                                                        // 189
  controller.originalUrl = context.originalUrl || url;                                        // 190
  controller.method = context.request && context.request.method;                              // 191
                                                                                              // 192
  return controller;                                                                          // 193
};                                                                                            // 194
                                                                                              // 195
Router.prototype.setTemplateNameConverter = function (fn) {                                   // 196
  this._templateNameConverter = fn;                                                           // 197
  return this;                                                                                // 198
};                                                                                            // 199
                                                                                              // 200
Router.prototype.setControllerNameConverter = function (fn) {                                 // 201
  this._controllerNameConverter = fn;                                                         // 202
  return this;                                                                                // 203
};                                                                                            // 204
                                                                                              // 205
Router.prototype.toTemplateName = function (str) {                                            // 206
  if (this._templateNameConverter)                                                            // 207
    return this._templateNameConverter(str);                                                  // 208
  else                                                                                        // 209
    return Iron.utils.classCase(str);                                                         // 210
};                                                                                            // 211
                                                                                              // 212
Router.prototype.toControllerName = function (str) {                                          // 213
  if (this._controllerNameConverter)                                                          // 214
    return this._controllerNameConverter(str);                                                // 215
  else                                                                                        // 216
    return Iron.utils.classCase(str) + 'Controller';                                          // 217
};                                                                                            // 218
                                                                                              // 219
/**                                                                                           // 220
 *                                                                                            // 221
 * Add a hook to all routes. The hooks will apply to all routes,                              // 222
 * unless you name routes to include or exclude via `only` and `except` options               // 223
 *                                                                                            // 224
 * @param {String} [type] one of 'load', 'unload', 'before' or 'after'                        // 225
 * @param {Object} [options] Options to controll the hooks [optional]                         // 226
 * @param {Function} [hook] Callback to run                                                   // 227
 * @return {IronRouter}                                                                       // 228
 * @api public                                                                                // 229
 *                                                                                            // 230
 */                                                                                           // 231
                                                                                              // 232
Router.prototype.addHook = function(type, hook, options) {                                    // 233
  var self = this;                                                                            // 234
                                                                                              // 235
  options = options || {};                                                                    // 236
                                                                                              // 237
  var toArray = function (input) {                                                            // 238
    if (!input)                                                                               // 239
      return [];                                                                              // 240
    else if (_.isArray(input))                                                                // 241
      return input;                                                                           // 242
    else                                                                                      // 243
      return [input];                                                                         // 244
  }                                                                                           // 245
                                                                                              // 246
  if (options.only)                                                                           // 247
    options.only = toArray(options.only);                                                     // 248
  if (options.except)                                                                         // 249
    options.except = toArray(options.except);                                                 // 250
                                                                                              // 251
  var hooks = this._globalHooks[type] = this._globalHooks[type] || [];                        // 252
                                                                                              // 253
  var hookWithOptions = function () {                                                         // 254
    var thisArg = this;                                                                       // 255
    // this allows us to bind hooks to options that get looked up when you call               // 256
    // this.lookupOption from within the hook. And it looks better to keep                    // 257
    // plugin/hook related options close to their definitions instead of                      // 258
    // Router.configure. But we use a dynamic variable so we don't have to                    // 259
    // pass the options explicitly as an argument and plugin creators can                     // 260
    // just use this.lookupOption which will follow the proper lookup chain from              // 261
    // "this", local options, dynamic variable options, route, router, etc.                   // 262
    return CurrentOptions.withValue(options, function () {                                    // 263
      return self.lookupHook(hook).apply(thisArg, arguments);                                 // 264
    });                                                                                       // 265
  };                                                                                          // 266
                                                                                              // 267
  hooks.push({options: options, hook: hookWithOptions});                                      // 268
  return this;                                                                                // 269
};                                                                                            // 270
                                                                                              // 271
/**                                                                                           // 272
 * If the argument is a function return it directly. If it's a string, see if                 // 273
 * there is a function in the Iron.Router.hooks namespace. Throw an error if we               // 274
 * can't find the hook.                                                                       // 275
 */                                                                                           // 276
Router.prototype.lookupHook = function (nameOrFn) {                                           // 277
  var fn = nameOrFn;                                                                          // 278
                                                                                              // 279
  // if we already have a func just return it                                                 // 280
  if (_.isFunction(fn))                                                                       // 281
    return fn;                                                                                // 282
                                                                                              // 283
  // look up one of the out-of-box hooks like                                                 // 284
  // 'loaded or 'dataNotFound' if the nameOrFn is a                                           // 285
  // string                                                                                   // 286
  if (_.isString(fn)) {                                                                       // 287
    if (_.isFunction(Iron.Router.hooks[fn]))                                                  // 288
      return Iron.Router.hooks[fn];                                                           // 289
  }                                                                                           // 290
                                                                                              // 291
  // we couldn't find it so throw an error                                                    // 292
  throw new Error("No hook found named: ", nameOrFn);                                         // 293
};                                                                                            // 294
                                                                                              // 295
/**                                                                                           // 296
 *                                                                                            // 297
 * Fetch the list of global hooks that apply to the given route name.                         // 298
 * Hooks are defined by the .addHook() function above.                                        // 299
 *                                                                                            // 300
 * @param {String} [type] one of IronRouter.HOOK_TYPES                                        // 301
 * @param {String} [name] the name of the route we are interested in                          // 302
 * @return {[Function]} [hooks] an array of hooks to run                                      // 303
 * @api public                                                                                // 304
 *                                                                                            // 305
 */                                                                                           // 306
                                                                                              // 307
Router.prototype.getHooks = function(type, name) {                                            // 308
  var self = this;                                                                            // 309
  var hooks = [];                                                                             // 310
                                                                                              // 311
  _.each(this._globalHooks[type], function(hook) {                                            // 312
    var options = hook.options;                                                               // 313
                                                                                              // 314
    if (options.except && _.include(options.except, name))                                    // 315
      return [];                                                                              // 316
                                                                                              // 317
    if (options.only && ! _.include(options.only, name))                                      // 318
      return [];                                                                              // 319
                                                                                              // 320
    hooks.push(hook.hook);                                                                    // 321
  });                                                                                         // 322
                                                                                              // 323
  return hooks;                                                                               // 324
};                                                                                            // 325
                                                                                              // 326
Router.HOOK_TYPES = [                                                                         // 327
  'onRun',                                                                                    // 328
  'onRerun',                                                                                  // 329
  'onBeforeAction',                                                                           // 330
  'onAfterAction',                                                                            // 331
  'onStop',                                                                                   // 332
                                                                                              // 333
  // not technically a hook but we'll use it                                                  // 334
  // in a similar way. This will cause waitOn                                                 // 335
  // to be added as a method to the Router and then                                           // 336
  // it can be selectively applied to specific routes                                         // 337
  'waitOn',                                                                                   // 338
                                                                                              // 339
  // legacy hook types but we'll let them slide                                               // 340
  'load', // onRun                                                                            // 341
  'before', // onBeforeAction                                                                 // 342
  'after', // onAfterAction                                                                   // 343
  'unload' // onStop                                                                          // 344
];                                                                                            // 345
                                                                                              // 346
/**                                                                                           // 347
 * A namespace for hooks keyed by name.                                                       // 348
 */                                                                                           // 349
Router.hooks = {};                                                                            // 350
                                                                                              // 351
                                                                                              // 352
/**                                                                                           // 353
 * A namespace for plugin functions keyed by name.                                            // 354
 */                                                                                           // 355
Router.plugins = {};                                                                          // 356
                                                                                              // 357
/**                                                                                           // 358
 * Auto add helper mtehods for all the hooks.                                                 // 359
 */                                                                                           // 360
                                                                                              // 361
Router.HOOK_TYPES.forEach(function (type) {                                                   // 362
  Router.prototype[type] = function (hook, options) {                                         // 363
    this.addHook(type, hook, options);                                                        // 364
  };                                                                                          // 365
});                                                                                           // 366
                                                                                              // 367
/**                                                                                           // 368
 * Add a plugin to the router instance.                                                       // 369
 */                                                                                           // 370
Router.prototype.plugin = function (nameOrFn, options) {                                      // 371
  var func;                                                                                   // 372
                                                                                              // 373
  if (typeof nameOrFn === 'function')                                                         // 374
    func = nameOrFn;                                                                          // 375
  else if (typeof nameOrFn === 'string')                                                      // 376
    func = Iron.Router.plugins[nameOrFn];                                                     // 377
                                                                                              // 378
  if (!func)                                                                                  // 379
    throw new Error("No plugin found named " + JSON.stringify(nameOrFn));                     // 380
                                                                                              // 381
  // fn(router, options)                                                                      // 382
  func.call(this, this, options);                                                             // 383
                                                                                              // 384
  return this;                                                                                // 385
};                                                                                            // 386
                                                                                              // 387
Iron.Router = Router;                                                                         // 388
                                                                                              // 389
////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                            //
// packages/iron:router/lib/router_server.js                                                  //
//                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                              //
var assert = Iron.utils.assert;                                                               // 1
                                                                                              // 2
var env = process.env.NODE_ENV || 'development';                                              // 3
                                                                                              // 4
/**                                                                                           // 5
 * Server specific initialization.                                                            // 6
 */                                                                                           // 7
Router.prototype.init = function (options) {};                                                // 8
                                                                                              // 9
/**                                                                                           // 10
 * Add the router to the server connect handlers.                                             // 11
 */                                                                                           // 12
Router.prototype.start = function () {                                                        // 13
  WebApp.connectHandlers.use(this);                                                           // 14
};                                                                                            // 15
                                                                                              // 16
/**                                                                                           // 17
 * Create a new controller and dispatch into the stack.                                       // 18
 */                                                                                           // 19
Router.prototype.dispatch = function (url, context, done) {                                   // 20
  var self = this;                                                                            // 21
                                                                                              // 22
  assert(typeof url === 'string', "expected url string in router dispatch");                  // 23
  assert(typeof context === 'object', "expected context object in router dispatch");          // 24
                                                                                              // 25
  if (this._stack.length === 0) {                                                             // 26
    var res = context.response;                                                               // 27
    var msg = " \
    <div style='font-family: helvetica; color: #777; max-width: 600px; margin: 20px auto;'> \
      <h1 style='text-align: center; margin: 0; font-size: 48pt;'> \
        iron:router \
      </h1> \
      <p style='text-align: center; font-size: 1.3em;'> \
        Organize your Meteor application. \
      </p> \
      <div style='margin: 50px 0px;'> \
        <pre style='background: #f2f2f2; margin: 0; padding: 10px;'>\
Router.route('/', function () {\n\
  this.render('Home', {\n\
    data: function () { return Items.findOne({_id: this.params._id}) }\n\
  });\n\
});\n\
        </pre>\
      </div> \
      <div style='margin: 50px 0px;'>\
        Check it out on Github:<br>\
        <a href='https://github.com/eventedmind/iron-router' target='_blank'>https://github.com/eventedmind/iron-router</a>\
        <br>\
        <br>\
        And check out the new Guide:<br>\
        <a href='https://eventedmind.github.io/iron-router' target='_blank'>\
          https://eventedmind.github.io/iron-router\
        </a>\
      </div>\
    </div> \
    ";                                                                                        // 56
                                                                                              // 57
    res.setHeader('Content-Type', 'text/html');                                               // 58
    res.end(msg + '\n');                                                                      // 59
    return;                                                                                   // 60
  }                                                                                           // 61
                                                                                              // 62
  // assumes there is only one router                                                         // 63
  // XXX need to initialize controller either from the context itself or if the               // 64
  // context already has a controller on it, just use that one.                               // 65
  var controller = this.createController(url, context);                                       // 66
                                                                                              // 67
  controller.dispatch(this._stack, url, function (err) {                                      // 68
    var res = this.response;                                                                  // 69
    var req = this.request;                                                                   // 70
    var msg;                                                                                  // 71
                                                                                              // 72
    if (err) {                                                                                // 73
      if (res.statusCode < 400)                                                               // 74
        res.statusCode = 500;                                                                 // 75
                                                                                              // 76
      if (err.status)                                                                         // 77
        res.statusCode = err.status;                                                          // 78
                                                                                              // 79
      if (env === 'development')                                                              // 80
        msg = (err.stack || err.toString()) + '\n';                                           // 81
      else                                                                                    // 82
        //XXX get this from standard dict of error messages?                                  // 83
        msg = 'Server error.';                                                                // 84
                                                                                              // 85
      console.error(err.stack || err.toString());                                             // 86
                                                                                              // 87
      if (res.headersSent)                                                                    // 88
        return req.socket.destroy();                                                          // 89
                                                                                              // 90
      res.setHeader('Content-Type', 'text/html');                                             // 91
      res.setHeader('Content-Length', Buffer.byteLength(msg));                                // 92
      if (req.method === 'HEAD')                                                              // 93
        return res.end();                                                                     // 94
      res.end(msg);                                                                           // 95
      return;                                                                                 // 96
    }                                                                                         // 97
                                                                                              // 98
    // if there are no client or server handlers for this dispatch                            // 99
    // then send a 404.                                                                       // 100
    // XXX we need a solution here for 404s on bad routes.                                    // 101
    //     one solution might be to provide a custom 404 page in the public                   // 102
    //     folder. But we need a proper way to handle 404s for search engines.                // 103
    // XXX might be a PR to Meteor to use an existing status code if it's set                 // 104
    if (!controller.isHandled() && !controller.willBeHandledOnClient()) {                     // 105
      return done();                                                                          // 106
      /*                                                                                      // 107
      res.statusCode = 404;                                                                   // 108
      res.setHeader('Content-Type', 'text/html');                                             // 109
      msg = req.method + ' ' + req.originalUrl + ' not found.';                               // 110
      console.error(msg);                                                                     // 111
      if (req.method == 'HEAD')                                                               // 112
        return res.end();                                                                     // 113
      res.end(msg + '\n');                                                                    // 114
      return;                                                                                 // 115
      */                                                                                      // 116
    }                                                                                         // 117
                                                                                              // 118
    // if for some reason there was a server handler but no client handler                    // 119
    // and the server handler called next() we might end up here. We                          // 120
    // want to make sure to end the response so it doesn't hang.                              // 121
    if (controller.isHandled() && !controller.willBeHandledOnClient()) {                      // 122
      res.setHeader('Content-Type', 'text/html');                                             // 123
      if (req.method === 'HEAD')                                                              // 124
        res.end();                                                                            // 125
      res.end("<p>It looks like you don't have any client routes defined, but you had at least one server handler. You probably want to define some client side routes!</p>\n");
    }                                                                                         // 127
                                                                                              // 128
    // we'll have Meteor load the normal application so long as                               // 129
    // we have at least one client route/handler and the done() iterator                      // 130
    // function has been passed to us, presumably from Connect.                               // 131
    if (controller.willBeHandledOnClient() && done)                                           // 132
      return done(err);                                                                       // 133
  });                                                                                         // 134
};                                                                                            // 135
                                                                                              // 136
////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                            //
// packages/iron:router/lib/plugins.js                                                        //
//                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                              //
/**                                                                                           // 1
 * Simple plugin wrapper around the loading hook.                                             // 2
 */                                                                                           // 3
Router.plugins.loading = function (router, options) {                                         // 4
  router.onBeforeAction('loading', options);                                                  // 5
};                                                                                            // 6
                                                                                              // 7
/**                                                                                           // 8
 * Simple plugin wrapper around the dataNotFound hook.                                        // 9
 */                                                                                           // 10
Router.plugins.dataNotFound = function (router, options) {                                    // 11
  router.onBeforeAction('dataNotFound', options);                                             // 12
};                                                                                            // 13
                                                                                              // 14
////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                            //
// packages/iron:router/lib/global_router.js                                                  //
//                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                              //
Router = new Iron.Router;                                                                     // 1
                                                                                              // 2
////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                            //
// packages/iron:router/lib/body_parser_server.js                                             //
//                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                              //
Router.bodyParser = Npm.require('body-parser');                                               // 1
                                                                                              // 2
////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['iron:router'] = {
  Router: Router,
  RouteController: RouteController
};

})();

//# sourceMappingURL=iron_router.js.map
