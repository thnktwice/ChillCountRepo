(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Log = Package.logging.Log;
var _ = Package.underscore._;
var RoutePolicy = Package.routepolicy.RoutePolicy;
var Boilerplate = Package['boilerplate-generator'].Boilerplate;
var Spacebars = Package.spacebars.Spacebars;
var HTML = Package.htmljs.HTML;
var Blaze = Package.blaze.Blaze;
var UI = Package.blaze.UI;
var Handlebars = Package.blaze.Handlebars;
var WebAppHashing = Package['webapp-hashing'].WebAppHashing;

/* Package-scope variables */
var WebApp, main, WebAppInternals;

(function () {

///////////////////////////////////////////////////////////////////////////////////////////
//                                                                                       //
// packages/webapp/webapp_server.js                                                      //
//                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////
                                                                                         //
////////// Requires //////////                                                           // 1
                                                                                         // 2
var fs = Npm.require("fs");                                                              // 3
var http = Npm.require("http");                                                          // 4
var os = Npm.require("os");                                                              // 5
var path = Npm.require("path");                                                          // 6
var url = Npm.require("url");                                                            // 7
var crypto = Npm.require("crypto");                                                      // 8
                                                                                         // 9
var connect = Npm.require('connect');                                                    // 10
var useragent = Npm.require('useragent');                                                // 11
var send = Npm.require('send');                                                          // 12
                                                                                         // 13
var Future = Npm.require('fibers/future');                                               // 14
var Fiber = Npm.require('fibers');                                                       // 15
                                                                                         // 16
var SHORT_SOCKET_TIMEOUT = 5*1000;                                                       // 17
var LONG_SOCKET_TIMEOUT = 120*1000;                                                      // 18
                                                                                         // 19
WebApp = {};                                                                             // 20
WebAppInternals = {};                                                                    // 21
                                                                                         // 22
WebApp.defaultArch = 'web.browser';                                                      // 23
                                                                                         // 24
// XXX maps archs to manifests                                                           // 25
WebApp.clientPrograms = {};                                                              // 26
                                                                                         // 27
// XXX maps archs to program path on filesystem                                          // 28
var archPath = {};                                                                       // 29
                                                                                         // 30
var bundledJsCssPrefix;                                                                  // 31
                                                                                         // 32
// Keepalives so that when the outer server dies unceremoniously and                     // 33
// doesn't kill us, we quit ourselves. A little gross, but better than                   // 34
// pidfiles.                                                                             // 35
// XXX This should really be part of the boot script, not the webapp package.            // 36
//     Or we should just get rid of it, and rely on containerization.                    // 37
//                                                                                       // 38
// XXX COMPAT WITH 0.9.2.2                                                               // 39
// Keepalives have been replaced with a check that the parent pid is                     // 40
// still running. We keep the --keep-alive option for backwards                          // 41
// compatibility.                                                                        // 42
var initKeepalive = function () {                                                        // 43
  var keepaliveCount = 0;                                                                // 44
                                                                                         // 45
  process.stdin.on('data', function (data) {                                             // 46
    keepaliveCount = 0;                                                                  // 47
  });                                                                                    // 48
                                                                                         // 49
  process.stdin.resume();                                                                // 50
                                                                                         // 51
  setInterval(function () {                                                              // 52
    keepaliveCount ++;                                                                   // 53
    if (keepaliveCount >= 3) {                                                           // 54
      console.log("Failed to receive keepalive! Exiting.");                              // 55
      process.exit(1);                                                                   // 56
    }                                                                                    // 57
  }, 3000);                                                                              // 58
};                                                                                       // 59
                                                                                         // 60
// Check that we have a pid that looks like an integer (non-decimal                      // 61
// integer is okay).                                                                     // 62
var validPid = function (pid) {                                                          // 63
  return ! isNaN(+pid);                                                                  // 64
};                                                                                       // 65
                                                                                         // 66
// As a replacement to the old keepalives mechanism, check for a running                 // 67
// parent every few seconds. Exit if the parent is not running.                          // 68
//                                                                                       // 69
// Two caveats to this strategy:                                                         // 70
// * Doesn't catch the case where the parent is CPU-hogging (but maybe we                // 71
//   don't want to catch that case anyway, since the bundler not yielding                // 72
//   is what caused #2536).                                                              // 73
// * Could be fooled by pid re-use, i.e. if another process comes up and                 // 74
//   takes the parent process's place before the child process dies.                     // 75
var startCheckForLiveParent = function (parentPid) {                                     // 76
  if (parentPid) {                                                                       // 77
    if (! validPid(parentPid)) {                                                         // 78
      console.error("--parent-pid must be a valid process ID.");                         // 79
      process.exit(1);                                                                   // 80
    }                                                                                    // 81
                                                                                         // 82
    setInterval(function () {                                                            // 83
      try {                                                                              // 84
        process.kill(parentPid, 0);                                                      // 85
      } catch (err) {                                                                    // 86
        console.error("Parent process is dead! Exiting.");                               // 87
        process.exit(1);                                                                 // 88
      }                                                                                  // 89
    });                                                                                  // 90
  }                                                                                      // 91
};                                                                                       // 92
                                                                                         // 93
                                                                                         // 94
var sha1 = function (contents) {                                                         // 95
  var hash = crypto.createHash('sha1');                                                  // 96
  hash.update(contents);                                                                 // 97
  return hash.digest('hex');                                                             // 98
};                                                                                       // 99
                                                                                         // 100
var readUtf8FileSync = function (filename) {                                             // 101
  return Meteor.wrapAsync(fs.readFile)(filename, 'utf8');                                // 102
};                                                                                       // 103
                                                                                         // 104
// #BrowserIdentification                                                                // 105
//                                                                                       // 106
// We have multiple places that want to identify the browser: the                        // 107
// unsupported browser page, the appcache package, and, eventually                       // 108
// delivering browser polyfills only as needed.                                          // 109
//                                                                                       // 110
// To avoid detecting the browser in multiple places ad-hoc, we create a                 // 111
// Meteor "browser" object. It uses but does not expose the npm                          // 112
// useragent module (we could choose a different mechanism to identify                   // 113
// the browser in the future if we wanted to).  The browser object                       // 114
// contains                                                                              // 115
//                                                                                       // 116
// * `name`: the name of the browser in camel case                                       // 117
// * `major`, `minor`, `patch`: integers describing the browser version                  // 118
//                                                                                       // 119
// Also here is an early version of a Meteor `request` object, intended                  // 120
// to be a high-level description of the request without exposing                        // 121
// details of connect's low-level `req`.  Currently it contains:                         // 122
//                                                                                       // 123
// * `browser`: browser identification object described above                            // 124
// * `url`: parsed url, including parsed query params                                    // 125
//                                                                                       // 126
// As a temporary hack there is a `categorizeRequest` function on WebApp which           // 127
// converts a connect `req` to a Meteor `request`. This can go away once smart           // 128
// packages such as appcache are being passed a `request` object directly when           // 129
// they serve content.                                                                   // 130
//                                                                                       // 131
// This allows `request` to be used uniformly: it is passed to the html                  // 132
// attributes hook, and the appcache package can use it when deciding                    // 133
// whether to generate a 404 for the manifest.                                           // 134
//                                                                                       // 135
// Real routing / server side rendering will probably refactor this                      // 136
// heavily.                                                                              // 137
                                                                                         // 138
                                                                                         // 139
// e.g. "Mobile Safari" => "mobileSafari"                                                // 140
var camelCase = function (name) {                                                        // 141
  var parts = name.split(' ');                                                           // 142
  parts[0] = parts[0].toLowerCase();                                                     // 143
  for (var i = 1;  i < parts.length;  ++i) {                                             // 144
    parts[i] = parts[i].charAt(0).toUpperCase() + parts[i].substr(1);                    // 145
  }                                                                                      // 146
  return parts.join('');                                                                 // 147
};                                                                                       // 148
                                                                                         // 149
var identifyBrowser = function (userAgentString) {                                       // 150
  var userAgent = useragent.lookup(userAgentString);                                     // 151
  return {                                                                               // 152
    name: camelCase(userAgent.family),                                                   // 153
    major: +userAgent.major,                                                             // 154
    minor: +userAgent.minor,                                                             // 155
    patch: +userAgent.patch                                                              // 156
  };                                                                                     // 157
};                                                                                       // 158
                                                                                         // 159
// XXX Refactor as part of implementing real routing.                                    // 160
WebAppInternals.identifyBrowser = identifyBrowser;                                       // 161
                                                                                         // 162
WebApp.categorizeRequest = function (req) {                                              // 163
  return {                                                                               // 164
    browser: identifyBrowser(req.headers['user-agent']),                                 // 165
    url: url.parse(req.url, true)                                                        // 166
  };                                                                                     // 167
};                                                                                       // 168
                                                                                         // 169
// HTML attribute hooks: functions to be called to determine any attributes to           // 170
// be added to the '<html>' tag. Each function is passed a 'request' object (see         // 171
// #BrowserIdentification) and should return a string,                                   // 172
var htmlAttributeHooks = [];                                                             // 173
var getHtmlAttributes = function (request) {                                             // 174
  var combinedAttributes  = {};                                                          // 175
  _.each(htmlAttributeHooks || [], function (hook) {                                     // 176
    var attributes = hook(request);                                                      // 177
    if (attributes === null)                                                             // 178
      return;                                                                            // 179
    if (typeof attributes !== 'object')                                                  // 180
      throw Error("HTML attribute hook must return null or object");                     // 181
    _.extend(combinedAttributes, attributes);                                            // 182
  });                                                                                    // 183
  return combinedAttributes;                                                             // 184
};                                                                                       // 185
WebApp.addHtmlAttributeHook = function (hook) {                                          // 186
  htmlAttributeHooks.push(hook);                                                         // 187
};                                                                                       // 188
                                                                                         // 189
// Serve app HTML for this URL?                                                          // 190
var appUrl = function (url) {                                                            // 191
  if (url === '/favicon.ico' || url === '/robots.txt')                                   // 192
    return false;                                                                        // 193
                                                                                         // 194
  // NOTE: app.manifest is not a web standard like favicon.ico and                       // 195
  // robots.txt. It is a file name we have chosen to use for HTML5                       // 196
  // appcache URLs. It is included here to prevent using an appcache                     // 197
  // then removing it from poisoning an app permanently. Eventually,                     // 198
  // once we have server side routing, this won't be needed as                           // 199
  // unknown URLs with return a 404 automatically.                                       // 200
  if (url === '/app.manifest')                                                           // 201
    return false;                                                                        // 202
                                                                                         // 203
  // Avoid serving app HTML for declared routes such as /sockjs/.                        // 204
  if (RoutePolicy.classify(url))                                                         // 205
    return false;                                                                        // 206
                                                                                         // 207
  // we currently return app HTML on all URLs by default                                 // 208
  return true;                                                                           // 209
};                                                                                       // 210
                                                                                         // 211
                                                                                         // 212
// We need to calculate the client hash after all packages have loaded                   // 213
// to give them a chance to populate __meteor_runtime_config__.                          // 214
//                                                                                       // 215
// Calculating the hash during startup means that packages can only                      // 216
// populate __meteor_runtime_config__ during load, not during startup.                   // 217
//                                                                                       // 218
// Calculating instead it at the beginning of main after all startup                     // 219
// hooks had run would allow packages to also populate                                   // 220
// __meteor_runtime_config__ during startup, but that's too late for                     // 221
// autoupdate because it needs to have the client hash at startup to                     // 222
// insert the auto update version itself into                                            // 223
// __meteor_runtime_config__ to get it to the client.                                    // 224
//                                                                                       // 225
// An alternative would be to give autoupdate a "post-start,                             // 226
// pre-listen" hook to allow it to insert the auto update version at                     // 227
// the right moment.                                                                     // 228
                                                                                         // 229
Meteor.startup(function () {                                                             // 230
  var calculateClientHash = WebAppHashing.calculateClientHash;                           // 231
  WebApp.clientHash = function (archName) {                                              // 232
    archName = archName || WebApp.defaultArch;                                           // 233
    return calculateClientHash(WebApp.clientPrograms[archName].manifest);                // 234
  };                                                                                     // 235
                                                                                         // 236
  WebApp.calculateClientHashRefreshable = function (archName) {                          // 237
    archName = archName || WebApp.defaultArch;                                           // 238
    return calculateClientHash(WebApp.clientPrograms[archName].manifest,                 // 239
      function (name) {                                                                  // 240
        return name === "css";                                                           // 241
      });                                                                                // 242
  };                                                                                     // 243
  WebApp.calculateClientHashNonRefreshable = function (archName) {                       // 244
    archName = archName || WebApp.defaultArch;                                           // 245
    return calculateClientHash(WebApp.clientPrograms[archName].manifest,                 // 246
      function (name) {                                                                  // 247
        return name !== "css";                                                           // 248
      });                                                                                // 249
  };                                                                                     // 250
  WebApp.calculateClientHashCordova = function () {                                      // 251
    var archName = 'web.cordova';                                                        // 252
    if (! WebApp.clientPrograms[archName])                                               // 253
      return 'none';                                                                     // 254
                                                                                         // 255
    return calculateClientHash(                                                          // 256
      WebApp.clientPrograms[archName].manifest, null, _.pick(                            // 257
        __meteor_runtime_config__, 'PUBLIC_SETTINGS'));                                  // 258
  };                                                                                     // 259
});                                                                                      // 260
                                                                                         // 261
                                                                                         // 262
                                                                                         // 263
// When we have a request pending, we want the socket timeout to be long, to             // 264
// give ourselves a while to serve it, and to allow sockjs long polls to                 // 265
// complete.  On the other hand, we want to close idle sockets relatively                // 266
// quickly, so that we can shut down relatively promptly but cleanly, without            // 267
// cutting off anyone's response.                                                        // 268
WebApp._timeoutAdjustmentRequestCallback = function (req, res) {                         // 269
  // this is really just req.socket.setTimeout(LONG_SOCKET_TIMEOUT);                     // 270
  req.setTimeout(LONG_SOCKET_TIMEOUT);                                                   // 271
  // Insert our new finish listener to run BEFORE the existing one which removes         // 272
  // the response from the socket.                                                       // 273
  var finishListeners = res.listeners('finish');                                         // 274
  // XXX Apparently in Node 0.12 this event is now called 'prefinish'.                   // 275
  // https://github.com/joyent/node/commit/7c9b6070                                      // 276
  res.removeAllListeners('finish');                                                      // 277
  res.on('finish', function () {                                                         // 278
    res.setTimeout(SHORT_SOCKET_TIMEOUT);                                                // 279
  });                                                                                    // 280
  _.each(finishListeners, function (l) { res.on('finish', l); });                        // 281
};                                                                                       // 282
                                                                                         // 283
                                                                                         // 284
// Will be updated by main before we listen.                                             // 285
// Map from client arch to boilerplate object.                                           // 286
// Boilerplate object has:                                                               // 287
//   - func: XXX                                                                         // 288
//   - baseData: XXX                                                                     // 289
var boilerplateByArch = {};                                                              // 290
                                                                                         // 291
// Given a request (as returned from `categorizeRequest`), return the                    // 292
// boilerplate HTML to serve for that request. Memoizes on HTML                          // 293
// attributes (used by, eg, appcache) and whether inline scripts are                     // 294
// currently allowed.                                                                    // 295
// XXX so far this function is always called with arch === 'web.browser'                 // 296
var memoizedBoilerplate = {};                                                            // 297
var getBoilerplate = function (request, arch) {                                          // 298
                                                                                         // 299
  var htmlAttributes = getHtmlAttributes(request);                                       // 300
                                                                                         // 301
  // The only thing that changes from request to request (for now) are                   // 302
  // the HTML attributes (used by, eg, appcache) and whether inline                      // 303
  // scripts are allowed, so we can memoize based on that.                               // 304
  var memHash = JSON.stringify({                                                         // 305
    inlineScriptsAllowed: inlineScriptsAllowed,                                          // 306
    htmlAttributes: htmlAttributes,                                                      // 307
    arch: arch                                                                           // 308
  });                                                                                    // 309
                                                                                         // 310
  if (! memoizedBoilerplate[memHash]) {                                                  // 311
    memoizedBoilerplate[memHash] = boilerplateByArch[arch].toHTML({                      // 312
      htmlAttributes: htmlAttributes                                                     // 313
    });                                                                                  // 314
  }                                                                                      // 315
  return memoizedBoilerplate[memHash];                                                   // 316
};                                                                                       // 317
                                                                                         // 318
var generateBoilerplateInstance = function (arch, manifest, additionalOptions) {         // 319
  additionalOptions = additionalOptions || {};                                           // 320
  var runtimeConfig = _.extend(__meteor_runtime_config__,                                // 321
    additionalOptions.runtimeConfigOverrides || {}                                       // 322
  );                                                                                     // 323
                                                                                         // 324
  return new Boilerplate(arch, manifest,                                                 // 325
    _.extend({                                                                           // 326
      pathMapper: function (itemPath) {                                                  // 327
        return path.join(archPath[arch], itemPath); },                                   // 328
      baseDataExtension: {                                                               // 329
        additionalStaticJs: _.map(                                                       // 330
          additionalStaticJs || [],                                                      // 331
          function (contents, pathname) {                                                // 332
            return {                                                                     // 333
              pathname: pathname,                                                        // 334
              contents: contents                                                         // 335
            };                                                                           // 336
          }                                                                              // 337
        ),                                                                               // 338
        meteorRuntimeConfig: JSON.stringify(runtimeConfig),                              // 339
        rootUrlPathPrefix: __meteor_runtime_config__.ROOT_URL_PATH_PREFIX || '',         // 340
        bundledJsCssPrefix: bundledJsCssPrefix ||                                        // 341
          __meteor_runtime_config__.ROOT_URL_PATH_PREFIX || '',                          // 342
        inlineScriptsAllowed: WebAppInternals.inlineScriptsAllowed(),                    // 343
        inline: additionalOptions.inline                                                 // 344
      }                                                                                  // 345
    }, additionalOptions)                                                                // 346
  );                                                                                     // 347
};                                                                                       // 348
                                                                                         // 349
// A mapping from url path to "info". Where "info" has the following fields:             // 350
// - type: the type of file to be served                                                 // 351
// - cacheable: optionally, whether the file should be cached or not                     // 352
// - sourceMapUrl: optionally, the url of the source map                                 // 353
//                                                                                       // 354
// Info also contains one of the following:                                              // 355
// - content: the stringified content that should be served at this path                 // 356
// - absolutePath: the absolute path on disk to the file                                 // 357
                                                                                         // 358
var staticFiles;                                                                         // 359
                                                                                         // 360
// Serve static files from the manifest or added with                                    // 361
// `addStaticJs`. Exported for tests.                                                    // 362
WebAppInternals.staticFilesMiddleware = function (staticFiles, req, res, next) {         // 363
  if ('GET' != req.method && 'HEAD' != req.method) {                                     // 364
    next();                                                                              // 365
    return;                                                                              // 366
  }                                                                                      // 367
  var pathname = connect.utils.parseUrl(req).pathname;                                   // 368
  try {                                                                                  // 369
    pathname = decodeURIComponent(pathname);                                             // 370
  } catch (e) {                                                                          // 371
    next();                                                                              // 372
    return;                                                                              // 373
  }                                                                                      // 374
                                                                                         // 375
  var serveStaticJs = function (s) {                                                     // 376
    res.writeHead(200, {                                                                 // 377
      'Content-type': 'application/javascript; charset=UTF-8'                            // 378
    });                                                                                  // 379
    res.write(s);                                                                        // 380
    res.end();                                                                           // 381
  };                                                                                     // 382
                                                                                         // 383
  if (pathname === "/meteor_runtime_config.js" &&                                        // 384
      ! WebAppInternals.inlineScriptsAllowed()) {                                        // 385
    serveStaticJs("__meteor_runtime_config__ = " +                                       // 386
                  JSON.stringify(__meteor_runtime_config__) + ";");                      // 387
    return;                                                                              // 388
  } else if (_.has(additionalStaticJs, pathname) &&                                      // 389
              ! WebAppInternals.inlineScriptsAllowed()) {                                // 390
    serveStaticJs(additionalStaticJs[pathname]);                                         // 391
    return;                                                                              // 392
  }                                                                                      // 393
                                                                                         // 394
  if (!_.has(staticFiles, pathname)) {                                                   // 395
    next();                                                                              // 396
    return;                                                                              // 397
  }                                                                                      // 398
                                                                                         // 399
  // We don't need to call pause because, unlike 'static', once we call into             // 400
  // 'send' and yield to the event loop, we never call another handler with              // 401
  // 'next'.                                                                             // 402
                                                                                         // 403
  var info = staticFiles[pathname];                                                      // 404
                                                                                         // 405
  // Cacheable files are files that should never change. Typically                       // 406
  // named by their hash (eg meteor bundled js and css files).                           // 407
  // We cache them ~forever (1yr).                                                       // 408
  //                                                                                     // 409
  // We cache non-cacheable files anyway. This isn't really correct, as users            // 410
  // can change the files and changes won't propagate immediately. However, if           // 411
  // we don't cache them, browsers will 'flicker' when rerendering                       // 412
  // images. Eventually we will probably want to rewrite URLs of static assets           // 413
  // to include a query parameter to bust caches. That way we can both get               // 414
  // good caching behavior and allow users to change assets without delay.               // 415
  // https://github.com/meteor/meteor/issues/773                                         // 416
  var maxAge = info.cacheable                                                            // 417
        ? 1000 * 60 * 60 * 24 * 365                                                      // 418
        : 1000 * 60 * 60 * 24;                                                           // 419
                                                                                         // 420
  // Set the X-SourceMap header, which current Chrome, FireFox, and Safari               // 421
  // understand.  (The SourceMap header is slightly more spec-correct but FF             // 422
  // doesn't understand it.)                                                             // 423
  //                                                                                     // 424
  // You may also need to enable source maps in Chrome: open dev tools, click            // 425
  // the gear in the bottom right corner, and select "enable source maps".               // 426
  if (info.sourceMapUrl) {                                                               // 427
    res.setHeader('X-SourceMap',                                                         // 428
                  __meteor_runtime_config__.ROOT_URL_PATH_PREFIX +                       // 429
                  info.sourceMapUrl);                                                    // 430
  }                                                                                      // 431
                                                                                         // 432
  if (info.type === "js") {                                                              // 433
    res.setHeader("Content-Type", "application/javascript; charset=UTF-8");              // 434
  } else if (info.type === "css") {                                                      // 435
    res.setHeader("Content-Type", "text/css; charset=UTF-8");                            // 436
  } else if (info.type === "json") {                                                     // 437
    res.setHeader("Content-Type", "application/json; charset=UTF-8");                    // 438
    // XXX if it is a manifest we are serving, set additional headers                    // 439
    if (/\/manifest.json$/.test(pathname)) {                                             // 440
      res.setHeader("Access-Control-Allow-Origin", "*");                                 // 441
    }                                                                                    // 442
  }                                                                                      // 443
                                                                                         // 444
  if (info.content) {                                                                    // 445
    res.write(info.content);                                                             // 446
    res.end();                                                                           // 447
  } else {                                                                               // 448
    send(req, info.absolutePath)                                                         // 449
      .maxage(maxAge)                                                                    // 450
      .hidden(true)  // if we specified a dotfile in the manifest, serve it              // 451
      .on('error', function (err) {                                                      // 452
        Log.error("Error serving static file " + err);                                   // 453
        res.writeHead(500);                                                              // 454
        res.end();                                                                       // 455
      })                                                                                 // 456
      .on('directory', function () {                                                     // 457
        Log.error("Unexpected directory " + info.absolutePath);                          // 458
        res.writeHead(500);                                                              // 459
        res.end();                                                                       // 460
      })                                                                                 // 461
      .pipe(res);                                                                        // 462
  }                                                                                      // 463
};                                                                                       // 464
                                                                                         // 465
var getUrlPrefixForArch = function (arch) {                                              // 466
  // XXX we rely on the fact that arch names don't contain slashes                       // 467
  // in that case we would need to uri escape it                                         // 468
                                                                                         // 469
  // We add '__' to the beginning of non-standard archs to "scope" the url               // 470
  // to Meteor internals.                                                                // 471
  return arch === WebApp.defaultArch ?                                                   // 472
    '' : '/' + '__' + arch.replace(/^web\./, '');                                        // 473
};                                                                                       // 474
                                                                                         // 475
var runWebAppServer = function () {                                                      // 476
  var shuttingDown = false;                                                              // 477
  var syncQueue = new Meteor._SynchronousQueue();                                        // 478
                                                                                         // 479
  var getItemPathname = function (itemUrl) {                                             // 480
    return decodeURIComponent(url.parse(itemUrl).pathname);                              // 481
  };                                                                                     // 482
                                                                                         // 483
  WebAppInternals.reloadClientPrograms = function () {                                   // 484
    syncQueue.runTask(function() {                                                       // 485
      staticFiles = {};                                                                  // 486
      var generateClientProgram = function (clientPath, arch) {                          // 487
        // read the control for the client we'll be serving up                           // 488
        var clientJsonPath = path.join(__meteor_bootstrap__.serverDir,                   // 489
                                   clientPath);                                          // 490
        var clientDir = path.dirname(clientJsonPath);                                    // 491
        var clientJson = JSON.parse(readUtf8FileSync(clientJsonPath));                   // 492
        if (clientJson.format !== "web-program-pre1")                                    // 493
          throw new Error("Unsupported format for client assets: " +                     // 494
                          JSON.stringify(clientJson.format));                            // 495
                                                                                         // 496
        if (! clientJsonPath || ! clientDir || ! clientJson)                             // 497
          throw new Error("Client config file not parsed.");                             // 498
                                                                                         // 499
        var urlPrefix = getUrlPrefixForArch(arch);                                       // 500
                                                                                         // 501
        var manifest = clientJson.manifest;                                              // 502
        _.each(manifest, function (item) {                                               // 503
          if (item.url && item.where === "client") {                                     // 504
            staticFiles[urlPrefix + getItemPathname(item.url)] = {                       // 505
              absolutePath: path.join(clientDir, item.path),                             // 506
              cacheable: item.cacheable,                                                 // 507
              // Link from source to its map                                             // 508
              sourceMapUrl: item.sourceMapUrl,                                           // 509
              type: item.type                                                            // 510
            };                                                                           // 511
                                                                                         // 512
            if (item.sourceMap) {                                                        // 513
              // Serve the source map too, under the specified URL. We assume all        // 514
              // source maps are cacheable.                                              // 515
              staticFiles[urlPrefix + getItemPathname(item.sourceMapUrl)] = {            // 516
                absolutePath: path.join(clientDir, item.sourceMap),                      // 517
                cacheable: true                                                          // 518
              };                                                                         // 519
            }                                                                            // 520
          }                                                                              // 521
        });                                                                              // 522
                                                                                         // 523
        var program = {                                                                  // 524
          manifest: manifest,                                                            // 525
          version: WebAppHashing.calculateClientHash(manifest, null, _.pick(             // 526
            __meteor_runtime_config__, 'PUBLIC_SETTINGS')),                              // 527
          PUBLIC_SETTINGS: __meteor_runtime_config__.PUBLIC_SETTINGS                     // 528
        };                                                                               // 529
                                                                                         // 530
        WebApp.clientPrograms[arch] = program;                                           // 531
                                                                                         // 532
        // Serve the program as a string at /foo/<arch>/manifest.json                    // 533
        // XXX change manifest.json -> program.json                                      // 534
        staticFiles[path.join(urlPrefix, 'manifest.json')] = {                           // 535
          content: JSON.stringify(program),                                              // 536
          cacheable: true,                                                               // 537
          type: "json"                                                                   // 538
        };                                                                               // 539
      };                                                                                 // 540
                                                                                         // 541
      try {                                                                              // 542
        var clientPaths = __meteor_bootstrap__.configJson.clientPaths;                   // 543
        _.each(clientPaths, function (clientPath, arch) {                                // 544
          archPath[arch] = path.dirname(clientPath);                                     // 545
          generateClientProgram(clientPath, arch);                                       // 546
        });                                                                              // 547
                                                                                         // 548
        // Exported for tests.                                                           // 549
        WebAppInternals.staticFiles = staticFiles;                                       // 550
      } catch (e) {                                                                      // 551
        Log.error("Error reloading the client program: " + e.stack);                     // 552
        process.exit(1);                                                                 // 553
      }                                                                                  // 554
    });                                                                                  // 555
  };                                                                                     // 556
                                                                                         // 557
  WebAppInternals.generateBoilerplate = function () {                                    // 558
    // This boilerplate will be served to the mobile devices when used with              // 559
    // Meteor/Cordova for the Hot-Code Push and since the file will be served by         // 560
    // the device's server, it is important to set the DDP url to the actual             // 561
    // Meteor server accepting DDP connections and not the device's file server.         // 562
    var defaultOptionsForArch = {                                                        // 563
      'web.cordova': {                                                                   // 564
        runtimeConfigOverrides: {                                                        // 565
          DDP_DEFAULT_CONNECTION_URL: process.env.MOBILE_DDP_URL ||                      // 566
            __meteor_runtime_config__.ROOT_URL,                                          // 567
          ROOT_URL: process.env.MOBILE_ROOT_URL ||                                       // 568
            __meteor_runtime_config__.ROOT_URL                                           // 569
        }                                                                                // 570
      }                                                                                  // 571
    };                                                                                   // 572
                                                                                         // 573
    syncQueue.runTask(function() {                                                       // 574
      _.each(WebApp.clientPrograms, function (program, archName) {                       // 575
        boilerplateByArch[archName] =                                                    // 576
          generateBoilerplateInstance(archName, program.manifest,                        // 577
                                      defaultOptionsForArch[archName]);                  // 578
      });                                                                                // 579
                                                                                         // 580
      // Clear the memoized boilerplate cache.                                           // 581
      memoizedBoilerplate = {};                                                          // 582
                                                                                         // 583
      // Configure CSS injection for the default arch                                    // 584
      // XXX implement the CSS injection for all archs?                                  // 585
      WebAppInternals.refreshableAssets = {                                              // 586
        allCss: boilerplateByArch[WebApp.defaultArch].baseData.css                       // 587
      };                                                                                 // 588
    });                                                                                  // 589
  };                                                                                     // 590
                                                                                         // 591
  WebAppInternals.reloadClientPrograms();                                                // 592
                                                                                         // 593
  // webserver                                                                           // 594
  var app = connect();                                                                   // 595
                                                                                         // 596
  // Auto-compress any json, javascript, or text.                                        // 597
  app.use(connect.compress());                                                           // 598
                                                                                         // 599
  // Packages and apps can add handlers that run before any other Meteor                 // 600
  // handlers via WebApp.rawConnectHandlers.                                             // 601
  var rawConnectHandlers = connect();                                                    // 602
  app.use(rawConnectHandlers);                                                           // 603
                                                                                         // 604
  // Strip off the path prefix, if it exists.                                            // 605
  app.use(function (request, response, next) {                                           // 606
    var pathPrefix = __meteor_runtime_config__.ROOT_URL_PATH_PREFIX;                     // 607
    var url = Npm.require('url').parse(request.url);                                     // 608
    var pathname = url.pathname;                                                         // 609
    // check if the path in the url starts with the path prefix (and the part            // 610
    // after the path prefix must start with a / if it exists.)                          // 611
    if (pathPrefix && pathname.substring(0, pathPrefix.length) === pathPrefix &&         // 612
       (pathname.length == pathPrefix.length                                             // 613
        || pathname.substring(pathPrefix.length, pathPrefix.length + 1) === "/")) {      // 614
      request.url = request.url.substring(pathPrefix.length);                            // 615
      next();                                                                            // 616
    } else if (pathname === "/favicon.ico" || pathname === "/robots.txt") {              // 617
      next();                                                                            // 618
    } else if (pathPrefix) {                                                             // 619
      response.writeHead(404);                                                           // 620
      response.write("Unknown path");                                                    // 621
      response.end();                                                                    // 622
    } else {                                                                             // 623
      next();                                                                            // 624
    }                                                                                    // 625
  });                                                                                    // 626
                                                                                         // 627
  // Parse the query string into res.query. Used by oauth_server, but it's               // 628
  // generally pretty handy..                                                            // 629
  app.use(connect.query());                                                              // 630
                                                                                         // 631
  // Serve static files from the manifest.                                               // 632
  // This is inspired by the 'static' middleware.                                        // 633
  app.use(function (req, res, next) {                                                    // 634
    Fiber(function () {                                                                  // 635
     WebAppInternals.staticFilesMiddleware(staticFiles, req, res, next);                 // 636
    }).run();                                                                            // 637
  });                                                                                    // 638
                                                                                         // 639
  // Packages and apps can add handlers to this via WebApp.connectHandlers.              // 640
  // They are inserted before our default handler.                                       // 641
  var packageAndAppHandlers = connect();                                                 // 642
  app.use(packageAndAppHandlers);                                                        // 643
                                                                                         // 644
  var suppressConnectErrors = false;                                                     // 645
  // connect knows it is an error handler because it has 4 arguments instead of          // 646
  // 3. go figure.  (It is not smart enough to find such a thing if it's hidden          // 647
  // inside packageAndAppHandlers.)                                                      // 648
  app.use(function (err, req, res, next) {                                               // 649
    if (!err || !suppressConnectErrors || !req.headers['x-suppress-error']) {            // 650
      next(err);                                                                         // 651
      return;                                                                            // 652
    }                                                                                    // 653
    res.writeHead(err.status, { 'Content-Type': 'text/plain' });                         // 654
    res.end("An error message");                                                         // 655
  });                                                                                    // 656
                                                                                         // 657
  app.use(function (req, res, next) {                                                    // 658
    if (! appUrl(req.url))                                                               // 659
      return next();                                                                     // 660
                                                                                         // 661
    var headers = {                                                                      // 662
      'Content-Type':  'text/html; charset=utf-8'                                        // 663
    };                                                                                   // 664
    if (shuttingDown)                                                                    // 665
      headers['Connection'] = 'Close';                                                   // 666
                                                                                         // 667
    var request = WebApp.categorizeRequest(req);                                         // 668
                                                                                         // 669
    if (request.url.query && request.url.query['meteor_css_resource']) {                 // 670
      // In this case, we're requesting a CSS resource in the meteor-specific            // 671
      // way, but we don't have it.  Serve a static css file that indicates that         // 672
      // we didn't have it, so we can detect that and refresh.                           // 673
      headers['Content-Type'] = 'text/css; charset=utf-8';                               // 674
      res.writeHead(200, headers);                                                       // 675
      res.write(".meteor-css-not-found-error { width: 0px;}");                           // 676
      res.end();                                                                         // 677
      return undefined;                                                                  // 678
    }                                                                                    // 679
                                                                                         // 680
    // /packages/asdfsad ... /__cordova/dafsdf.js                                        // 681
    var pathname = connect.utils.parseUrl(req).pathname;                                 // 682
    var archKey = pathname.split('/')[1];                                                // 683
    var archKeyCleaned = 'web.' + archKey.replace(/^__/, '');                            // 684
                                                                                         // 685
    if (! /^__/.test(archKey) || ! _.has(archPath, archKeyCleaned)) {                    // 686
      archKey = WebApp.defaultArch;                                                      // 687
    } else {                                                                             // 688
      archKey = archKeyCleaned;                                                          // 689
    }                                                                                    // 690
                                                                                         // 691
    var boilerplate;                                                                     // 692
    try {                                                                                // 693
      boilerplate = getBoilerplate(request, archKey);                                    // 694
    } catch (e) {                                                                        // 695
      Log.error("Error running template: " + e);                                         // 696
      res.writeHead(500, headers);                                                       // 697
      res.end();                                                                         // 698
      return undefined;                                                                  // 699
    }                                                                                    // 700
                                                                                         // 701
    res.writeHead(200, headers);                                                         // 702
    res.write(boilerplate);                                                              // 703
    res.end();                                                                           // 704
    return undefined;                                                                    // 705
  });                                                                                    // 706
                                                                                         // 707
  // Return 404 by default, if no other handlers serve this URL.                         // 708
  app.use(function (req, res) {                                                          // 709
    res.writeHead(404);                                                                  // 710
    res.end();                                                                           // 711
  });                                                                                    // 712
                                                                                         // 713
                                                                                         // 714
  var httpServer = http.createServer(app);                                               // 715
  var onListeningCallbacks = [];                                                         // 716
                                                                                         // 717
  // After 5 seconds w/o data on a socket, kill it.  On the other hand, if               // 718
  // there's an outstanding request, give it a higher timeout instead (to avoid          // 719
  // killing long-polling requests)                                                      // 720
  httpServer.setTimeout(SHORT_SOCKET_TIMEOUT);                                           // 721
                                                                                         // 722
  // Do this here, and then also in livedata/stream_server.js, because                   // 723
  // stream_server.js kills all the current request handlers when installing its         // 724
  // own.                                                                                // 725
  httpServer.on('request', WebApp._timeoutAdjustmentRequestCallback);                    // 726
                                                                                         // 727
                                                                                         // 728
  // For now, handle SIGHUP here.  Later, this should be in some centralized             // 729
  // Meteor shutdown code.                                                               // 730
  process.on('SIGHUP', Meteor.bindEnvironment(function () {                              // 731
    shuttingDown = true;                                                                 // 732
    // tell others with websockets open that we plan to close this.                      // 733
    // XXX: Eventually, this should be done with a standard meteor shut-down             // 734
    // logic path.                                                                       // 735
    httpServer.emit('meteor-closing');                                                   // 736
                                                                                         // 737
    httpServer.close(Meteor.bindEnvironment(function () {                                // 738
      if (proxy) {                                                                       // 739
        try {                                                                            // 740
          proxy.call('removeBindingsForJob', process.env.GALAXY_JOB);                    // 741
        } catch (e) {                                                                    // 742
          Log.error("Error removing bindings: " + e.message);                            // 743
          process.exit(1);                                                               // 744
        }                                                                                // 745
      }                                                                                  // 746
      process.exit(0);                                                                   // 747
                                                                                         // 748
    }, "On http server close failed"));                                                  // 749
                                                                                         // 750
    // Ideally we will close before this hits.                                           // 751
    Meteor.setTimeout(function () {                                                      // 752
      Log.warn("Closed by SIGHUP but one or more HTTP requests may not have finished."); // 753
      process.exit(1);                                                                   // 754
    }, 5000);                                                                            // 755
                                                                                         // 756
  }, function (err) {                                                                    // 757
    console.log(err);                                                                    // 758
    process.exit(1);                                                                     // 759
  }));                                                                                   // 760
                                                                                         // 761
  // start up app                                                                        // 762
  _.extend(WebApp, {                                                                     // 763
    connectHandlers: packageAndAppHandlers,                                              // 764
    rawConnectHandlers: rawConnectHandlers,                                              // 765
    httpServer: httpServer,                                                              // 766
    // For testing.                                                                      // 767
    suppressConnectErrors: function () {                                                 // 768
      suppressConnectErrors = true;                                                      // 769
    },                                                                                   // 770
    onListening: function (f) {                                                          // 771
      if (onListeningCallbacks)                                                          // 772
        onListeningCallbacks.push(f);                                                    // 773
      else                                                                               // 774
        f();                                                                             // 775
    },                                                                                   // 776
    // Hack: allow http tests to call connect.basicAuth without making them              // 777
    // Npm.depends on another copy of connect. (That would be fine if we could           // 778
    // have test-only NPM dependencies but is overkill here.)                            // 779
    __basicAuth__: connect.basicAuth                                                     // 780
  });                                                                                    // 781
                                                                                         // 782
  // Let the rest of the packages (and Meteor.startup hooks) insert connect              // 783
  // middlewares and update __meteor_runtime_config__, then keep going to set up         // 784
  // actually serving HTML.                                                              // 785
  main = function (argv) {                                                               // 786
    // main happens post startup hooks, so we don't need a Meteor.startup() to           // 787
    // ensure this happens after the galaxy package is loaded.                           // 788
    var AppConfig = Package["application-configuration"].AppConfig;                      // 789
    // We used to use the optimist npm package to parse argv here, but it's              // 790
    // overkill (and no longer in the dev bundle). Just assume any instance of           // 791
    // '--keepalive' is a use of the option.                                             // 792
    // XXX COMPAT WITH 0.9.2.2                                                           // 793
    // We used to expect keepalives to be written to stdin every few                     // 794
    // seconds; now we just check if the parent process is still alive                   // 795
    // every few seconds.                                                                // 796
    var expectKeepalives = _.contains(argv, '--keepalive');                              // 797
    // XXX Saddest argument parsing ever, should we add optimist back to                 // 798
    // the dev bundle?                                                                   // 799
    var parentPid = null;                                                                // 800
    var parentPidIndex = _.indexOf(argv, "--parent-pid");                                // 801
    if (parentPidIndex !== -1) {                                                         // 802
      parentPid = argv[parentPidIndex + 1];                                              // 803
    }                                                                                    // 804
    WebAppInternals.generateBoilerplate();                                               // 805
                                                                                         // 806
    // only start listening after all the startup code has run.                          // 807
    var localPort = parseInt(process.env.PORT) || 0;                                     // 808
    var host = process.env.BIND_IP;                                                      // 809
    var localIp = host || '0.0.0.0';                                                     // 810
    httpServer.listen(localPort, localIp, Meteor.bindEnvironment(function() {            // 811
      if (expectKeepalives || parentPid)                                                 // 812
        console.log("LISTENING"); // must match run-app.js                               // 813
      var proxyBinding;                                                                  // 814
                                                                                         // 815
      AppConfig.configurePackage('webapp', function (configuration) {                    // 816
        if (proxyBinding)                                                                // 817
          proxyBinding.stop();                                                           // 818
        if (configuration && configuration.proxy) {                                      // 819
          // TODO: We got rid of the place where this checks the app's                   // 820
          // configuration, because this wants to be configured for some things          // 821
          // on a per-job basis.  Discuss w/ teammates.                                  // 822
          proxyBinding = AppConfig.configureService(                                     // 823
            "proxy",                                                                     // 824
            "pre0",                                                                      // 825
            function (proxyService) {                                                    // 826
              if (proxyService && ! _.isEmpty(proxyService)) {                           // 827
                var proxyConf;                                                           // 828
                // XXX Figure out a per-job way to specify bind location                 // 829
                // (besides hardcoding the location for ADMIN_APP jobs).                 // 830
                if (process.env.ADMIN_APP) {                                             // 831
                  var bindPathPrefix = "";                                               // 832
                  if (process.env.GALAXY_APP !== "panel") {                              // 833
                    bindPathPrefix = "/" + bindPathPrefix +                              // 834
                      encodeURIComponent(                                                // 835
                        process.env.GALAXY_APP                                           // 836
                      ).replace(/\./g, '_');                                             // 837
                  }                                                                      // 838
                  proxyConf = {                                                          // 839
                    bindHost: process.env.GALAXY_NAME,                                   // 840
                    bindPathPrefix: bindPathPrefix,                                      // 841
                    requiresAuth: true                                                   // 842
                  };                                                                     // 843
                } else {                                                                 // 844
                  proxyConf = configuration.proxy;                                       // 845
                }                                                                        // 846
                Log("Attempting to bind to proxy at " +                                  // 847
                    proxyService);                                                       // 848
                WebAppInternals.bindToProxy(_.extend({                                   // 849
                  proxyEndpoint: proxyService                                            // 850
                }, proxyConf));                                                          // 851
              }                                                                          // 852
            }                                                                            // 853
          );                                                                             // 854
        }                                                                                // 855
      });                                                                                // 856
                                                                                         // 857
      var callbacks = onListeningCallbacks;                                              // 858
      onListeningCallbacks = null;                                                       // 859
      _.each(callbacks, function (x) { x(); });                                          // 860
                                                                                         // 861
    }, function (e) {                                                                    // 862
      console.error("Error listening:", e);                                              // 863
      console.error(e && e.stack);                                                       // 864
    }));                                                                                 // 865
                                                                                         // 866
    if (expectKeepalives) {                                                              // 867
      initKeepalive();                                                                   // 868
    }                                                                                    // 869
    if (parentPid) {                                                                     // 870
      startCheckForLiveParent(parentPid);                                                // 871
    }                                                                                    // 872
    return 'DAEMON';                                                                     // 873
  };                                                                                     // 874
};                                                                                       // 875
                                                                                         // 876
                                                                                         // 877
var proxy;                                                                               // 878
WebAppInternals.bindToProxy = function (proxyConfig) {                                   // 879
  var securePort = proxyConfig.securePort || 4433;                                       // 880
  var insecurePort = proxyConfig.insecurePort || 8080;                                   // 881
  var bindPathPrefix = proxyConfig.bindPathPrefix || "";                                 // 882
  // XXX also support galaxy-based lookup                                                // 883
  if (!proxyConfig.proxyEndpoint)                                                        // 884
    throw new Error("missing proxyEndpoint");                                            // 885
  if (!proxyConfig.bindHost)                                                             // 886
    throw new Error("missing bindHost");                                                 // 887
  if (!process.env.GALAXY_JOB)                                                           // 888
    throw new Error("missing $GALAXY_JOB");                                              // 889
  if (!process.env.GALAXY_APP)                                                           // 890
    throw new Error("missing $GALAXY_APP");                                              // 891
  if (!process.env.LAST_START)                                                           // 892
    throw new Error("missing $LAST_START");                                              // 893
                                                                                         // 894
  // XXX rename pid argument to bindTo.                                                  // 895
  // XXX factor out into a 'getPid' function in a 'galaxy' package?                      // 896
  var pid = {                                                                            // 897
    job: process.env.GALAXY_JOB,                                                         // 898
    lastStarted: +(process.env.LAST_START),                                              // 899
    app: process.env.GALAXY_APP                                                          // 900
  };                                                                                     // 901
  var myHost = os.hostname();                                                            // 902
                                                                                         // 903
  WebAppInternals.usingDdpProxy = true;                                                  // 904
                                                                                         // 905
  // This is run after packages are loaded (in main) so we can use                       // 906
  // Follower.connect.                                                                   // 907
  if (proxy) {                                                                           // 908
    // XXX the concept here is that our configuration has changed and                    // 909
    // we have connected to an entirely new follower set, which does                     // 910
    // not have the state that we set up on the follower set that we                     // 911
    // were previously connected to, and so we need to recreate all of                   // 912
    // our bindings -- analogous to getting a SIGHUP and rereading                       // 913
    // your configuration file. so probably this should actually tear                    // 914
    // down the connection and make a whole new one, rather than                         // 915
    // hot-reconnecting to a different URL.                                              // 916
    proxy.reconnect({                                                                    // 917
      url: proxyConfig.proxyEndpoint                                                     // 918
    });                                                                                  // 919
  } else {                                                                               // 920
    proxy = Package["follower-livedata"].Follower.connect(                               // 921
      proxyConfig.proxyEndpoint, {                                                       // 922
        group: "proxy"                                                                   // 923
      }                                                                                  // 924
    );                                                                                   // 925
  }                                                                                      // 926
                                                                                         // 927
  var route = process.env.ROUTE;                                                         // 928
  var ourHost = route.split(":")[0];                                                     // 929
  var ourPort = +route.split(":")[1];                                                    // 930
                                                                                         // 931
  var outstanding = 0;                                                                   // 932
  var startedAll = false;                                                                // 933
  var checkComplete = function () {                                                      // 934
    if (startedAll && ! outstanding)                                                     // 935
      Log("Bound to proxy.");                                                            // 936
  };                                                                                     // 937
  var makeCallback = function () {                                                       // 938
    outstanding++;                                                                       // 939
    return function (err) {                                                              // 940
      if (err)                                                                           // 941
        throw err;                                                                       // 942
      outstanding--;                                                                     // 943
      checkComplete();                                                                   // 944
    };                                                                                   // 945
  };                                                                                     // 946
                                                                                         // 947
  // for now, have our (temporary) requiresAuth flag apply to all                        // 948
  // routes created by this process.                                                     // 949
  var requiresDdpAuth = !! proxyConfig.requiresAuth;                                     // 950
  var requiresHttpAuth = (!! proxyConfig.requiresAuth) &&                                // 951
        (pid.app !== "panel" && pid.app !== "auth");                                     // 952
                                                                                         // 953
  // XXX a current limitation is that we treat securePort and                            // 954
  // insecurePort as a global configuration parameter -- we assume                       // 955
  // that if the proxy wants us to ask for 8080 to get port 80 traffic                   // 956
  // on our default hostname, that's the same port that we would use                     // 957
  // to get traffic on some other hostname that our proxy listens                        // 958
  // for. Likewise, we assume that if the proxy can receive secure                       // 959
  // traffic for our domain, it can assume secure traffic for any                        // 960
  // domain! Hopefully this will get cleaned up before too long by                       // 961
  // pushing that logic into the proxy service, so we can just ask for                   // 962
  // port 80.                                                                            // 963
                                                                                         // 964
  // XXX BUG: if our configuration changes, and bindPathPrefix                           // 965
  // changes, it appears that we will not remove the routes derived                      // 966
  // from the old bindPathPrefix from the proxy (until the process                       // 967
  // exits). It is not actually normal for bindPathPrefix to change,                     // 968
  // certainly not without a process restart for other reasons, but                      // 969
  // it'd be nice to fix.                                                                // 970
                                                                                         // 971
  _.each(routes, function (route) {                                                      // 972
    var parsedUrl = url.parse(route.url, /* parseQueryString */ false,                   // 973
                              /* slashesDenoteHost aka workRight */ true);               // 974
    if (parsedUrl.protocol || parsedUrl.port || parsedUrl.search)                        // 975
      throw new Error("Bad url");                                                        // 976
    parsedUrl.host = null;                                                               // 977
    parsedUrl.path = null;                                                               // 978
    if (! parsedUrl.hostname) {                                                          // 979
      parsedUrl.hostname = proxyConfig.bindHost;                                         // 980
      if (! parsedUrl.pathname)                                                          // 981
        parsedUrl.pathname = "";                                                         // 982
      if (! parsedUrl.pathname.indexOf("/") !== 0) {                                     // 983
        // Relative path                                                                 // 984
        parsedUrl.pathname = bindPathPrefix + parsedUrl.pathname;                        // 985
      }                                                                                  // 986
    }                                                                                    // 987
    var version = "";                                                                    // 988
                                                                                         // 989
    var AppConfig = Package["application-configuration"].AppConfig;                      // 990
    version = AppConfig.getStarForThisJob() || "";                                       // 991
                                                                                         // 992
                                                                                         // 993
    var parsedDdpUrl = _.clone(parsedUrl);                                               // 994
    parsedDdpUrl.protocol = "ddp";                                                       // 995
    // Node has a hardcoded list of protocols that get '://' instead                     // 996
    // of ':'. ddp needs to be added to that whitelist. Until then, we                   // 997
    // can set the undocumented attribute 'slashes' to get the right                     // 998
    // behavior. It's not clear whether than is by design or accident.                   // 999
    parsedDdpUrl.slashes = true;                                                         // 1000
    parsedDdpUrl.port = '' + securePort;                                                 // 1001
    var ddpUrl = url.format(parsedDdpUrl);                                               // 1002
                                                                                         // 1003
    var proxyToHost, proxyToPort, proxyToPathPrefix;                                     // 1004
    if (! _.has(route, 'forwardTo')) {                                                   // 1005
      proxyToHost = ourHost;                                                             // 1006
      proxyToPort = ourPort;                                                             // 1007
      proxyToPathPrefix = parsedUrl.pathname;                                            // 1008
    } else {                                                                             // 1009
      var parsedFwdUrl = url.parse(route.forwardTo, false, true);                        // 1010
      if (! parsedFwdUrl.hostname || parsedFwdUrl.protocol)                              // 1011
        throw new Error("Bad forward url");                                              // 1012
      proxyToHost = parsedFwdUrl.hostname;                                               // 1013
      proxyToPort = parseInt(parsedFwdUrl.port || "80");                                 // 1014
      proxyToPathPrefix = parsedFwdUrl.pathname || "";                                   // 1015
    }                                                                                    // 1016
                                                                                         // 1017
    if (route.ddp) {                                                                     // 1018
      proxy.call('bindDdp', {                                                            // 1019
        pid: pid,                                                                        // 1020
        bindTo: {                                                                        // 1021
          ddpUrl: ddpUrl,                                                                // 1022
          insecurePort: insecurePort                                                     // 1023
        },                                                                               // 1024
        proxyTo: {                                                                       // 1025
          tags: [version],                                                               // 1026
          host: proxyToHost,                                                             // 1027
          port: proxyToPort,                                                             // 1028
          pathPrefix: proxyToPathPrefix + '/websocket'                                   // 1029
        },                                                                               // 1030
        requiresAuth: requiresDdpAuth                                                    // 1031
      }, makeCallback());                                                                // 1032
    }                                                                                    // 1033
                                                                                         // 1034
    if (route.http) {                                                                    // 1035
      proxy.call('bindHttp', {                                                           // 1036
        pid: pid,                                                                        // 1037
        bindTo: {                                                                        // 1038
          host: parsedUrl.hostname,                                                      // 1039
          port: insecurePort,                                                            // 1040
          pathPrefix: parsedUrl.pathname                                                 // 1041
        },                                                                               // 1042
        proxyTo: {                                                                       // 1043
          tags: [version],                                                               // 1044
          host: proxyToHost,                                                             // 1045
          port: proxyToPort,                                                             // 1046
          pathPrefix: proxyToPathPrefix                                                  // 1047
        },                                                                               // 1048
        requiresAuth: requiresHttpAuth                                                   // 1049
      }, makeCallback());                                                                // 1050
                                                                                         // 1051
      // Only make the secure binding if we've been told that the                        // 1052
      // proxy knows how terminate secure connections for us (has an                     // 1053
      // appropriate cert, can bind the necessary port..)                                // 1054
      if (proxyConfig.securePort !== null) {                                             // 1055
        proxy.call('bindHttp', {                                                         // 1056
          pid: pid,                                                                      // 1057
          bindTo: {                                                                      // 1058
            host: parsedUrl.hostname,                                                    // 1059
            port: securePort,                                                            // 1060
            pathPrefix: parsedUrl.pathname,                                              // 1061
            ssl: true                                                                    // 1062
          },                                                                             // 1063
          proxyTo: {                                                                     // 1064
            tags: [version],                                                             // 1065
            host: proxyToHost,                                                           // 1066
            port: proxyToPort,                                                           // 1067
            pathPrefix: proxyToPathPrefix                                                // 1068
          },                                                                             // 1069
          requiresAuth: requiresHttpAuth                                                 // 1070
        }, makeCallback());                                                              // 1071
      }                                                                                  // 1072
    }                                                                                    // 1073
  });                                                                                    // 1074
                                                                                         // 1075
  startedAll = true;                                                                     // 1076
  checkComplete();                                                                       // 1077
};                                                                                       // 1078
                                                                                         // 1079
// (Internal, unsupported interface -- subject to change)                                // 1080
//                                                                                       // 1081
// Listen for HTTP and/or DDP traffic and route it somewhere. Only                       // 1082
// takes effect when using a proxy service.                                              // 1083
//                                                                                       // 1084
// 'url' is the traffic that we want to route, interpreted relative to                   // 1085
// the default URL where this app has been told to serve itself. It                      // 1086
// may not have a scheme or port, but it may have a host and a path,                     // 1087
// and if no host is provided the path need not be absolute. The                         // 1088
// following cases are possible:                                                         // 1089
//                                                                                       // 1090
//   //somehost.com                                                                      // 1091
//     All incoming traffic for 'somehost.com'                                           // 1092
//   //somehost.com/foo/bar                                                              // 1093
//     All incoming traffic for 'somehost.com', but only when                            // 1094
//     the first two path components are 'foo' and 'bar'.                                // 1095
//   /foo/bar                                                                            // 1096
//     Incoming traffic on our default host, but only when the                           // 1097
//     first two path components are 'foo' and 'bar'.                                    // 1098
//   foo/bar                                                                             // 1099
//     Incoming traffic on our default host, but only when the path                      // 1100
//     starts with our default path prefix, followed by 'foo' and                        // 1101
//     'bar'.                                                                            // 1102
//                                                                                       // 1103
// (Yes, these scheme-less URLs that start with '//' are legal URLs.)                    // 1104
//                                                                                       // 1105
// You can select either DDP traffic, HTTP traffic, or both. Both                        // 1106
// secure and insecure traffic will be gathered (assuming the proxy                      // 1107
// service is capable, eg, has appropriate certs and port mappings).                     // 1108
//                                                                                       // 1109
// With no 'forwardTo' option, the traffic is received by this process                   // 1110
// for service by the hooks in this 'webapp' package. The original URL                   // 1111
// is preserved (that is, if you bind "/a", and a user visits "/a/b",                    // 1112
// the app receives a request with a path of "/a/b", not a path of                       // 1113
// "/b").                                                                                // 1114
//                                                                                       // 1115
// With 'forwardTo', the process is instead sent to some other remote                    // 1116
// host. The URL is adjusted by stripping the path components in 'url'                   // 1117
// and putting the path components in the 'forwardTo' URL in their                       // 1118
// place. For example, if you forward "//somehost/a" to                                  // 1119
// "//otherhost/x", and the user types "//somehost/a/b" into their                       // 1120
// browser, then otherhost will receive a request with a Host header                     // 1121
// of "somehost" and a path of "/x/b".                                                   // 1122
//                                                                                       // 1123
// The routing continues until this process exits. For now, all of the                   // 1124
// routes must be set up ahead of time, before the initial                               // 1125
// registration with the proxy. Calling addRoute from the top level of                   // 1126
// your JS should do the trick.                                                          // 1127
//                                                                                       // 1128
// When multiple routes are present that match a given request, the                      // 1129
// most specific route wins. When routes with equal specificity are                      // 1130
// present, the proxy service will distribute the traffic between                        // 1131
// them.                                                                                 // 1132
//                                                                                       // 1133
// options may be:                                                                       // 1134
// - ddp: if true, the default, include DDP traffic. This includes                       // 1135
//   both secure and insecure traffic, and both websocket and sockjs                     // 1136
//   transports.                                                                         // 1137
// - http: if true, the default, include HTTP/HTTPS traffic.                             // 1138
// - forwardTo: if provided, should be a URL with a host, optional                       // 1139
//   path and port, and no scheme (the scheme will be derived from the                   // 1140
//   traffic type; for now it will always be a http or ws connection,                    // 1141
//   never https or wss, but we could add a forwardSecure flag to                        // 1142
//   re-encrypt).                                                                        // 1143
var routes = [];                                                                         // 1144
WebAppInternals.addRoute = function (url, options) {                                     // 1145
  options = _.extend({                                                                   // 1146
    ddp: true,                                                                           // 1147
    http: true                                                                           // 1148
  }, options || {});                                                                     // 1149
                                                                                         // 1150
  if (proxy)                                                                             // 1151
    // In the future, lift this restriction                                              // 1152
    throw new Error("Too late to add routes");                                           // 1153
                                                                                         // 1154
  routes.push(_.extend({ url: url }, options));                                          // 1155
};                                                                                       // 1156
                                                                                         // 1157
// Receive traffic on our default URL.                                                   // 1158
WebAppInternals.addRoute("");                                                            // 1159
                                                                                         // 1160
runWebAppServer();                                                                       // 1161
                                                                                         // 1162
                                                                                         // 1163
var inlineScriptsAllowed = true;                                                         // 1164
                                                                                         // 1165
WebAppInternals.inlineScriptsAllowed = function () {                                     // 1166
  return inlineScriptsAllowed;                                                           // 1167
};                                                                                       // 1168
                                                                                         // 1169
WebAppInternals.setInlineScriptsAllowed = function (value) {                             // 1170
  inlineScriptsAllowed = value;                                                          // 1171
  WebAppInternals.generateBoilerplate();                                                 // 1172
};                                                                                       // 1173
                                                                                         // 1174
WebAppInternals.setBundledJsCssPrefix = function (prefix) {                              // 1175
  bundledJsCssPrefix = prefix;                                                           // 1176
  WebAppInternals.generateBoilerplate();                                                 // 1177
};                                                                                       // 1178
                                                                                         // 1179
// Packages can call `WebAppInternals.addStaticJs` to specify static                     // 1180
// JavaScript to be included in the app. This static JS will be inlined,                 // 1181
// unless inline scripts have been disabled, in which case it will be                    // 1182
// served under `/<sha1 of contents>`.                                                   // 1183
var additionalStaticJs = {};                                                             // 1184
WebAppInternals.addStaticJs = function (contents) {                                      // 1185
  additionalStaticJs["/" + sha1(contents) + ".js"] = contents;                           // 1186
};                                                                                       // 1187
                                                                                         // 1188
// Exported for tests                                                                    // 1189
WebAppInternals.getBoilerplate = getBoilerplate;                                         // 1190
WebAppInternals.additionalStaticJs = additionalStaticJs;                                 // 1191
WebAppInternals.validPid = validPid;                                                     // 1192
                                                                                         // 1193
///////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package.webapp = {
  WebApp: WebApp,
  main: main,
  WebAppInternals: WebAppInternals
};

})();

//# sourceMappingURL=webapp.js.map
