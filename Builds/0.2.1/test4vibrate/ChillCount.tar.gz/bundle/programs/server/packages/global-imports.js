/* Imports for global scope */

RouteController = Package['iron:router'].RouteController;
Route = Package['iron:router'].Route;
Router = Package['iron:router'].Router;
Model = Package['channikhabra:stupid-models'].Model;
moment = Package['mrt:moment'].moment;
Helpers = Package['raix:handlebar-helpers'].Helpers;
MochaWeb = Package['mike:mocha'].MochaWeb;
MeteorCollectionTestReporter = Package['mike:mocha'].MeteorCollectionTestReporter;
Observatory = Package['superstringsoft:observatory'].Observatory;
TLog = Package['superstringsoft:observatory'].TLog;
Meteor = Package.meteor.Meteor;
WebApp = Package.webapp.WebApp;
main = Package.webapp.main;
WebAppInternals = Package.webapp.WebAppInternals;
Log = Package.logging.Log;
Tracker = Package.deps.Tracker;
Deps = Package.deps.Deps;
DDP = Package.livedata.DDP;
DDPServer = Package.livedata.DDPServer;
MongoInternals = Package.mongo.MongoInternals;
Mongo = Package.mongo.Mongo;
Blaze = Package.ui.Blaze;
UI = Package.ui.UI;
Handlebars = Package.ui.Handlebars;
Spacebars = Package.spacebars.Spacebars;
check = Package.check.check;
Match = Package.check.Match;
_ = Package.underscore._;
Random = Package.random.Random;
EJSON = Package.ejson.EJSON;
Async = Package['meteorhacks:async'].Async;
Accounts = Package['accounts-base'].Accounts;
SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
MongoObject = Package['aldeed:simple-schema'].MongoObject;
HTML = Package.htmljs.HTML;

