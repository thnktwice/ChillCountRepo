(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var _ = Package.underscore._;
var EJSON = Package.ejson.EJSON;
var Accounts = Package['accounts-base'].Accounts;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var Log = Package.logging.Log;
var Tracker = Package.deps.Tracker;
var Deps = Package.deps.Deps;
var DDP = Package.livedata.DDP;
var DDPServer = Package.livedata.DDPServer;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var check = Package.check.check;
var Match = Package.check.Match;
var Random = Package.random.Random;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var Observatory, TLog, __coffeescriptShare;

(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/superstringsoft:observatory/lib/lib/observatory-galileo/src/Observatory.coffee.js                      //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;

/*

   * Commented out for Meteor usage

require = if Npm? then Npm.require else require
_ = require 'underscore'
 */
var             
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

Observatory = Observatory != null ? Observatory : {};

_.extend(Observatory, {
  LOGLEVEL: {
    SILENT: -1,
    FATAL: 0,
    ERROR: 1,
    WARNING: 2,
    INFO: 3,
    VERBOSE: 4,
    DEBUG: 5,
    MAX: 6,
    NAMES: ["FATAL", "ERROR", "WARNING", "INFO", "VERBOSE", "DEBUG", "MAX"]
  },
  settings: {
    maxSeverity: 3,
    printToConsole: false
  },
  initialize: function(settings) {
    var f, _i, _len, _ref, _results;
    _ref = this._initFunctions;
    _results = [];
    for (_i = 0, _len = _ref.length; _i < _len; _i++) {
      f = _ref[_i];
      _results.push(f.call(this, settings));
    }
    return _results;
  },
  registerInitFunction: function(f) {
    return this._initFunctions.push(f);
  },
  _initFunctions: [
    function(s) {
      var _ref;
      this._loggers = [];
      this.emitters = {};
      if (s != null) {
        this.settings.maxSeverity = s.logLevel != null ? this.LOGLEVEL[s.logLevel] : 3;
        this.settings.printToConsole = (_ref = s.printToConsole) != null ? _ref : true;
      }
      this._consoleLogger = new Observatory.ConsoleLogger('default');
      if (this.settings.printToConsole) {
        this.subscribeLogger(this._consoleLogger);
      }
      this._defaultEmitter = new Observatory.Toolbox('Toolbox');
      this.emitters.Toolbox = this._defaultEmitter;
      return this.emitters.Toolbox.maxSeverity = this.settings.maxSeverity;
    }
  ],
  setSettings: function(s) {
    var k, v, _ref, _results;
    if (s.maxSeverity != null) {
      this.settings.maxSeverity = s.maxSeverity;
    } else {
      if (s.logLevel != null) {
        this.settings.maxSeverity = this.LOGLEVEL[s.logLevel];
      }
    }
    if ((s.printToConsole != null) && (s.printToConsole !== this.settings.printToConsole)) {
      this.settings.printToConsole = s.printToConsole;
      if (s.printToConsole === true) {
        this.subscribeLogger(this._consoleLogger);
      } else {
        this.unsubscribeLogger(this._consoleLogger);
      }
    }
    _ref = this.emitters;
    _results = [];
    for (k in _ref) {
      v = _ref[k];
      _results.push(v.maxSeverity = this.settings.maxSeverity);
    }
    return _results;
  },
  getDefaultLogger: function() {
    return this._defaultEmitter;
  },
  getToolbox: function() {
    return this._defaultEmitter;
  },
  isServer: function() {
    return !(typeof window !== "undefined" && window.document);
  },
  formatters: {
    basicFormatter: function(options) {
      var _ref;
      return {
        timestamp: new Date,
        severity: options.severity,
        textMessage: options.message,
        module: options.module,
        object: (_ref = options.object) != null ? _ref : options.obj,
        isServer: Observatory.isServer(),
        type: options.type
      };
    }
  },
  viewFormatters: {
    _convertDate: function(timestamp, long) {
      var ds;
      if (long == null) {
        long = false;
      }
      ds = timestamp.getUTCDate() + '/' + (timestamp.getUTCMonth() + 1);
      if (long) {
        ds = ds + +'/' + timestamp.getUTCFullYear();
      }
      return ds;
    },
    _convertTime: function(timestamp, ms) {
      var ts;
      if (ms == null) {
        ms = true;
      }
      ts = timestamp.getUTCHours() + ':' + timestamp.getUTCMinutes() + ':' + timestamp.getUTCSeconds();
      if (ms) {
        ts += '.' + timestamp.getUTCMilliseconds();
      }
      return ts;
    },
    _ps: function(s) {
      return '[' + s + ']';
    },
    basicConsole: function(o) {
      var full_message, t, ts;
      t = Observatory.viewFormatters;
      ts = t._ps(t._convertDate(o.timestamp)) + t._ps(t._convertTime(o.timestamp));
      full_message = ts + (o.isServer ? "[SERVER]" : "[CLIENT]");
      full_message += o.module ? t._ps(o.module) : "[]";
      full_message += t._ps(Observatory.LOGLEVEL.NAMES[o.severity]);
      full_message += " " + o.textMessage;
      if (o.object != null) {
        full_message += " | " + (JSON.stringify(o.object));
      }
      return full_message;
    }
  },
  _loggers: [],
  getLoggers: function() {
    return this._loggers;
  },
  subscribeLogger: function(logger) {
    return this._loggers.push(logger);
  },
  unsubscribeLogger: function(logger) {
    return this._loggers = _.without(this._loggers, logger);
  }
});

Observatory.MessageEmitter = (function() {
  var _loggers;

  _loggers = [];

  MessageEmitter.prototype._getLoggers = function() {
    return this._loggers;
  };

  function MessageEmitter(name, formatter) {
    this.name = name;
    this.formatter = formatter;
    this._loggers = [];
    this.isOn = true;
    this.isOff = false;
  }

  MessageEmitter.prototype.turnOn = function() {
    this.isOn = true;
    return this.isOff = false;
  };

  MessageEmitter.prototype.turnOff = function() {
    this.isOn = false;
    return this.isOff = true;
  };

  MessageEmitter.prototype.subscribeLogger = function(logger) {
    return this._loggers.push(logger);
  };

  MessageEmitter.prototype.unsubscribeLogger = function(logger) {
    return this._loggers = _.without(this._loggers, logger);
  };

  MessageEmitter.prototype.emitMessage = function(message, buffer) {
    var l, _i, _j, _len, _len1, _ref, _ref1;
    if (buffer == null) {
      buffer = false;
    }
    if (!this.isOn) {
      return;
    }
    _ref = Observatory.getLoggers();
    for (_i = 0, _len = _ref.length; _i < _len; _i++) {
      l = _ref[_i];
      l.addMessage(message, buffer);
    }
    if (this._loggers.length > 0) {
      _ref1 = this._loggers;
      for (_j = 0, _len1 = _ref1.length; _j < _len1; _j++) {
        l = _ref1[_j];
        l.addMessage(message, buffer);
      }
    }
    return message;
  };

  MessageEmitter.prototype.emitFormattedMessage = function(message, buffer) {
    if (buffer == null) {
      buffer = false;
    }
    if (this.isOn && (this.formatter != null) && (typeof this.formatter === 'function')) {
      this.emitMessage(this.formatter(message), buffer);
    }
    return message;
  };

  return MessageEmitter;

})();

Observatory.Logger = (function() {
  var messageBuffer;

  messageBuffer = [];

  function Logger(name, formatter, useBuffer, interval) {
    this.name = name;
    this.formatter = formatter != null ? formatter : Observatory.viewFormatters.basicConsole;
    this.useBuffer = useBuffer != null ? useBuffer : false;
    this.interval = interval != null ? interval : 3000;
    if (typeof formatter === 'boolean') {
      this.interval = this.useBuffer;
      this.useBuffer = this.formatter;
      this.formatter = Observatory.viewFormatters.basicConsole;
    }
    this.messageBuffer = [];
  }

  Logger.prototype.messageAcceptable = function(m) {
    return (m != null) && (m.timestamp != null) && (m.severity != null) && (m.isServer != null) && ((m.textMessage != null) || (m.htmlMessage != null));
  };

  Logger.prototype.addMessage = function(message, useBuffer) {
    if (useBuffer == null) {
      useBuffer = false;
    }
    if (!this.messageAcceptable(message)) {
      throw new Error("Unacceptable message format in logger: " + this.name);
    }
    if (this.useBuffer || useBuffer) {
      return this.messageBuffer.push(message);
    } else {
      return this.log(message);
    }
  };

  Logger.prototype.log = function(message) {
    throw new Error("log() function needs to be overriden to perform actual output!");
  };

  Logger.prototype.processBuffer = function() {
    var obj, _i, _len, _ref;
    if (!(this.messageBuffer.length > 0)) {
      return;
    }
    _ref = this.messageBuffer;
    for (_i = 0, _len = _ref.length; _i < _len; _i++) {
      obj = _ref[_i];
      this.log(obj);
    }
    return this.messageBuffer = [];
  };

  return Logger;

})();

Observatory.GenericEmitter = (function(_super) {
  __extends(GenericEmitter, _super);

  function GenericEmitter(name, maxSeverity, formatter) {
    var i, m, _i, _j, _len, _len1, _ref, _ref1;
    this.maxSeverity = maxSeverity;
    if ((formatter != null) && typeof formatter === 'function') {
      this.formatter = formatter;
    } else {
      this.formatter = Observatory.formatters.basicFormatter;
    }
    GenericEmitter.__super__.constructor.call(this, name, this.formatter);
    _ref = ['fatal', 'error', 'warn', 'info', 'verbose', 'debug', 'insaneVerbose'];
    for (i = _i = 0, _len = _ref.length; _i < _len; i = ++_i) {
      m = _ref[i];
      this[m] = this._emitWithSeverity.bind(this, i);
    }
    _ref1 = ['_fatal', '_error', '_warn', '_info', '_verbose', '_debug', '_insaneVerbose'];
    for (i = _j = 0, _len1 = _ref1.length; _j < _len1; i = ++_j) {
      m = _ref1[i];
      this[m] = this._forceEmitWithSeverity.bind(this, i);
    }
  }

  GenericEmitter.prototype.trace = function(error, msg, module) {
    var message, _ref;
    message = msg + '\n' + ((_ref = error.stack) != null ? _ref : error);
    return this._emitWithSeverity(Observatory.LOGLEVEL.ERROR, message, error, module);
  };

  GenericEmitter.prototype._forceEmitWithSeverity = function(severity, message, obj, module, type, buffer) {
    var options;
    if (buffer == null) {
      buffer = false;
    }
    if (typeof message === 'object') {
      buffer = type;
      type = module;
      module = obj;
      obj = message;
      message = JSON.stringify(obj);
    }
    if (typeof obj === 'string') {
      buffer = type;
      type = module;
      module = obj;
      obj = null;
    }
    options = {
      severity: severity,
      message: message,
      object: obj,
      type: type,
      module: module != null ? module : this.name
    };
    return this.emitMessage(this.formatter(options), buffer);
  };

  GenericEmitter.prototype._emitWithSeverity = function(severity, message, obj, module, type, buffer) {
    if (buffer == null) {
      buffer = false;
    }
    if ((severity == null) || (severity > this.maxSeverity)) {
      return false;
    }
    return this._forceEmitWithSeverity(severity, message, obj, module, type, buffer);
  };

  return GenericEmitter;

})(Observatory.MessageEmitter);

Observatory.ConsoleLogger = (function(_super) {
  __extends(ConsoleLogger, _super);

  function ConsoleLogger() {
    return ConsoleLogger.__super__.constructor.apply(this, arguments);
  }

  ConsoleLogger.prototype.log = function(m) {
    return console.log(this.formatter(m));
  };

  ConsoleLogger.prototype.addMessage = function(message, useBuffer) {
    if (!this.messageAcceptable(message)) {
      throw new Error("Unacceptable message format in logger: " + this.name);
    }
    return this.log(message);
  };

  return ConsoleLogger;

})(Observatory.Logger);

(typeof exports !== "undefined" && exports !== null ? exports : this).Observatory = Observatory;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/superstringsoft:observatory/lib/lib/observatory-galileo/src/Toolbox.coffee.js                          //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;

/*

   * Commented out for Meteor usage

if require?
  Observatory = (require './Observatory.coffee').Observatory
  {MessageEmitter, GenericEmitter, Logger, ConsoleLogger, LOGLEVEL} = Observatory
 */
var             
  __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

Observatory = Observatory != null ? Observatory : {};

Observatory.Toolbox = (function(_super) {
  __extends(Toolbox, _super);

  function Toolbox() {
    this.exec = __bind(this.exec, this);
    return Toolbox.__super__.constructor.apply(this, arguments);
  }

  Toolbox.prototype.exec = function(f, options) {
    var e, obj, ret, t, t2;
    if (options == null) {
      options = {
        errors: true,
        profile: true,
        profileLoglevel: 'INFO',
        message: "exec() call",
        module: 'profiler'
      };
    }
    if (typeof f !== 'function') {
      this.error("Tried to call exec() without a function as an argument");
      return;
    }
    obj = {
      "function": f.toString(),
      type: 'profile'
    };
    if (options.profile) {
      this._emitWithSeverity(Observatory.LOGLEVEL[options.profileLoglevel], options.message + " starting for " + obj["function"], options.module);
    }
    if (options.errors) {
      try {
        t = Date.now();
        ret = f.call(this);
        t2 = Date.now() - t;
      } catch (_error) {
        e = _error;
        t2 = Date.now() - t;
        this.trace(e);
      }
    } else {
      t = Date.now();
      ret = f.call(this);
      t2 = Date.now() - t;
    }
    if (options.profile) {
      this.profile(options.message + (" done in " + t2 + " ms"), t2, obj, module, options.profileLoglevel);
    }
    return ret;
  };

  Toolbox.prototype.profile = function(message, time, object, module, severity, buffer) {
    if (module == null) {
      module = 'profiler';
    }
    if (severity == null) {
      severity = 'VERBOSE';
    }
    if (buffer == null) {
      buffer = false;
    }
    object = object != null ? object : {};
    object.timeElapsed = time;
    return this._emitWithSeverity(Observatory.LOGLEVEL[severity], message, object, module, 'profile');
  };

  Toolbox.prototype._profile = function(message, time, object, module, severity, buffer) {
    if (module == null) {
      module = 'profiler';
    }
    if (severity == null) {
      severity = 'VERBOSE';
    }
    if (buffer == null) {
      buffer = false;
    }
    object = object != null ? object : {};
    object.timeElapsed = time;
    return this._forceEmitWithSeverity(Observatory.LOGLEVEL[severity], message, object, module, 'profile');
  };

  Toolbox.prototype.inspect = function(obj, long, print) {
    var it, k, ret, t, v, _i, _j, _k, _len, _len1, _len2, _ref, _ref1, _ref2;
    if (long == null) {
      long = true;
    }
    if (print == null) {
      print = false;
    }
    ret = {
      functions: [],
      objects: [],
      vars: []
    };
    for (k in obj) {
      v = obj[k];
      switch (typeof v) {
        case 'function':
          ret.functions.push({
            key: k,
            value: v
          });
          break;
        case 'object':
          ret.objects.push({
            key: k,
            value: v
          });
          break;
        default:
          ret.vars.push({
            key: k,
            value: v
          });
      }
    }
    if (print) {
      _ref = ['functions', 'objects', 'vars'];
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        t = _ref[_i];
        if (ret[t].length > 0) {
          console.log("****** PRINTING " + t + " ***********");
        }
        if (long) {
          _ref1 = ret[t];
          for (_j = 0, _len1 = _ref1.length; _j < _len1; _j++) {
            it = _ref1[_j];
            console.log("" + it.key + ": " + it.value);
          }
        } else {
          _ref2 = ret[t];
          for (_k = 0, _len2 = _ref2.length; _k < _len2; _k++) {
            it = _ref2[_k];
            console.log(it.key);
          }
        }
      }
    }
    return ret;
  };

  return Toolbox;

})(Observatory.GenericEmitter);

(typeof exports !== "undefined" && exports !== null ? exports : this).Observatory = Observatory;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/superstringsoft:observatory/lib/server/MeteorInternals.coffee.js                                       //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var _ref;             

Observatory = (_ref = this.Observatory) != null ? _ref : {};

Observatory.MeteorInternals = (function() {
  function MeteorInternals() {}

  MeteorInternals.prototype.getCurrentSessions = function() {
    return Meteor.server.sessions;
  };

  MeteorInternals.prototype.getSessionCount = function() {
    return _.keys(this.getCurrentSessions()).length;
  };

  MeteorInternals.prototype.findSession = function(id) {
    return _.find(this.getCurrentSessions(), function(v, k) {
      return k === id;
    });
  };

  MeteorInternals.prototype.getCurrentServer = function() {
    var k, methodHandlers, publishHandlers, srv, v;
    srv = Meteor.server;
    publishHandlers = (function() {
      var _ref1, _results;
      _ref1 = srv != null ? srv.publish_handlers : void 0;
      _results = [];
      for (k in _ref1) {
        v = _ref1[k];
        _results.push({
          name: k,
          func: v.toString().substring(0, v.toString().indexOf('{') - 1),
          body: v.toString().substring(v.toString().indexOf('{'))
        });
      }
      return _results;
    })();
    methodHandlers = (function() {
      var _ref1, _results;
      _ref1 = srv != null ? srv.method_handlers : void 0;
      _results = [];
      for (k in _ref1) {
        v = _ref1[k];
        _results.push({
          name: k,
          func: v.toString().substring(0, v.toString().indexOf('{') - 1),
          body: v.toString().substring(v.toString().indexOf('{'))
        });
      }
      return _results;
    })();
    return {
      publishHandlers: publishHandlers,
      methodHandlers: methodHandlers
    };
  };

  MeteorInternals.prototype.convertSessionToView = function(ss) {
    var cv, k, ns, session, v, _ref1, _ref2;
    session = {
      id: ss.id,
      connectionId: ss.connectionHandle.id,
      ip: ss.connectionHandle.clientAddress,
      headers: ss.connectionHandle.httpHeaders,
      userId: ss.userId,
      collectionViews: [],
      namedSubs: []
    };
    _ref1 = ss.collectionViews;
    for (k in _ref1) {
      v = _ref1[k];
      cv = {
        id: k,
        name: v.collectionName,
        documentCount: _.keys(v.documents).length
      };
      session.collectionViews.push(cv);
    }
    _ref2 = ss._namedSubs;
    for (k in _ref2) {
      v = _ref2[k];
      ns = {
        name: v._name,
        params: v._params,
        subscriptionHandle: v._subscriptionHandle,
        deactivated: v._deactivated,
        documentCount: _.keys(v._documents).length,
        ready: v._ready
      };
      session.namedSubs.push(ns);
    }
    return session;
  };

  return MeteorInternals;

})();

(typeof exports !== "undefined" && exports !== null ? exports : this).Observatory = Observatory;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/superstringsoft:observatory/lib/server/ObservatoryServer.coffee.js                                     //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var _checkUserId, _ref;             

Observatory = (_ref = this.Observatory) != null ? _ref : {};

Observatory.canRun = function(uid, action) {
  var err, res, user, _ref1, _ref2, _ref3;
  if (action == null) {
    action = 'view';
  }
  res = false;
  if (uid != null) {
    user = Meteor.users.findOne(uid);
  } else {
    try {
      if (uid == null) {
        user = (_ref1 = Meteor.users.findOne({
          _id: this.userId
        })) != null ? _ref1 : Meteor.user();
      }
    } catch (_error) {
      err = _error;
    }
  }
  if ((user != null ? (_ref2 = user.profile) != null ? (_ref3 = _ref2.observatoryProfile) != null ? _ref3.role : void 0 : void 0 : void 0) === "administrator") {
    res = true;
  }
  return res;
};

Observatory.Server = (function() {
  function Server() {
    this.mi = new Observatory.MeteorInternals;
    this.monitor = new Observatory.MonitoringEmitter;
  }

  Server.prototype.initialSetup = function(options) {
    var email, id, password, user;
    if (!Observatory.settingsController.needsSetup()) {
      return;
    }
    user = options.user, email = options.email, password = options.password;
    id = Accounts.createUser({
      username: user,
      email: email,
      password: password,
      profile: {
        observatoryProfile: {
          role: "administrator"
        }
      }
    });
    if (id != null) {
      return Observatory.settingsController.setupComplete();
    }
  };

  Server.prototype.handshake = function() {
    var o;
    return o = {
      version: Observatory.version,
      isLocalhost: Observatory.isLocalhost,
      needsSetup: Observatory.settingsController.needsSetup(),
      monitoring: Observatory.emitters.Monitor.isRunning,
      registeredUsers: Meteor.users.find().count(),
      logsCount: Observatory.getMeteorLogger().logsCount(),
      meteorVersion: Meteor.release,
      heartbeat: this.heartbeat(),
      sysinfo: Observatory.emitters.Monitor.sysInfoShort()
    };
  };

  Server.prototype.heartbeat = function() {
    return this.monitor.measure();
  };

  Server.prototype.publishLocal = function() {
    return Observatory.settingsController.publishLocal();
  };

  Server.prototype._publishLogsTimed = function(name, collectionName, selector) {
    return Meteor.publish(name, function(hours, scrollback, limit) {
      var cl, dt, handle;
      if (hours == null) {
        hours = 12;
      }
      if (scrollback == null) {
        scrollback = 0;
      }
      if (limit == null) {
        limit = 2000;
      }
      if (!Observatory.canRun.call(this)) {
        return;
      }
      cl = Observatory.getMeteorLogger()._logsCollection;
      dt = new Date(Date.now() - 3600000 * hours);
      selector.timestamp = {
        $gt: dt
      };
      handle = cl.find(selector, {
        sort: {
          timestamp: -1
        },
        limit: limit
      }).observe({
        added: (function(_this) {
          return function(doc) {
            return _this.added(collectionName, doc._id, doc);
          };
        })(this)
      });
      this.ready();
      this.onStop = function() {
        return handle.stop();
      };
    });
  };

  Server.prototype.publish = function(func) {
    var monitor;
    Observatory.settingsController.publishAdmin();

    /*
    Meteor.publish '_observatory_logs', (numInPage = 300, pageNumber = 0)->
       *console.log "trying to publish logs with #{numInPage} and #{pageNumber}"
      return if not Observatory.canRun.call(@)
       *console.log "trying to publish logs with #{numInPage} and #{pageNumber}"
      cl = Observatory.getMeteorLogger()._logsCollection
      cr = cl.find({type: {$ne: 'monitor'}}, {sort: {timestamp: -1}, limit: numInPage})
      cr
     */
    this._publishLogsTimed('_observatory_logs', '_observatory_remote_logs', {
      type: {
        $ne: 'monitor'
      }
    });
    this._publishLogsTimed('_observatory_monitoring', '_observatory_monitoring', {
      type: 'monitor'
    });
    this._publishLogsTimed('_observatory_http_logs', '_observatory_http_logs', {
      module: 'HTTP'
    });
    this._publishLogsTimed('_observatory_errors', '_observatory_errors', {
      severity: {
        $lte: 1
      }
    });
    this._publishLogsTimed('_observatory_profiling', '_observatory_profiling', {
      type: 'profile'
    });
    Meteor.publish('_observatory_current_sessions', function() {
      var handle, mi;
      if (!Observatory.canRun.call(this)) {
        return;
      }
      mi = new Observatory.MeteorInternals;
      handle = Observatory.DDPConnectionEmitter.SessionsCollection.find().observe({
        added: (function(_this) {
          return function(doc) {
            var ss;
            ss = mi.convertSessionToView(mi.findSession(doc.connectionId));
            ss.started = doc.started;
            return _this.added('_observatory_current_sessions', doc.connectionId, ss);
          };
        })(this),
        removed: (function(_this) {
          return function(doc) {
            return _this.removed('_observatory_current_sessions', doc.connectionId);
          };
        })(this)
      });
      this.ready();
      this.onStop = function() {
        return handle.stop();
      };
    });
    Meteor.publish('_observatory_selected_users', function(userIds) {
      var handle;
      if (!Observatory.canRun.call(this)) {
        return;
      }
      if (userIds == null) {
        userIds = [];
      }
      handle = Meteor.users.find({
        $or: [
          {
            _id: {
              $in: userIds
            }
          }, {
            "profile.observatoryProfile.role": "administrator"
          }
        ]
      }, {
        fields: {
          services: 0
        }
      }).observe({
        added: (function(_this) {
          return function(doc) {
            return _this.added('_observatory_remote_users', doc._id, doc);
          };
        })(this),
        removed: (function(_this) {
          return function(doc) {
            return _this.removed('_observatory_remote_users', doc._id);
          };
        })(this)
      });
      this.ready();
      this.onStop = function() {
        return handle.stop();
      };
    });
    monitor = this.monitor;
    return Meteor.publish('_observatory_nonpersistent_monitor', function(timePeriod, dataPoints) {
      var handle;
      if (timePeriod == null) {
        timePeriod = 5000;
      }
      if (dataPoints == null) {
        dataPoints = 50;
      }
      if (!Observatory.canRun.call(this)) {
        return;
      }
      monitor.stopNonpersistentMonitor();
      monitor.startNonpersistentMonitor(timePeriod);
      handle = monitor.Monitors.find({}, {
        sort: {
          timestamp: -1
        }
      }).observe({
        added: (function(_this) {
          return function(doc) {
            _this.added('_observatory_nonpersistent_monitor', doc._id, doc);
            if (monitor.Monitors.find({}).count() > dataPoints) {
              return monitor.Monitors.remove({
                timestamp: {
                  $lt: Date.now() - timePeriod * dataPoints
                }
              });
            }
          };
        })(this),
        removed: (function(_this) {
          return function(doc) {
            return _this.removed('_observatory_nonpersistent_monitor', doc._id);
          };
        })(this)
      });
      this.ready();
      this.onStop = function() {
        handle.stop();
        return monitor.stopNonpersistentMonitor();
      };
    });
  };

  Server.prototype.startConnectionMonitoring = function() {};

  return Server;

})();

Meteor.methods({
  _observatoryHandshake: function() {
    return Observatory.meteorServer.handshake();
  },
  _observatoryInitialSetup: function(options) {
    return Observatory.meteorServer.initialSetup(options);
  },
  _observatoryGetCurrentServer: function() {
    if (!Observatory.canRun()) {
      throw new Meteor.Error(77, "Observatory access denied");
    }
    return Observatory.meteorServer.mi.getCurrentServer();
  },
  _observatoryHeartbeat: function() {
    if (!Observatory.canRun()) {
      throw new Meteor.Error(77, "Observatory access denied");
    }
    return Observatory.meteorServer.heartbeat();
  },
  _observatoryGetOpenSessions: function() {
    var k, mi, sessions, ss, v;
    if (!Observatory.canRun()) {
      throw new Meteor.Error(77, "Observatory access denied");
    }
    mi = Observatory.meteorServer.mi;
    ss = mi.getCurrentSessions();
    sessions = [];
    for (k in ss) {
      v = ss[k];
      sessions.push(mi.convertSessionToView(v));
    }
    return sessions;
  }
});

_checkUserId = function() {
  var err, uid, _ref1;
  uid = null;
  try {
    uid = (_ref1 = this.userId) != null ? _ref1 : Meteor.userId();
    return uid;
  } catch (_error) {
    err = _error;
    return uid;
  }
};

(typeof exports !== "undefined" && exports !== null ? exports : this).Observatory = Observatory;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/superstringsoft:observatory/lib/server/DDPEmitter.coffee.js                                            //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var _ref,             
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

Observatory = (_ref = this.Observatory) != null ? _ref : {};

Observatory.DDPEmitter = (function(_super) {
  __extends(DDPEmitter, _super);

  DDPEmitter.messageStub = function() {
    var options;
    options = {
      isServer: true,
      severity: Observatory.LOGLEVEL.DEBUG,
      module: "DDP",
      timestamp: new Date
    };
    return options;
  };

  DDPEmitter._instance = void 0;

  DDPEmitter.de = function() {
    if (DDPEmitter._instance == null) {
      DDPEmitter._instance = new Observatory.DDPEmitter("DDP Emitter");
    }
    return DDPEmitter._instance;
  };

  function DDPEmitter(name, formatter) {
    this.name = name;
    this.formatter = formatter;
    DDPEmitter.__super__.constructor.call(this, this.name, this.formatter);
    this.turnOff();
    if (Observatory.DDPEmitter._instance != null) {
      throw new Error("Attempted to create another instance of DDPEmitter and it is a really bad idea");
    }
    Meteor.default_server.stream_server.register(function(socket) {
      var msg;
      if (!Observatory.DDPEmitter.de().isOn) {
        return;
      }
      msg = Observatory.DDPEmitter.messageStub();
      msg.socketId = socket.id;
      msg.textMessage = "Connected socket " + socket.id;
      Observatory.DDPEmitter.de().emitMessage(msg, true);
      socket.on('data', function(raw_msg) {
        if (!Observatory.DDPEmitter.de().isOn) {
          return;
        }
        msg = Observatory.DDPEmitter.messageStub();
        msg.socketId = this.id;
        msg.sessionId = this._session.connection._meteorSession.id;
        msg.textMessage = "Got message in a socket " + this.id + " session " + this._session.connection._meteorSession.id;
        msg.object = raw_msg;
        msg.type = "DDP";
        return Observatory.DDPEmitter.de().emitMessage(msg, true);
      });
      return socket.on('close', function() {
        if (!Observatory.DDPEmitter.de().isOn) {
          return;
        }
        msg = Observatory.DDPEmitter.messageStub();
        msg.socketId = socket.id;
        msg.textMessage = "Closed socket " + socket.id;
        return Observatory.DDPEmitter.de().emitMessage(msg, true);
      });
    });
  }

  return DDPEmitter;

})(this.Observatory.MessageEmitter);

(typeof exports !== "undefined" && exports !== null ? exports : this).Observatory = Observatory;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/superstringsoft:observatory/lib/server/DDPConnectionEmitter.coffee.js                                  //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var _ref,             
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

Observatory = (_ref = this.Observatory) != null ? _ref : {};

Observatory.DDPConnectionEmitter = (function(_super) {
  __extends(DDPConnectionEmitter, _super);

  DDPConnectionEmitter.connectionCount = 0;

  DDPConnectionEmitter.messageStub = function() {
    var options;
    options = {
      isServer: true,
      severity: Observatory.LOGLEVEL.VERBOSE,
      module: "DDP",
      timestamp: new Date
    };
    return options;
  };

  DDPConnectionEmitter._instance = void 0;

  DDPConnectionEmitter.de = function() {
    if (DDPConnectionEmitter._instance == null) {
      DDPConnectionEmitter._instance = new Observatory.DDPConnectionEmitter("DDP Connection Emitter");
    }
    return DDPConnectionEmitter._instance;
  };

  DDPConnectionEmitter.SessionsCollection = new Mongo.Collection(null);

  function DDPConnectionEmitter(name, formatter) {
    this.name = name;
    this.formatter = formatter;
    DDPConnectionEmitter.__super__.constructor.call(this, this.name, this.formatter);
    this.turnOff();
    if (Observatory.DDPConnectionEmitter._instance != null) {
      throw new Error("Attempted to create another instance of DDPConnectionEmitter and it is a really bad idea");
    }
    Meteor.onConnection((function(_this) {
      return function(con) {
        var msg;
        Observatory.DDPConnectionEmitter.SessionsCollection.insert({
          connectionId: con.id,
          started: Date.now()
        });
        if (!Observatory.DDPConnectionEmitter.de().isOn) {
          return;
        }
        Observatory.DDPConnectionEmitter.connectionCount++;
        msg = Observatory.DDPConnectionEmitter.messageStub();
        msg.connectionId = con.id;
        msg.textMessage = "New connection " + con.id + " from " + con.clientAddress;
        msg.IP = con.clientAddress;
        msg.object = {
          headers: con.httpHeaders,
          totalConnections: Observatory.DDPConnectionEmitter.connectionCount
        };
        msg.type = "DDPConnection:OPEN";
        Observatory.DDPConnectionEmitter.de().emitMessage(msg, false);
        return con.onClose(function() {
          Observatory.DDPConnectionEmitter.SessionsCollection.remove({
            connectionId: con.id
          });
          if (!Observatory.DDPConnectionEmitter.de().isOn) {
            return;
          }
          Observatory.DDPConnectionEmitter.connectionCount--;
          msg = Observatory.DDPConnectionEmitter.messageStub();
          msg.connectionId = con.id;
          msg.textMessage = "Closing connection " + con.id + " from " + con.clientAddress;
          msg.IP = con.clientAddress;
          msg.object = {
            totalConnections: Observatory.DDPConnectionEmitter.connectionCount
          };
          msg.type = "DDPConnection:CLOSE";
          return Observatory.DDPConnectionEmitter.de().emitMessage(msg, false);
        });
      };
    })(this));
  }

  return DDPConnectionEmitter;

})(this.Observatory.MessageEmitter);

(typeof exports !== "undefined" && exports !== null ? exports : this).Observatory = Observatory;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/superstringsoft:observatory/lib/server/HttpEmitter.coffee.js                                           //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var _ref,             
  __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

Observatory = (_ref = this.Observatory) != null ? _ref : {};

Observatory.HttpEmitter = (function(_super) {
  __extends(HttpEmitter, _super);

  HttpEmitter.prototype.httpLogger = function(req, res, next) {
    var end;
    if (this.isOff) {
      next();
      return;
    }
    req._startTime = Date.now();
    end = res.end;
    res.end = (function(_this) {
      return function(chunk, encoding) {
        var obj, timeElaspsed;
        res.end = end;
        res.end(chunk, encoding);
        timeElaspsed = Date.now() - req._startTime;
        obj = {
          url: req.originalUrl || req.url,
          method: req.method,
          referrer: req.headers["referer"] || req.headers["referrer"],
          remoteAddress: req.ip ? req.ip : req.socket.socket ? req.socket.socket.remoteAddress : req.socket.remoteAddress,
          status: res.statusCode,
          httpVersion: req.httpVersionMajor + "." + req.httpVersionMinor,
          userAgent: req.headers["user-agent"],
          responseHeader: res._header,
          acceptLanguage: req.headers['accept-language'],
          forwardedFor: req.headers['x-forwarded-for'],
          timestamp: new Date,
          responseTime: timeElaspsed,
          timeElaspsed: timeElaspsed,
          type: 'http'
        };
        return _this.emitFormattedMessage(obj, true);
      };
    })(this);
    return next();
  };

  function HttpEmitter(name) {
    this.name = name;
    this.httpLogger = __bind(this.httpLogger, this);
    this.turnOff();
    this.formatter = function(l) {
      var msg, options, severity;
      msg = "" + l.method + " " + l.url + ": " + l.status + " from " + l.forwardedFor + " in " + l.responseTime + " ms";
      severity = Observatory.LOGLEVEL.VERBOSE;
      if (l.status >= 500) {
        severity = Observatory.LOGLEVEL.FATAL;
      } else {
        if (l.status >= 400) {
          severity = Observatory.LOGLEVEL.ERROR;
        } else {
          if (l.status >= 300) {
            severity = Observatory.LOGLEVEL.WARNING;
          }
        }
      }
      options = {
        isServer: true,
        textMessage: msg,
        module: "HTTP",
        timestamp: l.timestamp,
        type: 'profile',
        severity: severity,
        ip: l.forwardedFor,
        object: l
      };
      return options;
    };
    HttpEmitter.__super__.constructor.call(this, this.name, this.formatter);
    WebApp.connectHandlers.use(this.httpLogger);
  }

  return HttpEmitter;

})(this.Observatory.MessageEmitter);

(typeof exports !== "undefined" && exports !== null ? exports : this).Observatory = Observatory;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/superstringsoft:observatory/lib/server/MonitoringEmitter.coffee.js                                     //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var os, util, _ref,             
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

util = Npm.require('util');

os = Npm.require('os');

Observatory = (_ref = this.Observatory) != null ? _ref : {};

Observatory.MonitoringEmitter = (function(_super) {
  var secondsToString;

  __extends(MonitoringEmitter, _super);

  MonitoringEmitter.prototype.sysInfo = function() {
    var o;
    return o = {
      cpus: os.cpus(),
      host: os.hostname(),
      os: {
        type: os.type(),
        platform: os.platform(),
        arch: os.arch(),
        release: os.release()
      },
      network: os.networkInterfaces(),
      url: Meteor.absoluteUrl()
    };
  };

  MonitoringEmitter.prototype.sysInfoShort = function() {
    var o, _ref1;
    o = this.sysInfo();
    o.cpuType = (_ref1 = o.cpus[0]) != null ? _ref1.model : void 0;
    o.cpus = o.cpus.length;
    o.network = _.keys(o.network).length;
    return o;
  };

  MonitoringEmitter.prototype.measure = function() {
    var obj;
    return obj = {
      procMemUse: process.memoryUsage(),
      osUptime: os.uptime(),
      procUptime: process.uptime(),
      loadavg: os.loadavg(),
      totalmem: os.totalmem(),
      freemem: os.freemem()
    };
  };

  secondsToString = function(seconds) {
    var numdays, numhours, numminutes, numseconds;
    numdays = Math.floor(seconds / 86400);
    numhours = Math.floor((seconds % 86400) / 3600);
    numminutes = Math.floor(((seconds % 86400) % 3600) / 60);
    numseconds = ((seconds % 86400) % 3600) % 60;
    return numdays + " days " + numhours + " hours " + numminutes + " minutes " + numseconds + " seconds";
  };

  function MonitoringEmitter(name) {
    this.name = name;
    this.name = name != null ? name : 'Monitor';
    this._sessions = [];
    this.isRunning = false;
    this._monitorHandle = null;
    this.mi = new Observatory.MeteorInternals;
    this.Monitors = new Mongo.Collection(null);
    MonitoringEmitter.__super__.constructor.call(this, this.name);
  }

  MonitoringEmitter.prototype.startMonitor = function(timePeriod) {
    if (this.isRunning) {
      this.stopMonitor;
    }
    timePeriod = timePeriod != null ? timePeriod : 60000;
    return this._monitorHandle = Meteor.setInterval((function(_this) {
      return function() {
        var msg, obj;
        obj = _this.measure();
        obj.currentSessionNumber = _this.mi.getSessionCount();
        msg = {
          isServer: true,
          timestamp: new Date,
          module: 'Monitor',
          type: 'monitor',
          severity: Observatory.LOGLEVEL.INFO,
          object: obj,
          textMessage: "Monitoring every " + (timePeriod / 1000) + "s"
        };
        _this.emitMessage(msg);
        return _this.isRunning = true;
      };
    })(this), timePeriod);
  };

  MonitoringEmitter.prototype.stopMonitor = function() {
    if (this.isRunning) {
      Meteor.clearInterval(this._monitorHandle);
      return this.isRunning = false;
    }
  };

  MonitoringEmitter.prototype.startNonpersistentMonitor = function(timePeriod) {
    if (timePeriod == null) {
      timePeriod = 5000;
    }
    return this._persistentMonitorHandle = Meteor.setInterval((function(_this) {
      return function() {
        var o;
        o = _this.measure();
        o.currentSessionNumber = _this.mi.getSessionCount();
        o.timestamp = Date.now();
        return _this.Monitors.insert(o);
      };
    })(this), timePeriod);
  };

  MonitoringEmitter.prototype.stopNonpersistentMonitor = function() {
    Meteor.clearInterval(this._persistentMonitorHandle);
    return this.Monitors.remove({});
  };

  MonitoringEmitter.prototype.sessionToLoggingOptions = function(session) {
    var o;
    o = {
      timestamp: null
    };
    return o;
  };

  return MonitoringEmitter;

})(this.Observatory.MessageEmitter);

(typeof exports !== "undefined" && exports !== null ? exports : this).Observatory = Observatory;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/superstringsoft:observatory/lib/MeteorLogger.coffee.js                                                 //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var _ref,             
  __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

Observatory = (_ref = this.Observatory) != null ? _ref : {};

Observatory.MeteorLogger = (function(_super) {
  __extends(MeteorLogger, _super);

  function MeteorLogger(name, colName, connection) {
    this.name = name;
    this.colName = colName != null ? colName : '_observatory_logs';
    if (connection == null) {
      connection = null;
    }
    this._checkUserId = __bind(this._checkUserId, this);
    this.log = __bind(this.log, this);
    MeteorLogger.__super__.constructor.call(this, this.name);
    this._logsCollection = new Mongo.Collection(this.colName);
    if (Meteor.isServer) {
      this._logsCollection.allow({
        update: function(uid) {
          return false;
        },
        insert: (function(_this) {
          return function(uid) {
            return _this.allowInsert(uid);
          };
        })(this),
        remove: (function(_this) {
          return function(uid) {
            return _this.allowRemove(uid);
          };
        })(this)
      });
    }
  }

  MeteorLogger.prototype.allowInsert = function(uid) {
    return false;
  };

  MeteorLogger.prototype.allowRemove = function(uid) {
    return false;
  };

  MeteorLogger.prototype.log = function(message) {
    var msg, _ref1;
    if (Meteor.isClient) {
      if (!Observatory.settingsController.currentSettings().logAnonymous) {
        if (!Observatory.settingsController.currentSettings().logUser) {
          return;
        } else {
          if (Meteor.userId() == null) {
            return;
          }
        }
      }
    }
    msg = message;
    msg.userId = (_ref1 = msg.userId) != null ? _ref1 : this._checkUserId();
    if (!Meteor.isServer) {
      msg.connectionId = Meteor.connection._lastSessionId;
    }
    return this._logsCollection.insert(msg);
  };

  MeteorLogger.prototype.logsCount = function() {
    return this._logsCollection.find().count();
  };

  MeteorLogger.prototype._checkUserId = function() {
    var err, uid, _ref1;
    uid = null;
    try {
      uid = (_ref1 = this.userId) != null ? _ref1 : Meteor.userId();
    } catch (_error) {
      err = _error;
    }
    return uid;
  };

  return MeteorLogger;

})(Observatory.Logger);

(typeof exports !== "undefined" && exports !== null ? exports : this).Observatory = Observatory;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/superstringsoft:observatory/lib/Settings.coffee.js                                                     //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var _ref;             

Observatory = (_ref = this.Observatory) != null ? _ref : {};

Observatory.SettingsCommon = (function() {
  function SettingsCommon() {}

  SettingsCommon.defaultClientSettings = {
    logLevel: "DEBUG",
    printToConsole: true,
    logUser: true,
    logAnonymous: true
  };

  SettingsCommon.col = new Mongo.Collection('_observatory_settings');

  SettingsCommon.prototype.processSettingsUpdate = function(s) {
    return Observatory.setSettings(s);
  };

  SettingsCommon.prototype.currentSettings = function() {
    throw new Error("SettingsCommon::currentSettings - needs overloading and should not be called directly");
  };

  return SettingsCommon;

})();

(typeof exports !== "undefined" && exports !== null ? exports : this).Observatory = Observatory;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/superstringsoft:observatory/lib/server/Settings.coffee.js                                              //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var _ref,             
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

Observatory = (_ref = this.Observatory) != null ? _ref : {};

Observatory.Settings = (function(_super) {
  __extends(Settings, _super);

  Settings.defaultServerSettings = {
    logLevel: "INFO",
    printToConsole: false,
    logUser: true,
    logAnonymous: false,
    logHttp: true,
    logDDP: false,
    logBasicDDP: true,
    prohibitAutoPublish: false
  };

  function Settings() {
    this.col = Observatory.SettingsCommon.col;

    /*
    @col.deny
      insert: -> true
      update: -> true
      remove: -> true
     */
    this.col.allow({
      insert: function(uid, doc) {
        return Observatory.canRun(uid);
      },
      update: function(uid, doc, fields, modifier) {
        return Observatory.canRun(uid);
      },
      remove: function(uid, doc) {
        var _ref1;
        return Observatory.canRun(uid) && ((_ref1 = doc.type) !== "SERVER" && _ref1 !== "CLIENT_LOGGEDIN" && _ref1 !== "CLIENT_ANONYMOUS");
      }
    });
    this.loadSettings();
    this.col.find({
      type: "SERVER"
    }).observe({
      changed: (function(_this) {
        return function(newDoc, oldDoc) {
          return _this.processSettingsUpdate(newDoc.settings);
        };
      })(this),
      removed: (function(_this) {
        return function(doc) {
          throw new Meteor.Error(78, "SERVER settings removed: this SHOULD NOT be happening!");
        };
      })(this)
    });
  }

  Settings.prototype.needsSetup = function() {
    if (this.col.find({
      initialSetupComplete: true
    }).count() > 0) {
      return false;
    } else {
      return true;
    }
  };

  Settings.prototype.setupComplete = function() {
    return this.col.insert({
      initialSetupComplete: true
    });
  };

  Settings.prototype.loadSettings = function() {
    if (this.col.find().count() === 0) {
      this.col.insert({
        type: "SERVER",
        settings: Observatory.Settings.defaultServerSettings
      });
      this.col.insert({
        type: "CLIENT_LOGGEDIN",
        settings: Observatory.Settings.defaultClientSettings
      });
      this.col.insert({
        type: "CLIENT_ANONYMOUS",
        settings: Observatory.Settings.defaultClientSettings
      });
    }
    if (this.col.find({
      type: "SERVER"
    }).count() === 0) {
      this.col.insert({
        type: "SERVER",
        settings: Observatory.Settings.defaultServerSettings
      });
    }
    return this.currentSettings();
  };

  Settings.prototype.publishLocal = function() {
    return Meteor.publish('_observatory_settings', function(opts) {
      if (this.userId) {
        return Observatory.SettingsCommon.col.find({
          type: "CLIENT_LOGGEDIN"
        });
      } else {
        return Observatory.SettingsCommon.col.find({
          type: "CLIENT_ANONYMOUS"
        });
      }
    });
  };

  Settings.prototype.publishAdmin = function() {
    return Meteor.publish('_observatory_settings_admin', function(opts) {
      if (!Observatory.canRun.call(this)) {
        return;
      }
      return Observatory.SettingsCommon.col.find({});
    });
  };

  Settings.prototype.currentSettings = function() {
    var cs;
    cs = this.col.findOne({
      type: "SERVER"
    });
    return cs.settings;
  };

  Settings.prototype.processSettingsUpdate = function(s) {
    Settings.__super__.processSettingsUpdate.call(this, s);
    if (s.logBasicDDP) {
      Observatory.emitters.DDPConnection.turnOn();
    } else {
      Observatory.emitters.DDPConnection.turnOff();
    }
    if (s.logDDP) {
      Observatory.emitters.DDP.turnOn();
    } else {
      Observatory.emitters.DDP.turnOff();
    }
    if (s.logHttp) {
      Observatory.emitters.Http.turnOn();
    } else {
      Observatory.emitters.Http.turnOff();
    }
    if (this.currentSettings().logAnonymous) {
      return Observatory._meteorLogger.allowInsert = function() {
        return true;
      };
    } else {
      if (this.currentSettings().logUser) {
        return Observatory._meteorLogger.allowInsert = function(uid) {
          if (uid != null) {
            return true;
          } else {
            return false;
          }
        };
      } else {
        return Observatory._meteorLogger.allowInsert = function() {
          return false;
        };
      }
    }
  };

  return Settings;

})(Observatory.SettingsCommon);

(typeof exports !== "undefined" && exports !== null ? exports : this).Observatory = Observatory;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/superstringsoft:observatory/lib/server/Observatory.coffee.js                                           //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var _ref;             

Observatory = (_ref = this.Observatory) != null ? _ref : {};

Observatory.initialize = _.wrap(Observatory.initialize, function(f, s) {
  Observatory.settingsController = new Observatory.Settings;
  if (s == null) {
    s = Observatory.settingsController.currentSettings();
  }
  return f.call(Observatory, s);
});

Observatory.setSettings = _.wrap(Observatory.setSettings, function(f, s) {
  return f.call(Observatory, s);

  /*
  @settings.logUser = s.logUser ? @settings.logUser
  @settings.logHttp = s?.logHttp ? @settings.logHttp
  @settings.logDDP = s?.logDDP ? @settings.logDDP
   */
});

Observatory.registerInitFunction(function(s) {

  /*
  @settings.logsCollectionName = s?.logsCollectionName ? '_observatory_logs'
  @settings.logUser = s?.logUser ? true
  @settings.logHttp = s?.logHttp ? true
  @settings.logDDP = s?.logDDP ? false
  @settings.prohibitAutoPublish = s?.prohibitAutoPublish ? false
  @settings.logAnonymous = s?.logAnonymous ? false
   */
  var _ref1;
  this._meteorLogger = new Observatory.MeteorLogger('Meteor Logger', (_ref1 = this.settingsController.currentSettings().logsCollectionName) != null ? _ref1 : '_observatory_logs');
  this.subscribeLogger(this._meteorLogger);
  this.meteorServer = new Observatory.Server;
  this.meteorServer.publish();
  this.meteorServer.publishLocal();
  this.emitters.DDP = Observatory.DDPEmitter.de('DDP');
  this.emitters.DDPConnection = Observatory.DDPConnectionEmitter.de('DDP Connection');
  this.emitters.Http = new Observatory.HttpEmitter('HTTP');
  this.emitters.Monitor = new Observatory.MonitoringEmitter('Monitor');
  this.settingsController.processSettingsUpdate(this.settingsController.currentSettings());
  this.isLocalhost = Meteor.absoluteUrl({
    replaceLocalhost: true
  }).indexOf("http://127.0.0.1") === 0 ? true : false;
  return Meteor.setInterval(function() {
    var m;
    m = Observatory.getMeteorLogger();
    return m.processBuffer();
  }, 3000);
});


/*
if Meteor.isServer
  Observatory._meteorLogger.allowInsert = (uid)->
    console.log "Trying to insert for " + uid
    true
 */


/*
Meteor.publish = _.wrap Meteor.publish, (f)->
  args = _.rest arguments
   *console.log args

  name = args[0]
  func = args[1]

  args[1] = _.wrap func, (f1)->
    t1 = Date.now()
    args1 = _.rest arguments
    console.log "Calling publish function #{name} with #{args1}"
    ret = f1.apply this, args1
    console.log "...executed in #{Date.now()-t1}ms"
    ret

  r = f.apply this, args
  r
 */

(typeof exports !== "undefined" && exports !== null ? exports : this).Observatory = Observatory;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/superstringsoft:observatory/lib/Observatory.coffee.js                                                  //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var _ref;             

Observatory = (_ref = this.Observatory) != null ? _ref : {};

Observatory.version = {
  major: 0,
  minor: 4,
  patch: 8
};

Observatory.isServer = function() {
  return Meteor.isServer;
};

Observatory.getMeteorLogger = function() {
  return Observatory._meteorLogger;
};

Observatory.initialize();

(typeof exports !== "undefined" && exports !== null ? exports : this).Observatory = Observatory;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/superstringsoft:observatory/globals.js                                                                 //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
/**                                                                                                                // 1
 * Created by aantich on 20/09/14.                                                                                 // 2
 */                                                                                                                // 3
Observatory = this.Observatory;                                                                                    // 4
TLog = this.TLog;                                                                                                  // 5
                                                                                                                   // 6
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['superstringsoft:observatory'] = {
  Observatory: Observatory,
  TLog: TLog
};

})();

//# sourceMappingURL=superstringsoft_observatory.js.map
