(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var check = Package.check.check;
var Match = Package.check.Match;
var HTTP = Package.http.HTTP;
var Retry = Package.retry.Retry;

/* Package-scope variables */
var Velocity, VelocityTestFiles, VelocityFixtureFiles, VelocityTestReports, VelocityAggregateReports, VelocityLogs, VelocityMirrors, DEBUG;

(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/velocity:core/collections.js                                                                             //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
/*jshint -W117 */                                                                                                    // 1
/* global                                                                                                            // 2
 VelocityTestFiles: true,                                                                                            // 3
 VelocityTestReports: true,                                                                                          // 4
 VelocityAggregateReports: true,                                                                                     // 5
 VelocityLogs: true,                                                                                                 // 6
 VelocityMirrors: true                                                                                               // 7
 */                                                                                                                  // 8
                                                                                                                     // 9
VelocityTestFiles = new Meteor.Collection('velocityTestFiles');                                                      // 10
VelocityFixtureFiles = new Meteor.Collection('velocityFixtureFiles');                                                // 11
VelocityTestReports = new Meteor.Collection('velocityTestReports');                                                  // 12
VelocityAggregateReports = new Meteor.Collection('velocityAggregateReports');                                        // 13
VelocityLogs = new Meteor.Collection('velocityLogs');                                                                // 14
VelocityMirrors = new Meteor.Collection('velocityMirrors');                                                          // 15
                                                                                                                     // 16
(function () {                                                                                                       // 17
  'use strict';                                                                                                      // 18
                                                                                                                     // 19
  if (!Package.autopublish) {                                                                                        // 20
    if (Meteor.isServer) {                                                                                           // 21
      Meteor.publish('VelocityTestFiles', function () {                                                              // 22
        return VelocityTestFiles.find({});                                                                           // 23
      });                                                                                                            // 24
      Meteor.publish('VelocityFixtureFiles', function () {                                                           // 25
        return VelocityFixtureFiles.find({});                                                                        // 26
      });                                                                                                            // 27
      Meteor.publish('VelocityTestReports', function () {                                                            // 28
        return VelocityTestReports.find({});                                                                         // 29
      });                                                                                                            // 30
      Meteor.publish('VelocityAggregateReports', function () {                                                       // 31
        return VelocityAggregateReports.find({});                                                                    // 32
      });                                                                                                            // 33
      Meteor.publish('VelocityLogs', function () {                                                                   // 34
        return VelocityLogs.find({});                                                                                // 35
      });                                                                                                            // 36
      Meteor.publish('VelocityMirrors', function () {                                                                // 37
        return VelocityMirrors.find({});                                                                             // 38
      });                                                                                                            // 39
    }                                                                                                                // 40
                                                                                                                     // 41
    if (Meteor.isClient) {                                                                                           // 42
      Meteor.subscribe('VelocityTestFiles');                                                                         // 43
      Meteor.subscribe('VelocityFixtureFiles');                                                                      // 44
      Meteor.subscribe('VelocityTestReports');                                                                       // 45
      Meteor.subscribe('VelocityAggregateReports');                                                                  // 46
      Meteor.subscribe('VelocityLogs');                                                                              // 47
      Meteor.subscribe('VelocityMirrors');                                                                           // 48
    }                                                                                                                // 49
  }                                                                                                                  // 50
})();                                                                                                                // 51
                                                                                                                     // 52
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/velocity:core/main.js                                                                                    //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
/*jshint -W117, -W030 */                                                                                             // 1
/* global                                                                                                            // 2
 Velocity:true,                                                                                                      // 3
 DEBUG:true                                                                                                          // 4
 */                                                                                                                  // 5
                                                                                                                     // 6
DEBUG = !!process.env.VELOCITY_DEBUG;                                                                                // 7
/**                                                                                                                  // 8
 * @module Velocity                                                                                                  // 9
 */                                                                                                                  // 10
/**                                                                                                                  // 11
 * @class Velocity                                                                                                   // 12
 */                                                                                                                  // 13
Velocity = {};                                                                                                       // 14
                                                                                                                     // 15
(function () {                                                                                                       // 16
  'use strict';                                                                                                      // 17
                                                                                                                     // 18
//////////////////////////////////////////////////////////////////////                                               // 19
// Init                                                                                                              // 20
//                                                                                                                   // 21
                                                                                                                     // 22
  if (process.env.NODE_ENV !== 'development' || process.env.VELOCITY === '0' || process.env.IS_MIRROR) {             // 23
    DEBUG && console.log('Not adding velocity code');                                                                // 24
    return;                                                                                                          // 25
  }                                                                                                                  // 26
                                                                                                                     // 27
  /*                                                                                                                 // 28
   * Returns true for Meteor versions >= 0.9.2                                                                       // 29
   */                                                                                                                // 30
  var isMeteor92OrNewer = function () {                                                                              // 31
    if (Meteor.release) {                                                                                            // 32
      if (Meteor.release === "none"){                                                                                // 33
        DEBUG && console.log("Running from checkout, assuming > 0.9.2");                                             // 34
        return true;                                                                                                 // 35
      }                                                                                                              // 36
      var versionRegExp = /^(?:METEOR@)?(\d+)\.(\d+)\.(\d+)/;                                                        // 37
      var version = versionRegExp.exec(Meteor.release);                                                              // 38
      if (version) {                                                                                                 // 39
        var majorVersion = Number(version[1]);                                                                       // 40
        var minorVersion = Number(version[2]);                                                                       // 41
        var patchVersion = Number(version[3]);                                                                       // 42
        if (majorVersion > 0 ||                                                                                      // 43
          (majorVersion == 0 && minorVersion > 9) ||                                                                 // 44
          (majorVersion == 0 && minorVersion == 9 && patchVersion >= 2)                                              // 45
          ) {                                                                                                        // 46
          return true;                                                                                               // 47
        }                                                                                                            // 48
      }                                                                                                              // 49
    }                                                                                                                // 50
                                                                                                                     // 51
    return false;                                                                                                    // 52
  };                                                                                                                 // 53
                                                                                                                     // 54
  var getAssetPath = function (packageName, fileName) {                                                              // 55
    var serverAssetsPath = path.join(                                                                                // 56
      process.env.PWD, '.meteor', 'local', 'build', 'programs', 'server', 'assets'                                   // 57
    );                                                                                                               // 58
    if (isMeteor92OrNewer()) {                                                                                       // 59
      packageName = packageName.replace(':', '_')                                                                    // 60
    }                                                                                                                // 61
                                                                                                                     // 62
    return path.join(serverAssetsPath, 'packages', packageName, fileName);                                           // 63
  };                                                                                                                 // 64
                                                                                                                     // 65
  var _ = Npm.require('lodash'),                                                                                     // 66
      fs = Npm.require('fs'),                                                                                        // 67
      fse = Npm.require('fs-extra'),                                                                                 // 68
      readFile = Meteor._wrapAsync(fs.readFile),                                                                     // 69
      writeFile = Meteor._wrapAsync(fs.writeFile),                                                                   // 70
      copyFile = Meteor._wrapAsync(fse.copy),                                                                        // 71
      path = Npm.require('path'),                                                                                    // 72
      url = Npm.require('url'),                                                                                      // 73
      Rsync = Npm.require('rsync'),                                                                                  // 74
      Future = Npm.require('fibers/future'),                                                                         // 75
      freeport = Npm.require('freeport'),                                                                            // 76
      child_process = Npm.require('child_process'),                                                                  // 77
      spawn = child_process.spawn,                                                                                   // 78
      chokidar = Npm.require('chokidar'),                                                                            // 79
      glob = Npm.require('glob'),                                                                                    // 80
      mkdirp = Npm.require('mkdirp'),                                                                                // 81
      _config = {},                                                                                                  // 82
      _preProcessors = [],                                                                                           // 83
      _postProcessors = [],                                                                                          // 84
      _watcher,                                                                                                      // 85
      FIXTURE_REG_EXP = new RegExp("-fixture.(js|coffee)$"),                                                         // 86
      DEFAULT_FIXTURE_PATH = getAssetPath('velocity:core', 'default-fixture.js');                                    // 87
                                                                                                                     // 88
  Meteor.startup(function initializeVelocity () {                                                                    // 89
    DEBUG && console.log('[velocity] PWD', process.env.PWD);                                                         // 90
    DEBUG && console.log('velocity config =', JSON.stringify(_config, null, 2));                                     // 91
                                                                                                                     // 92
    // kick-off everything                                                                                           // 93
    _reset(_config);                                                                                                 // 94
  });                                                                                                                // 95
                                                                                                                     // 96
//////////////////////////////////////////////////////////////////////                                               // 97
// Public Methods                                                                                                    // 98
//                                                                                                                   // 99
                                                                                                                     // 100
  _.extend(Velocity, {                                                                                               // 101
                                                                                                                     // 102
    getMirrorPath: function () {                                                                                     // 103
      return path.join(process.env.PWD, '.meteor', 'local', '.mirror');                                              // 104
    },                                                                                                               // 105
                                                                                                                     // 106
    getTestsPath: function () {                                                                                      // 107
      return path.join(process.env.PWD, 'tests');                                                                    // 108
    },                                                                                                               // 109
                                                                                                                     // 110
    addPreProcessor: function (preProcessor) {                                                                       // 111
      _preProcessors.push(preProcessor);                                                                             // 112
    },                                                                                                               // 113
                                                                                                                     // 114
    addPostProcessor: function (reporter) {                                                                          // 115
      _postProcessors.push(reporter);                                                                                // 116
    },                                                                                                               // 117
                                                                                                                     // 118
    getReportGithubIssueMessage: function() {                                                                        // 119
      return "Please report the issue here: https://github.com/xolvio/velocity/issues";                              // 120
    }                                                                                                                // 121
  });                                                                                                                // 122
                                                                                                                     // 123
  if (Meteor.isServer) {                                                                                             // 124
    _.extend(Velocity, {                                                                                             // 125
      /**                                                                                                            // 126
       * Registers a testing framework plugin.                                                                       // 127
       *                                                                                                             // 128
       * @method registerTestingFramework                                                                            // 129
       * @param {String} name The name of the testing framework.                                                     // 130
       * @param {Object} [options] Options for the testing framework.                                                // 131
       * @param {String} options.regex The regular expression for                                                    // 132
       *                      test files that should be assigned                                                     // 133
       *                      to the testing framework.                                                              // 134
       *                                 The path relative to the tests                                              // 135
       *                                 folder is matched against it.                                               // 136
       *                                 The default is "name/.+\.js$"                                               // 137
       *                                 (name is the testing framework name).                                       // 138
       * @param options.sampleTestGenerator {Function} sampleTestGenerator                                           // 139
       *    returns an array of fileObjects with the following fields:                                               // 140
       * @param options.sampleTestGenerator.path {String} relative path to place test file (from PROJECT/tests)      // 141
       * @param options.sampleTestGenerator.contents {String} contents of the test file the path thats returned      // 142
       */                                                                                                            // 143
      registerTestingFramework: function (name, options) {                                                           // 144
        _config[name] = _parseTestingFrameworkOptions(name, options);                                                // 145
      },                                                                                                             // 146
      parseXmlFiles: function  (selectedFramework){                                                                  // 147
         var closeFunc = Meteor.bindEnvironment(function () {                                                        // 148
           console.log('binding environment and parsing output xml files...')                                        // 149
                                                                                                                     // 150
            function hashCode (s) {                                                                                  // 151
              return s.split("").reduce(function (a, b) {                                                            // 152
                a = ((a << 5) - a) + b.charCodeAt(0);                                                                // 153
                return a & a;                                                                                        // 154
              }, 0);                                                                                                 // 155
            }                                                                                                        // 156
                                                                                                                     // 157
           var newResults = [];                                                                                      // 158
           //var globSearchString = parsePath('**/FIREFOX*.xml');                                                    // 159
           var globSearchString = path.join('**', 'FIREFOX_*.xml');                                                  // 160
           var xmlFiles = glob.sync(globSearchString, { cwd: testReportsPath });                                     // 161
                                                                                                                     // 162
           console.log('globSearchString', globSearchString);                                                        // 163
                                                                                                                     // 164
           _.each(xmlFiles, function (xmlFile, index) {                                                              // 165
             parseString(fs.readFileSync(testReportsPath + path.sep + xmlFile), function (err, result) {             // 166
               _.each(result.testsuites.testsuite, function (testsuite) {                                            // 167
                 _.each(testsuite.testcase, function (testcase) {                                                    // 168
                   var result = ({                                                                                   // 169
                     name: testcase.$.name,                                                                          // 170
                     framework: selectedFramework,                                                                   // 171
                     result: testcase.failure ? 'failed' : 'passed',                                                 // 172
                     timestamp: testsuite.$.timestamp,                                                               // 173
                     time: testcase.$.time,                                                                          // 174
                     ancestors: [testcase.$.classname]                                                               // 175
                   });                                                                                               // 176
                                                                                                                     // 177
                   if (testcase.failure) {                                                                           // 178
                     _.each(testcase.failure, function (failure) {                                                   // 179
                       result.failureType = failure.$.type;                                                          // 180
                       result.failureMessage = failure.$.message;                                                    // 181
                       result.failureStackTrace = failure._;                                                         // 182
                     });                                                                                             // 183
                   }                                                                                                 // 184
                   result.id = selectedFramework + ':' + hashCode(xmlFile + testcase.$.classname + testcase.$.name); // 185
                   newResults.push(result.id);                                                                       // 186
                   console.log('result', result);                                                                    // 187
                   Meteor.call('postResult', result);                                                                // 188
                 });                                                                                                 // 189
               });                                                                                                   // 190
             });                                                                                                     // 191
                                                                                                                     // 192
             if (index === xmlFiles.length - 1) {                                                                    // 193
               Meteor.call('resetReports', {framework: selectedFramework, notIn: newResults});                       // 194
               Meteor.call('completed', {framework: selectedFramework});                                             // 195
             }                                                                                                       // 196
           });                                                                                                       // 197
         });                                                                                                         // 198
      }                                                                                                              // 199
    });                                                                                                              // 200
  }                                                                                                                  // 201
                                                                                                                     // 202
//////////////////////////////////////////////////////////////////////                                               // 203
// Meteor Methods                                                                                                    // 204
//                                                                                                                   // 205
                                                                                                                     // 206
  Meteor.methods({                                                                                                   // 207
                                                                                                                     // 208
    /**                                                                                                              // 209
     * Meteor method: reset                                                                                          // 210
     * Re-init file watcher and clear all test results.                                                              // 211
     *                                                                                                               // 212
     * @method reset                                                                                                 // 213
     */                                                                                                              // 214
    reset: function () {                                                                                             // 215
      _reset(_config);                                                                                               // 216
    },                                                                                                               // 217
                                                                                                                     // 218
    /**                                                                                                              // 219
     * Meteor method: resetReports                                                                                   // 220
     * Clear all test results.                                                                                       // 221
     *                                                                                                               // 222
     * @method resetReports                                                                                          // 223
     * @param {Object} [options] Optional, specify specific framework to clear                                       // 224
     *                 and/or define a list of tests to keep.                                                        // 225
     *                 ex.                                                                                           // 226
     *                 {                                                                                             // 227
     *                   framework: 'jasmine-unit',                                                                  // 228
     *                   notIn: ['tests/auth-jasmine-unit.js']                                                       // 229
     *                 }                                                                                             // 230
     */                                                                                                              // 231
    resetReports: function (options) {                                                                               // 232
      options = options || {};                                                                                       // 233
      check(options, {                                                                                               // 234
        framework: Match.Optional(String),                                                                           // 235
        notIn: Match.Optional([String])                                                                              // 236
      });                                                                                                            // 237
                                                                                                                     // 238
      var query = {};                                                                                                // 239
      if (options.framework) {                                                                                       // 240
        query.framework = options.framework;                                                                         // 241
      }                                                                                                              // 242
      if (options.notIn) {                                                                                           // 243
        query = _.assign(query, {_id: {$nin: options.notIn }});                                                      // 244
      }                                                                                                              // 245
      VelocityTestReports.remove(query);                                                                             // 246
      _updateAggregateReports();                                                                                     // 247
    },                                                                                                               // 248
                                                                                                                     // 249
    /**                                                                                                              // 250
     * Meteor method: resetLogs                                                                                      // 251
     * Clear all log entried.                                                                                        // 252
     *                                                                                                               // 253
     * @method resetLogs                                                                                             // 254
     * @param {Object} [options] Optional, specify specific framework to clear                                       // 255
     */                                                                                                              // 256
    resetLogs: function (options) {                                                                                  // 257
      options = options || {};                                                                                       // 258
      check(options, {                                                                                               // 259
        framework: Match.Optional(String)                                                                            // 260
      });                                                                                                            // 261
                                                                                                                     // 262
      var query = {};                                                                                                // 263
      if (options.framework) {                                                                                       // 264
        query.framework = options.framework;                                                                         // 265
      }                                                                                                              // 266
      VelocityLogs.remove(query);                                                                                    // 267
    },                                                                                                               // 268
                                                                                                                     // 269
    /**                                                                                                              // 270
     * Meteor method: postLog                                                                                        // 271
     * Log a method to the central Velocity log store.                                                               // 272
     *                                                                                                               // 273
     * @method postLog                                                                                               // 274
     * @param {Object} options Required parameters:                                                                  // 275
     *                   type - String                                                                               // 276
     *                   message - String                                                                            // 277
     *                   framework - String  ex. 'jasmine-unit'                                                      // 278
     *                                                                                                               // 279
     *                 Optional parameters:                                                                          // 280
     *                   timestamp - Date                                                                            // 281
     */                                                                                                              // 282
    postLog: function (options) {                                                                                    // 283
      console.log                                                                                                    // 284
      check(options, {                                                                                               // 285
        type: String,                                                                                                // 286
        message: String,                                                                                             // 287
        framework: String,                                                                                           // 288
        timestamp: Match.Optional(Match.OneOf(Date, String))                                                         // 289
      });                                                                                                            // 290
                                                                                                                     // 291
      VelocityLogs.insert({                                                                                          // 292
        timestamp: options.timestamp || new Date(),                                                                  // 293
        type: options.type,                                                                                          // 294
        message: options.message,                                                                                    // 295
        framework: options.framework                                                                                 // 296
      });                                                                                                            // 297
    },                                                                                                               // 298
                                                                                                                     // 299
    /**                                                                                                              // 300
     * Meteor method: postResult                                                                                     // 301
     * Record the results of a test run.                                                                             // 302
     *                                                                                                               // 303
     * @method postResult                                                                                            // 304
     * @param {Object} data Required fields:                                                                         // 305
     *                   id - String                                                                                 // 306
     *                   name - String                                                                               // 307
     *                   framework - String  ex. 'jasmine-unit'                                                      // 308
     *                   result - String.  ex. 'failed', 'passed' or 'pending'                                       // 309
     *                                                                                                               // 310
     *                 Suggested fields:                                                                             // 311
     *                   isClient - {Boolean] Is it a client test?                                                   // 312
     *                   isServer - {Boolean} Is it a server test?                                                   // 313
     *                   browser  - {String} In which browser did the test run?                                      // 314
     *                   timestamp - {Date} The time that the test started for this result                           // 315
     *                   async - // TODO @rissem to write                                                            // 316
     *                   timeOut - // TODO @rissem to write                                                          // 317
     *                   failureType - {String} ex 'expect' or 'assert'                                              // 318
     *                   failureMessage - {String} The failure message from the test framework                       // 319
     *                   failureStackTrace - {String} The stack trace associated with the failure                    // 320
     *                   ancestors - The hierarchy of suites and blocks above this test                              // 321
     *                               ex. 'Template.leaderboard.selected_name'                                        // 322
     */                                                                                                              // 323
    postResult: function (data) {                                                                                    // 324
      // Nightwatch doesn't return failureType, failureMessage, feailureStackTrace, or ancestors                     // 325
      // we can't assume that a test framework will have that informationPhoenix42                                   // 326
      check(data, Match.ObjectIncluding({                                                                            // 327
        id: String,                                                                                                  // 328
        name: String,                                                                                                // 329
        framework: _matchOneOf(_.keys(_config)),                                                                     // 330
        result: _matchOneOf(['passed', 'failed', 'pending']),                                                        // 331
        isClient: Match.Optional(Boolean),                                                                           // 332
        isServer: Match.Optional(Boolean),                                                                           // 333
        browser: Match.Optional(_matchOneOf(['chrome', 'firefox', 'internet explorer', 'opera', 'safari'])), // TODO: Add missing values
        timestamp: Match.Optional(Match.OneOf(Date, String)),                                                        // 335
        async: Match.Optional(Boolean),                                                                              // 336
        timeOut: Match.Optional(Match.Any)                                                                           // 337
        //failureType: Match.Optional(String),                                                                       // 338
        //failureMessage: Match.Optional(String),                                                                    // 339
        //failureStackTrace: Match.Optional(Match.Any),                                                              // 340
        //ancestors: Match.Optional([String])                                                                        // 341
      }));                                                                                                           // 342
                                                                                                                     // 343
      VelocityTestReports.upsert(data.id, {$set: data});                                                             // 344
      _updateAggregateReports();                                                                                     // 345
    },  // end postResult                                                                                            // 346
                                                                                                                     // 347
    /**                                                                                                              // 348
     * Meteor method: completed                                                                                      // 349
     * Frameworks must call this method to inform Velocity they have completed                                       // 350
     * their current test runs. Velocity uses this flag when running in CI mode.                                     // 351
     *                                                                                                               // 352
     * @method completed                                                                                             // 353
     * @param {Object} data Required fields:                                                                         // 354
     *                   framework - String  ex. 'jasmine-unit'                                                      // 355
     */                                                                                                              // 356
    completed: function (data) {                                                                                     // 357
      check(data, {                                                                                                  // 358
        framework: String                                                                                            // 359
      });                                                                                                            // 360
                                                                                                                     // 361
      VelocityAggregateReports.upsert({'name': data.framework}, {$set: {'result': 'completed'}});                    // 362
      _updateAggregateReports();                                                                                     // 363
    },  // end completed                                                                                             // 364
                                                                                                                     // 365
    /**                                                                                                              // 366
     * Meteor method: copySampleTests                                                                                // 367
     * Copy sample tests from frameworks `sample-tests` directories                                                  // 368
     * to user's `app/tests` directory.                                                                              // 369
     *                                                                                                               // 370
     * @method copySampleTests                                                                                       // 371
     * @param {Object} options                                                                                       // 372
     *     ex. {framework: 'jasmine-unit'}                                                                           // 373
     */                                                                                                              // 374
    copySampleTests: function (options) {                                                                            // 375
      var pwd = process.env.PWD,                                                                                     // 376
          samplesPath,                                                                                               // 377
          testsPath,                                                                                                 // 378
          command;                                                                                                   // 379
                                                                                                                     // 380
      options = options || {};                                                                                       // 381
      check(options, {                                                                                               // 382
        framework: String                                                                                            // 383
      });                                                                                                            // 384
                                                                                                                     // 385
      if (_config[options.framework].sampleTestGenerator){                                                           // 386
        var sampleTests = _config[options.framework].sampleTestGenerator(options);                                   // 387
        DEBUG && console.log('[velocity] found ', sampleTests.length, 'sample test files for', options.framework);   // 388
        sampleTests.forEach(function(testFile){                                                                      // 389
          var fullTestPath = path.join(pwd, 'tests', testFile.path);                                                 // 390
          var testDir = path.dirname(fullTestPath);                                                                  // 391
          mkdirp.sync(testDir);                                                                                      // 392
          fs.writeFileSync(fullTestPath, testFile.contents);                                                         // 393
        });                                                                                                          // 394
      } else {                                                                                                       // 395
        samplesPath = path.join(pwd, 'packages', options.framework, 'sample-tests');                                 // 396
        testsPath = path.join(pwd, 'tests');                                                                         // 397
                                                                                                                     // 398
        DEBUG && console.log('[velocity] checking for sample tests in', path.join(samplesPath, '*'));                // 399
                                                                                                                     // 400
        if (fs.existsSync(samplesPath)) {                                                                            // 401
          command = 'mkdir -p ' + testsPath + ' && ' +                                                               // 402
            'rsync -au ' + path.join(samplesPath, '*') +                                                             // 403
            ' ' + testsPath + path.sep;                                                                              // 404
                                                                                                                     // 405
          DEBUG && console.log('[velocity] copying sample tests (if any) for framework', options.framework, '-', command);
                                                                                                                     // 407
          child_process.exec(command, Meteor.bindEnvironment(                                                        // 408
            function copySampleTestsExecHandler (err, stdout, stderr) {                                              // 409
              if (err) {                                                                                             // 410
                console.log('ERROR', err);                                                                           // 411
              }                                                                                                      // 412
              console.log(stdout);                                                                                   // 413
              console.log(stderr);                                                                                   // 414
            },                                                                                                       // 415
            'copySampleTestsExecHandler'                                                                             // 416
          ));                                                                                                        // 417
        }                                                                                                            // 418
      }                                                                                                              // 419
    },  // end copySampleTests                                                                                       // 420
                                                                                                                     // 421
    /**                                                                                                              // 422
     * Meteor method: velocityStartMirror                                                                            // 423
     *                                                                                                               // 424
     * Starts a mirror and copies any specified fixture files into the mirror.                                       // 425
     * TODO and will remove any registered frameworks and reporters from the mirror                                  // 426
     *                                                                                                               // 427
     * @method velocityStartMirror                                                                                   // 428
     * @param {Object} options Required fields:                                                                      // 429
     *                   name - String ex. 'mocha-web-1'                                                             // 430
     *                                                                                                               // 431
     *                 Optional parameters:                                                                          // 432
     *                   fixtureFiles - Array of files with absolute paths                                           // 433
     *                   port - String use a specific port instead of finding the next available one                 // 434
     *                                                                                                               // 435
     * @return the url of started mirror                                                                             // 436
     */                                                                                                              // 437
    velocityStartMirror: function (options) {                                                                        // 438
      check(options, {                                                                                               // 439
        name: String,                                                                                                // 440
        fixtureFiles: Match.Optional([String]),                                                                      // 441
        port: Match.Optional(Number)                                                                                 // 442
      });                                                                                                            // 443
                                                                                                                     // 444
      var port = options.port || Meteor._wrapAsync(freeport)();                                                      // 445
      var mongoLocation = _getMongoUrl(options.name);                                                                // 446
      var mirrorLocation = _getMirrorUrl(port);                                                                      // 447
                                                                                                                     // 448
      if (options.fixtureFiles) {                                                                                    // 449
        _addFixtures(options.fixtureFiles);                                                                          // 450
      }                                                                                                              // 451
                                                                                                                     // 452
      var opts = {                                                                                                   // 453
        cwd: Velocity.getMirrorPath(),                                                                               // 454
        stdio: 'pipe',                                                                                               // 455
        env: _.extend({}, process.env, {                                                                             // 456
          ROOT_URL: mirrorLocation,                                                                                  // 457
          MONGO_URL: mongoLocation,                                                                                  // 458
          PARENT_URL: process.env.ROOT_URL,                                                                          // 459
          IS_MIRROR: true                                                                                            // 460
        })                                                                                                           // 461
      };                                                                                                             // 462
                                                                                                                     // 463
      writeFile(Velocity.getMirrorPath() + '/settings.json', JSON.stringify(Meteor.settings));                       // 464
                                                                                                                     // 465
      DEBUG && console.log('[velocity] Mirror: starting at', mirrorLocation);                                        // 466
                                                                                                                     // 467
      var spawnAttempts = 10;                                                                                        // 468
      var spawnMeteor = function () {                                                                                // 469
        var closeHandler = function (code, signal) {                                                                 // 470
          console.log('[velocity] Mirror: exited with code ' + code + ' signal ' + signal);                          // 471
          setTimeout(function () {                                                                                   // 472
            console.log('[velocity] Mirror: trying to restart');                                                     // 473
            spawnAttempts--;                                                                                         // 474
            if (spawnAttempts) {                                                                                     // 475
              spawnMeteor();                                                                                         // 476
            } else {                                                                                                 // 477
              console.error('[velocity] Mirror: could not be started on port ' + port + '.\n' +                      // 478
                'Please make sure that nothing else is using the port and then restart your app to try again.');     // 479
            }                                                                                                        // 480
          }, 1000);                                                                                                  // 481
        };                                                                                                           // 482
        var meteor = spawn(                                                                                          // 483
          'meteor',                                                                                                  // 484
          ['--port', port, '--settings', 'settings.json'],                                                           // 485
          opts                                                                                                       // 486
        );                                                                                                           // 487
        meteor.on('close', closeHandler);                                                                            // 488
                                                                                                                     // 489
        var outputHandler = function (data) {                                                                        // 490
          var lines = data.toString().split(/\r?\n/).slice(0, -1);                                                   // 491
          _.map(lines, function (line) {                                                                             // 492
            console.log('[velocity mirror] ' + line);                                                                // 493
          });                                                                                                        // 494
        };                                                                                                           // 495
        if (!!process.env.VELOCITY_DEBUG_MIRROR) {                                                                   // 496
          meteor.stdout.on('data', outputHandler);                                                                   // 497
        }                                                                                                            // 498
        meteor.stderr.on('data', outputHandler);                                                                     // 499
      };                                                                                                             // 500
      spawnMeteor();                                                                                                 // 501
                                                                                                                     // 502
      var storeMirrorMetadata = function () {                                                                        // 503
        VelocityMirrors.insert({                                                                                     // 504
          framework: options.framework,                                                                              // 505
          name: options.name,                                                                                        // 506
          port: port,                                                                                                // 507
          rootUrl: mirrorLocation,                                                                                   // 508
          mongoUrl: mongoLocation                                                                                    // 509
        });                                                                                                          // 510
      };                                                                                                             // 511
                                                                                                                     // 512
      return _retryHttpGet(mirrorLocation, {url: mirrorLocation, port: port}, function (statusCode) {                // 513
        if (statusCode === 200) {                                                                                    // 514
          storeMirrorMetadata();                                                                                     // 515
        } else {                                                                                                     // 516
          console.error('Mirror did not start correctly. Status code was ', statusCode);                             // 517
        }                                                                                                            // 518
      });                                                                                                            // 519
                                                                                                                     // 520
    },  // end velocityStartMirror                                                                                   // 521
                                                                                                                     // 522
                                                                                                                     // 523
    /**                                                                                                              // 524
     * Meteor method: velocityIsMirror                                                                               // 525
     * Exposes the IS_MIRROR flag to clients                                                                         // 526
     *                                                                                                               // 527
     * @method velocityIsMirror                                                                                      // 528
     */                                                                                                              // 529
    velocityIsMirror: function () {                                                                                  // 530
      return !!process.env.IS_MIRROR;                                                                                // 531
    }                                                                                                                // 532
                                                                                                                     // 533
  });  // end Meteor methods                                                                                         // 534
                                                                                                                     // 535
//////////////////////////////////////////////////////////////////////                                               // 536
// Private functions                                                                                                 // 537
//                                                                                                                   // 538
                                                                                                                     // 539
  function _getTestFrameworkNames() {                                                                                // 540
    return _.pluck(_config, 'name');                                                                                 // 541
  }                                                                                                                  // 542
                                                                                                                     // 543
  /**                                                                                                                // 544
   * Returns the MongoDB URL for the given database.                                                                 // 545
   * @param database                                                                                                 // 546
   * @returns {string} MongoDB Url                                                                                   // 547
   * @private                                                                                                        // 548
   */                                                                                                                // 549
  function _getMongoUrl (database) {                                                                                 // 550
    var mongoLocationParts = url.parse(process.env.MONGO_URL);                                                       // 551
    var mongoLocation = url.format({                                                                                 // 552
      protocol: mongoLocationParts.protocol,                                                                         // 553
      slashes: mongoLocationParts.slashes,                                                                           // 554
      hostname: mongoLocationParts.hostname,                                                                         // 555
      port: mongoLocationParts.port,                                                                                 // 556
      pathname: '/' + database                                                                                       // 557
    });                                                                                                              // 558
    return mongoLocation;                                                                                            // 559
  }                                                                                                                  // 560
                                                                                                                     // 561
  /**                                                                                                                // 562
   * Return URL for the mirror with the given port.                                                                  // 563
   * @param port Mirror port                                                                                         // 564
   * @returns {string} Mirror URL                                                                                    // 565
   * @private                                                                                                        // 566
   */                                                                                                                // 567
  function _getMirrorUrl (port) {                                                                                    // 568
    var rootUrlParts = url.parse(Meteor.absoluteUrl());                                                              // 569
    var mirrorLocation = url.format({                                                                                // 570
      protocol: rootUrlParts.protocol,                                                                               // 571
      slashes: rootUrlParts.slashes,                                                                                 // 572
      hostname: rootUrlParts.hostname,                                                                               // 573
      port: port,                                                                                                    // 574
      pathname: rootUrlParts.pathname                                                                                // 575
    });                                                                                                              // 576
    return mirrorLocation;                                                                                           // 577
  }                                                                                                                  // 578
                                                                                                                     // 579
  /**                                                                                                                // 580
   * Add fixtures to the database.                                                                                   // 581
   * @param fixtureFiles Array with fixture file paths.                                                              // 582
   * @private                                                                                                        // 583
   */                                                                                                                // 584
  function _addFixtures (fixtureFiles) {                                                                             // 585
    _.each(fixtureFiles, function (fixtureFile) {                                                                    // 586
      VelocityFixtureFiles.insert({                                                                                  // 587
        _id: fixtureFile,                                                                                            // 588
        absolutePath: fixtureFile                                                                                    // 589
      });                                                                                                            // 590
    });                                                                                                              // 591
  }                                                                                                                  // 592
                                                                                                                     // 593
  /**                                                                                                                // 594
   *                                                                                                                 // 595
   * Performs a http get and retries the specified number of times with the specified timeouts.                      // 596
   * Uses a future to respond and the future return object can be provided.                                          // 597
   *                                                                                                                 // 598
   * @method _retryHttpGet                                                                                           // 599
   * @param url                   requiredFields  The target location                                                // 600
   *                                                                                                                 // 601
   * @param futureResponse        optional        The future response that will be augmented with the                // 602
   *                                              http status code (if successful)                                   // 603
   * @param preResponseCallback   optional        Maximum number of retries                                          // 604
   * @param retries               optional        Maximum number of retries                                          // 605
   * @param maxTimeout            optional        Maximum time to wait for the location to respond                   // 606
   *                                                                                                                 // 607
   * @return    A future that can be used in meteor methods (or for other async needs)                               // 608
   * @private                                                                                                        // 609
   */                                                                                                                // 610
  function _retryHttpGet (url, futureResponse, preResponseCallback, retries, maxTimeout) {                           // 611
    var f = new Future();                                                                                            // 612
    var retry = new Retry({                                                                                          // 613
      baseTimeout: 100,                                                                                              // 614
      maxTimeout: maxTimeout ? maxTimeout : 1000                                                                     // 615
    });                                                                                                              // 616
    var tries = 0;                                                                                                   // 617
    var doGet = function () {                                                                                        // 618
      try {                                                                                                          // 619
        var res = HTTP.get(url);                                                                                     // 620
        preResponseCallback && preResponseCallback(res.statusCode);                                                  // 621
        f.return(_.extend({                                                                                          // 622
          statusCode: res.statusCode                                                                                 // 623
        }, futureResponse));                                                                                         // 624
      } catch (ex) {                                                                                                 // 625
        if (tries < retries ? retries : 5) {                                                                         // 626
          DEBUG && console.log('[velocity] retrying mirror at ', url, ex.message);                                   // 627
          retry.retryLater(++tries, doGet);                                                                          // 628
        } else {                                                                                                     // 629
          console.error('[velocity] mirror failed to respond', ex.message);                                          // 630
          f.throw(ex);                                                                                               // 631
        }                                                                                                            // 632
      }                                                                                                              // 633
    };                                                                                                               // 634
    doGet();                                                                                                         // 635
    return f.wait();                                                                                                 // 636
  } // end _retryHttpGet                                                                                             // 637
                                                                                                                     // 638
  /**                                                                                                                // 639
   * Matcher for checking if a value is one of the given values.                                                     // 640
   * @param {Array} values Valid values.                                                                             // 641
   * @returns {*}                                                                                                    // 642
   * @private                                                                                                        // 643
   */                                                                                                                // 644
  function _matchOneOf (values) {                                                                                    // 645
    return Match.Where(function (value) {                                                                            // 646
      return (values.indexOf(value) !== -1);                                                                         // 647
    });                                                                                                              // 648
  }                                                                                                                  // 649
                                                                                                                     // 650
  function _parseTestingFrameworkOptions(name, options) {                                                            // 651
    options = options || {};                                                                                         // 652
    _.defaults(options, {                                                                                            // 653
      name: name,                                                                                                    // 654
      regex: name + '\\' + path.sep + '.+\\.js$'                                                                     // 655
    });                                                                                                              // 656
                                                                                                                     // 657
    options._regexp = new RegExp(options.regex);                                                                     // 658
                                                                                                                     // 659
    return options;                                                                                                  // 660
  }                                                                                                                  // 661
                                                                                                                     // 662
  /**                                                                                                                // 663
   * Initialize the directory/file watcher.                                                                          // 664
   *                                                                                                                 // 665
   * @method _initWatcher                                                                                            // 666
   * @param {Object} config  See `registerTestingFramework`.                                                         // 667
   * @private                                                                                                        // 668
   */                                                                                                                // 669
  function _initWatcher (config) {                                                                                   // 670
                                                                                                                     // 671
    _watcher = chokidar.watch(Velocity.getTestsPath(), {ignored: /[\/\\]\./});                                       // 672
                                                                                                                     // 673
    _watcher.on('add', Meteor.bindEnvironment(function (filePath) {                                                  // 674
      var relativePath,                                                                                              // 675
          targetFramework,                                                                                           // 676
          data;                                                                                                      // 677
                                                                                                                     // 678
      filePath = path.normalize(filePath);                                                                           // 679
                                                                                                                     // 680
      DEBUG && console.log('File added:', filePath);                                                                 // 681
                                                                                                                     // 682
      relativePath = filePath.substring(process.env.PWD.length);                                                     // 683
      if (relativePath[0] === path.sep) {                                                                            // 684
        relativePath = relativePath.substring(1);                                                                    // 685
      }                                                                                                              // 686
                                                                                                                     // 687
      // if this is a fixture file, put it in the fixtures collection                                                // 688
      if (FIXTURE_REG_EXP.test(relativePath)) {                                                                      // 689
        VelocityFixtureFiles.insert({                                                                                // 690
          _id: filePath,                                                                                             // 691
          absolutePath: filePath,                                                                                    // 692
          lastModified: Date.now()                                                                                   // 693
        });                                                                                                          // 694
        return;                                                                                                      // 695
      }                                                                                                              // 696
                                                                                                                     // 697
      // test against each test framework's regexp matcher, use first                                                // 698
      // one that matches                                                                                            // 699
      targetFramework = _.find(config, function (framework) {                                                        // 700
        return framework._regexp.test(relativePath);                                                                 // 701
      });                                                                                                            // 702
                                                                                                                     // 703
      if (targetFramework) {                                                                                         // 704
        DEBUG && console.log(targetFramework.name, ' <= ', filePath);                                                // 705
                                                                                                                     // 706
        data = {                                                                                                     // 707
          _id: filePath,                                                                                             // 708
          name: path.basename(filePath),                                                                             // 709
          absolutePath: filePath,                                                                                    // 710
          relativePath: relativePath,                                                                                // 711
          targetFramework: targetFramework.name,                                                                     // 712
          lastModified: Date.now()                                                                                   // 713
        };                                                                                                           // 714
                                                                                                                     // 715
        //DEBUG && console.log('data', data);                                                                        // 716
        VelocityTestFiles.insert(data);                                                                              // 717
      }                                                                                                              // 718
    }));  // end watcher.on 'add'                                                                                    // 719
                                                                                                                     // 720
    _watcher.on('change', Meteor.bindEnvironment(function (filePath) {                                               // 721
      DEBUG && console.log('File changed:', filePath);                                                               // 722
                                                                                                                     // 723
      // Since we key on filePath and we only add files we're interested in,                                         // 724
      // we don't have to worry about inadvertently updating records for files                                       // 725
      // we don't care about.                                                                                        // 726
      VelocityFixtureFiles.update(filePath, { $set: {lastModified: Date.now()}});                                    // 727
      VelocityTestFiles.update(filePath, { $set: {lastModified: Date.now()}});                                       // 728
    }));                                                                                                             // 729
                                                                                                                     // 730
    _watcher.on('unlink', Meteor.bindEnvironment(function (filePath) {                                               // 731
      DEBUG && console.log('File removed:', filePath);                                                               // 732
      // If we only remove the file, we also need to remove the test results for                                     // 733
      // just that file. This required changing the postResult API and we could                                      // 734
      // do it, but the brute force method of reset() will do the trick until we                                     // 735
      // want to optimize VelocityTestFiles.remove(filePath);                                                        // 736
      _reset(config);                                                                                                // 737
    }));                                                                                                             // 738
                                                                                                                     // 739
  }  // end _initWatcher                                                                                             // 740
                                                                                                                     // 741
  /**                                                                                                                // 742
   * Re-init file watcher and clear all test results.                                                                // 743
   *                                                                                                                 // 744
   * @method _reset                                                                                                  // 745
   * @param {Object} config  See `registerTestingFramework`.                                                         // 746
   * @private                                                                                                        // 747
   */                                                                                                                // 748
  function _reset (config) {                                                                                         // 749
    if (_watcher) {                                                                                                  // 750
      _watcher.close();                                                                                              // 751
    }                                                                                                                // 752
                                                                                                                     // 753
    VelocityTestFiles.remove({});                                                                                    // 754
    VelocityFixtureFiles.remove({});                                                                                 // 755
    VelocityFixtureFiles.insert({                                                                                    // 756
      _id: DEFAULT_FIXTURE_PATH,                                                                                     // 757
      absolutePath: DEFAULT_FIXTURE_PATH                                                                             // 758
    });                                                                                                              // 759
    VelocityTestReports.remove({});                                                                                  // 760
    VelocityLogs.remove({});                                                                                         // 761
    VelocityAggregateReports.remove({});                                                                             // 762
    VelocityAggregateReports.insert({                                                                                // 763
      name: 'aggregateResult',                                                                                       // 764
      result: 'pending'                                                                                              // 765
    });                                                                                                              // 766
    VelocityAggregateReports.insert({                                                                                // 767
      name: 'aggregateComplete',                                                                                     // 768
      result: 'pending'                                                                                              // 769
    });                                                                                                              // 770
    _.forEach(_getTestFrameworkNames(), function (testFramework) {                                                   // 771
      VelocityAggregateReports.insert({                                                                              // 772
        name: testFramework,                                                                                         // 773
        result: 'pending'                                                                                            // 774
      });                                                                                                            // 775
    });                                                                                                              // 776
    VelocityMirrors.remove({});                                                                                      // 777
                                                                                                                     // 778
    // Meteor just reloaded us which means we should rsync the app files to the mirror                               // 779
    _syncMirror();                                                                                                   // 780
                                                                                                                     // 781
    _initWatcher(config);                                                                                            // 782
  }                                                                                                                  // 783
                                                                                                                     // 784
  /**                                                                                                                // 785
   * If any one test has failed, mark the aggregate test result as failed.                                           // 786
   *                                                                                                                 // 787
   * @method _updateAggregateReports                                                                                 // 788
   * @private                                                                                                        // 789
   */                                                                                                                // 790
  function _updateAggregateReports () {                                                                              // 791
    //console.log('_updateAggregateReports');                                                                        // 792
    //console.log('VelocityAggregateReports.find().fetch()', VelocityAggregateReports.find().fetch());               // 793
                                                                                                                     // 794
    // lets assuming that the framework wants to aggregate reports                                                   // 795
    // but not hang if it doesn't                                                                                    // 796
    // TODO: remove this try/catch block and replace it with better logic                                            // 797
    //try{                                                                                                           // 798
                                                                                                                     // 799
      var failedResult,                                                                                              // 800
          frameworkResult;                                                                                           // 801
                                                                                                                     // 802
      // if all of our test reports have valid results                                                               // 803
      if (!VelocityTestReports.findOne({result: ''})) {                                                              // 804
        // look through them and see if we find any tests that failed                                                // 805
        failedResult = VelocityTestReports.findOne({result: 'failed'});                                              // 806
                                                                                                                     // 807
        // if any tests failed, set the framework as failed; otherwise set our framework to passed                   // 808
        frameworkResult = failedResult ? 'failed' : 'passed';                                                        // 809
                                                                                                                     // 810
        // update the global status                                                                                  // 811
        VelocityAggregateReports.update({ 'name': 'aggregateResult'}, {$set: {result: frameworkResult}});            // 812
      }                                                                                                              // 813
                                                                                                                     // 814
      // if all test frameworks have completed, upsert an aggregate completed record                                 // 815
      var completedFrameworksCount = VelocityAggregateReports.find({                                                 // 816
        'name': {$in: _getTestFrameworkNames()},                                                                     // 817
        'result': 'completed'                                                                                        // 818
      }).count();                                                                                                    // 819
                                                                                                                     // 820
                                                                                                                     // 821
      // the following syntax is dangerous in case the database is flapping and the cursor hasn't been instantiated  // 822
      // VelocityAggregateReports.findOne({'name': 'aggregateComplete'}).result                                      // 823
                                                                                                                     // 824
      var aggregateComplete = VelocityAggregateReports.findOne({'name': 'aggregateComplete'});                       // 825
      if(aggregateComplete){                                                                                         // 826
        if((aggregateComplete.result !== 'completed') && (_getTestFrameworkNames().length === completedFrameworksCount)){
          VelocityAggregateReports.update({'name': 'aggregateComplete'}, {$set: {'result': 'completed'}});           // 828
                                                                                                                     // 829
          _.each(_postProcessors, function (reporter) {                                                              // 830
            reporter();                                                                                              // 831
          });                                                                                                        // 832
                                                                                                                     // 833
        }                                                                                                            // 834
      }                                                                                                              // 835
    //}catch(error){                                                                                                 // 836
    //  console.log(error)                                                                                           // 837
    //}                                                                                                              // 838
                                                                                                                     // 839
                                                                                                                     // 840
  }                                                                                                                  // 841
                                                                                                                     // 842
  /**                                                                                                                // 843
   * Creates a physical mirror of the application under .meteor/local/.mirror                                        // 844
   *                                                                                                                 // 845
   *     - Any files with the pattern tests/.*  are not copied, this stops .report                                   // 846
   *     directory from also being copied.                                                                           // 847
   *                                                                                                                 // 848
   *     TODO - Strips out velocity, any test packages and reporters from the mirror's .meteor/packages file         // 849
   *                                                                                                                 // 850
   * @method _syncMirror                                                                                             // 851
   * @private                                                                                                        // 852
   */                                                                                                                // 853
  function _syncMirror () {                                                                                          // 854
    var cmd = new Rsync()                                                                                            // 855
      .shell('ssh')                                                                                                  // 856
      .flags('av')                                                                                                   // 857
      .set('delete')                                                                                                 // 858
      .set('q')                                                                                                      // 859
      .set('delay-updates')                                                                                          // 860
      .set('force')                                                                                                  // 861
      .exclude('.meteor/local')                                                                                      // 862
      .exclude('tests/.*')                                                                                           // 863
      .source(process.env.PWD + path.sep)                                                                            // 864
      .destination(Velocity.getMirrorPath());                                                                        // 865
    var then = Date.now();                                                                                           // 866
    cmd.execute(Meteor.bindEnvironment(function (error) {                                                            // 867
                                                                                                                     // 868
      if (error) {                                                                                                   // 869
        DEBUG && console.error('[velocity] Error syncing mirror', error);                                            // 870
      } else {                                                                                                       // 871
        DEBUG && console.log('[velocity] rsync took', Date.now() - then);                                            // 872
      }                                                                                                              // 873
                                                                                                                     // 874
      _.each(_preProcessors, function (preProcessor) {                                                               // 875
        preProcessor();                                                                                              // 876
      });                                                                                                            // 877
                                                                                                                     // 878
      VelocityFixtureFiles.find({}).forEach(function (fixture) {                                                     // 879
        var fixtureLocationInMirror = Velocity.getMirrorPath() + path.sep + path.basename(fixture.absolutePath) + path.extname(fixture.absolutePath);
        DEBUG && console.log('[velocity] copying fixture', fixture.absolutePath, 'to', fixtureLocationInMirror);     // 881
        copyFile(fixture.absolutePath, fixtureLocationInMirror);                                                     // 882
      });                                                                                                            // 883
                                                                                                                     // 884
      // TODO remove this once jasmine and mocha-web are using the velocityStartMirror                               // 885
      Meteor.call('velocityStartMirror', {                                                                           // 886
        name: 'mocha-web',                                                                                           // 887
        port: 5000                                                                                                   // 888
      }, function (e, r) {                                                                                           // 889
        if (e) {                                                                                                     // 890
          console.error('[velocity] mirror failed to start', e);                                                     // 891
        } else {                                                                                                     // 892
          console.log('[velocity] Mirror started', r);                                                               // 893
        }                                                                                                            // 894
      });                                                                                                            // 895
                                                                                                                     // 896
    }));                                                                                                             // 897
  }                                                                                                                  // 898
                                                                                                                     // 899
})();                                                                                                                // 900
                                                                                                                     // 901
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/velocity:core/lib/FileCopier.js                                                                          //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
'use strict';                                                                                                        // 1
                                                                                                                     // 2
var _ = Npm.require('lodash');                                                                                       // 3
var path = Npm.require('path');                                                                                      // 4
var fs = Npm.require('fs-extra');                                                                                    // 5
var removeFile = Meteor._wrapAsync(fs.remove);                                                                       // 6
var copyFile = Meteor._wrapAsync(fs.copy);                                                                           // 7
                                                                                                                     // 8
/**                                                                                                                  // 9
 * Worker that copies test files to the mirror reactively.                                                           // 10
 *                                                                                                                   // 11
 * @class FileCopier                                                                                                 // 12
 * @constructor                                                                                                      // 13
 * @param {object} options                                                                                           // 14
 * @param {string} options.targetFramework The name of the target framework                                          // 15
 *                                         for which the tests should be copied                                      // 16
 *                                         to the mirror.                                                            // 17
 * @param {function} [options.onFileAdded] Callback that is called after a                                           // 18
 *                                         file was added.                                                           // 19
 * @param {function} [options.onFileChanged] Callback that is called after a                                         // 20
 *                                           file has changed.                                                       // 21
 * @param {function} [options.onFileRemoved] Callback that is called after a                                         // 22
 *                                           file was removed.                                                       // 23
 * @param {function} [options.shouldCopy] Control whether a file is copied.                                          // 24
 *                                        Passed the file object from the                                            // 25
 *                                        VelocityTestFiles collection which                                         // 26
 *                                        has a `absolutePath` field.                                                // 27
 *                                        Default: true                                                              // 28
 * @param {function} [options.convertTestPathToMirrorPath] A function that converts the                              // 29
 *                                                         test file path to the mirror path.                        // 30
 *                                                                                                                   // 31
 * @example                                                                                                          // 32
 *     var fileCopier = new Velocity.FileCopier({                                                                    // 33
 *       targetFramework: TEST_FRAMEWORK_NAME                                                                        // 34
 *     });                                                                                                           // 35
 *     fileCopier.start();                                                                                           // 36
 */                                                                                                                  // 37
Velocity.FileCopier = function VelocityFileCopier(options) {                                                         // 38
  check(options, {                                                                                                   // 39
    targetFramework: String,                                                                                         // 40
    onFileAdded: Match.Optional(Function),                                                                           // 41
    onFileChanged: Match.Optional(Function),                                                                         // 42
    onFileRemoved: Match.Optional(Function),                                                                         // 43
    shouldCopy: Match.Optional(Function),                                                                            // 44
    convertTestPathToMirrorPath: Match.Optional(Function)                                                            // 45
  });                                                                                                                // 46
  this.options = _.extend({                                                                                          // 47
    onFileAdded: _.noop,                                                                                             // 48
    onFileChanged: _.noop,                                                                                           // 49
    onFileRemoved: _.noop,                                                                                           // 50
    shouldCopy: function () { return true; },                                                                        // 51
    convertTestPathToMirrorPath: this._defaultConvertTestPathToMirrorPath                                            // 52
  }, options);                                                                                                       // 53
};                                                                                                                   // 54
                                                                                                                     // 55
_.extend(Velocity.FileCopier.prototype, {                                                                            // 56
                                                                                                                     // 57
  /**                                                                                                                // 58
   * Starts copying files to the mirror.                                                                             // 59
   *                                                                                                                 // 60
   * @method start                                                                                                   // 61
   * @memberof Velocity.FileCopier.prototype                                                                         // 62
   */                                                                                                                // 63
  start: function () {                                                                                               // 64
    if (!this._observer) {                                                                                           // 65
      var testFilesCursor = VelocityTestFiles.find({                                                                 // 66
        targetFramework: this.options.targetFramework                                                                // 67
      });                                                                                                            // 68
                                                                                                                     // 69
      this._observer = testFilesCursor.observe({                                                                     // 70
        added: this._onFileAdded.bind(this),                                                                         // 71
        changed: this._onFileChanged.bind(this),                                                                     // 72
        removed: this._onFileRemoved.bind(this)                                                                      // 73
      });                                                                                                            // 74
    }                                                                                                                // 75
  },                                                                                                                 // 76
                                                                                                                     // 77
  /**                                                                                                                // 78
   * Stops copying files to the mirror.                                                                              // 79
   * @memberof Velocity.FileCopier.prototype                                                                         // 80
   */                                                                                                                // 81
  stop: function () {                                                                                                // 82
    this._observer.stop();                                                                                           // 83
    this._observer = null;                                                                                           // 84
  },                                                                                                                 // 85
                                                                                                                     // 86
  _onFileAdded: function (newFile) {                                                                                 // 87
    if (this.options.shouldCopy(newFile)) {                                                                          // 88
      this._replaceFileInMirror(newFile);                                                                            // 89
      this.options.onFileAdded(newFile);                                                                             // 90
    }                                                                                                                // 91
  },                                                                                                                 // 92
                                                                                                                     // 93
  _onFileChanged: function (newFile, oldFile) {                                                                      // 94
    if (this.options.shouldCopy(oldFile)) {                                                                          // 95
      // Remove the oldFile in case the absolutePath has changed                                                     // 96
      this._removeFileFromMirror(oldFile);                                                                           // 97
    }                                                                                                                // 98
    if (this.options.shouldCopy(newFile)) {                                                                          // 99
      this._replaceFileInMirror(newFile);                                                                            // 100
      this.options.onFileAdded(oldFile, newFile);                                                                    // 101
    }                                                                                                                // 102
  },                                                                                                                 // 103
                                                                                                                     // 104
  _onFileRemoved: function (removedFile) {                                                                           // 105
    this._removeFileFromMirror(removedFile);                                                                         // 106
    this.options.onFileRemoved(removedFile);                                                                         // 107
  },                                                                                                                 // 108
                                                                                                                     // 109
  _removeFileFromMirror: function (file) {                                                                           // 110
    var mirrorFilePath = this._convertTestPathToMirrorPath(file.absolutePath);                                       // 111
    DEBUG && console.log('[Velocity.FileCopier] Remove file from mirror', mirrorFilePath);                           // 112
    removeFile(mirrorFilePath);                                                                                      // 113
  },                                                                                                                 // 114
                                                                                                                     // 115
  _replaceFileInMirror: function (file) {                                                                            // 116
    var self = this;                                                                                                 // 117
                                                                                                                     // 118
    var mirrorFilePath = self._convertTestPathToMirrorPath(file.absolutePath);                                       // 119
    DEBUG && console.log('[Velocity.FileCopier] Replace file in mirror', mirrorFilePath);                            // 120
    copyFile(file.absolutePath, mirrorFilePath);                                                                     // 121
  },                                                                                                                 // 122
                                                                                                                     // 123
  _isInTestsPath: function _isInTestsPath(filePath) {                                                                // 124
    var testsPath = Velocity.getTestsPath();                                                                         // 125
    return filePath.substr(0, testsPath.length) === testsPath;                                                       // 126
  },                                                                                                                 // 127
                                                                                                                     // 128
  _convertTestPathToMirrorPath: function (filePath) {                                                                // 129
    if (!this._isInTestsPath(filePath)) {                                                                            // 130
      throw new Error('[Velocity.FileCopier] Path "' + filePath + '" is not in the tests path.');                    // 131
    }                                                                                                                // 132
                                                                                                                     // 133
    filePath = filePath.substr(Velocity.getTestsPath().length);                                                      // 134
    filePath = this.options.convertTestPathToMirrorPath.call(this, filePath);                                        // 135
                                                                                                                     // 136
    return Velocity.getMirrorPath() + filePath;                                                                      // 137
  },                                                                                                                 // 138
                                                                                                                     // 139
  _defaultConvertTestPathToMirrorPath: function (filePath) {                                                         // 140
    var targetFramework = this.options.targetFramework;                                                              // 141
    filePath = filePath.replace(targetFramework + '/client', 'client/' + targetFramework);                           // 142
    filePath = filePath.replace(targetFramework + '/server', 'server/' + targetFramework);                           // 143
                                                                                                                     // 144
    return filePath                                                                                                  // 145
  }                                                                                                                  // 146
});                                                                                                                  // 147
                                                                                                                     // 148
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['velocity:core'] = {
  Velocity: Velocity,
  VelocityTestFiles: VelocityTestFiles,
  VelocityFixtureFiles: VelocityFixtureFiles,
  VelocityTestReports: VelocityTestReports,
  VelocityAggregateReports: VelocityAggregateReports,
  VelocityLogs: VelocityLogs,
  VelocityMirrors: VelocityMirrors
};

})();

//# sourceMappingURL=velocity_core.js.map
