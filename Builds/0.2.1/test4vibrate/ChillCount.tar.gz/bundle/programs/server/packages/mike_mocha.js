(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Velocity = Package['velocity:core'].Velocity;
var VelocityTestFiles = Package['velocity:core'].VelocityTestFiles;
var VelocityFixtureFiles = Package['velocity:core'].VelocityFixtureFiles;
var VelocityTestReports = Package['velocity:core'].VelocityTestReports;
var VelocityAggregateReports = Package['velocity:core'].VelocityAggregateReports;
var VelocityLogs = Package['velocity:core'].VelocityLogs;
var VelocityMirrors = Package['velocity:core'].VelocityMirrors;

/* Package-scope variables */
var MochaWeb, MeteorCollectionTestReporter, TEST_FRAMEWORK_NAME, ddpParentConnection, wrappedFunc, boundWrappedFunction;

(function () {

///////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                           //
// packages/mike:mocha/reporter.js                                                           //
//                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////
                                                                                             //
MochaWeb = {};                                                                               // 1
                                                                                             // 2
if (Meteor.isServer)                                                                         // 3
  var Base = Npm.require("mocha/lib/reporters").Base;                                        // 4
else                                                                                         // 5
  Base = Mocha.reporters.Base                                                                // 6
                                                                                             // 7
function getAncestors(testObject, ancestors){                                                // 8
  if (!ancestors)                                                                            // 9
    ancestors = []                                                                           // 10
  if (testObject.parent && testObject.parent.title !== ""){                                  // 11
    ancestors.push(testObject.parent.title)                                                  // 12
    return getAncestors(testObject.parent, ancestors);                                       // 13
  }                                                                                          // 14
  else{                                                                                      // 15
    return ancestors;                                                                        // 16
  }                                                                                          // 17
};                                                                                           // 18
                                                                                             // 19
MochaWeb.MeteorCollectionTestReporter = function(runner){                                    // 20
  Base.call(this, runner);                                                                   // 21
  var self = this;                                                                           // 22
                                                                                             // 23
  function saveTestResult(test){                                                             // 24
    if (test.state === "failed"){                                                            // 25
      console.log(test.err.message);                                                         // 26
      console.log(test.err.stack);                                                           // 27
    }                                                                                        // 28
                                                                                             // 29
    // console.log("SAVE TEST RESULT", test);                                                // 30
                                                                                             // 31
    var ancestors = getAncestors(test);                                                      // 32
    var result = {                                                                           // 33
      id: "mocha:" + ancestors.join(":") + ":" + test.title,                                 // 34
      async: !!test.async,                                                                   // 35
      framework: "mocha",                                                                    // 36
      name: test.title,                                                                      // 37
      pending: test.pending,                                                                 // 38
      result: test.state,                                                                    // 39
      time: test.duration,                                                                   // 40
      timeOut: test._timeout,                                                                // 41
      timedOut: test.timedOut,                                                               // 42
      ancestors: ancestors,                                                                  // 43
      isClient: Meteor.isClient,                                                             // 44
      isServer: Meteor.isServer,                                                             // 45
      timestamp: new Date()                                                                  // 46
    };                                                                                       // 47
    if (test.err){                                                                           // 48
      result.failureMessage = test.err.message;                                              // 49
      result.failureStackTrace = test.err.stack;                                             // 50
    }                                                                                        // 51
    // console.log("POSTING RESULT", result);                                                // 52
                                                                                             // 53
    ddpParentConnection.call("postResult", result, function(error, result){                  // 54
      if (error){                                                                            // 55
        console.error("ERROR WRITING TEST", error);                                          // 56
      }                                                                                      // 57
    });                                                                                      // 58
  }                                                                                          // 59
                                                                                             // 60
  runner.on("start", Meteor.bindEnvironment(                                                 // 61
    function(){                                                                              // 62
      //TODO tell testRunner that mocha tests have started                                   // 63
    },                                                                                       // 64
    function(err){                                                                           // 65
      throw err;                                                                             // 66
    }                                                                                        // 67
  ));                                                                                        // 68
                                                                                             // 69
  ["pass", "fail", "pending"].forEach(function(testEvent){                                   // 70
    runner.on(testEvent, Meteor.bindEnvironment(                                             // 71
      function(test){                                                                        // 72
        saveTestResult(test);                                                                // 73
      },                                                                                     // 74
      function(err){                                                                         // 75
        throw err;                                                                           // 76
      }                                                                                      // 77
    ));                                                                                      // 78
  });                                                                                        // 79
                                                                                             // 80
  runner.on('end', Meteor.bindEnvironment(function(){                                        // 81
    //TODO tell testRunner all mocha web tests have finished                                 // 82
  }, function(err){                                                                          // 83
    throw err;                                                                               // 84
  }));                                                                                       // 85
};                                                                                           // 86
                                                                                             // 87
///////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                           //
// packages/mike:mocha/server.js                                                             //
//                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////
                                                                                             //
TEST_FRAMEWORK_NAME = "mocha";                                                               // 1
                                                                                             // 2
if (!process.env.NODE_ENV === "development"){                                                // 3
  console.log("process.env.NODE ENV != DEVELOPMENT, TESTS WILL NOT BE RAN");                 // 4
}                                                                                            // 5
else {                                                                                       // 6
  if (Velocity && Velocity.registerTestingFramework){                                        // 7
    Velocity.registerTestingFramework(TEST_FRAMEWORK_NAME, {                                 // 8
      regex: 'mocha/.+\\.(js|coffee|litcoffee|coffee\\.md)$',                                // 9
      sampleTestGenerator: function(){                                                       // 10
        return [                                                                             // 11
          { path: "mocha/client/sampleClientTest.js",                                        // 12
            contents: Assets.getText("sample-tests/client.js")                               // 13
          },                                                                                 // 14
          { path: "mocha/server/sampleServerTest.js",                                        // 15
            contents: Assets.getText("sample-tests/server.js")}                              // 16
        ];                                                                                   // 17
      }                                                                                      // 18
    });                                                                                      // 19
  }                                                                                          // 20
                                                                                             // 21
  var clientTestsComplete = false;                                                           // 22
  var serverTestsComplete = false;                                                           // 23
                                                                                             // 24
  var Mocha = Npm.require("mocha");                                                          // 25
  var Fiber = Npm.require("fibers");                                                         // 26
  var _ = Npm.require("underscore");                                                         // 27
  var childProcess = Npm.require('child_process');                                           // 28
  var path = Npm.require('path');                                                            // 29
  var mkdirp = Npm.require("mkdirp");                                                        // 30
                                                                                             // 31
  ddpParentConnection = null;                                                                // 32
  var parentUrl = null;                                                                      // 33
  var childUrl = null;                                                                       // 34
                                                                                             // 35
  Meteor.startup(function(){                                                                 // 36
    if (process.env.IS_MIRROR) {                                                             // 37
      console.log("MOCHA-WEB MIRROR LISTENING AT", process.env.ROOT_URL);                    // 38
      parentUrl = process.env.PARENT_URL;                                                    // 39
      console.log("PARENT URL", process.env.PARENT_URL);                                     // 40
      ddpParentConnection = DDP.connect(parentUrl);                                          // 41
      console.log("Running mocha server tests");                                             // 42
      mocha.run(function(err){                                                               // 43
        serverTestsComplete = true;                                                          // 44
        if (clientTestsComplete){                                                            // 45
          markTestsComplete();                                                               // 46
        }                                                                                    // 47
      });                                                                                    // 48
    }                                                                                        // 49
  });                                                                                        // 50
                                                                                             // 51
  function markTestsComplete(){                                                              // 52
    ddpParentConnection.call("completed", {framework: "mocha"}, function(err){               // 53
      if (err){                                                                              // 54
        console.error("error calling testsComplete function", err);                          // 55
      }                                                                                      // 56
    });                                                                                      // 57
  }                                                                                          // 58
                                                                                             // 59
  Meteor.methods({                                                                           // 60
    "mirrorInfo": function(){                                                                // 61
      return {                                                                               // 62
        isMirror: process.env.IS_MIRROR,                                                     // 63
        parentUrl: process.env.PARENT_URL                                                    // 64
      }                                                                                      // 65
    },                                                                                       // 66
                                                                                             // 67
    "clientTestsComplete": function(){                                                       // 68
      // console.log("CLIENT TESTS COMPLETE");                                               // 69
      clientTestsComplete = true;                                                            // 70
      if (serverTestsComplete){                                                              // 71
        markTestsComplete();                                                                 // 72
      }                                                                                      // 73
    }                                                                                        // 74
  })                                                                                         // 75
                                                                                             // 76
  //if not a mirror don't do anything                                                        // 77
  MochaWeb.testOnly = function(callback){                                                    // 78
    // console.log("NO OP", mirror.isMirror);                                                // 79
  };                                                                                         // 80
                                                                                             // 81
  setupMocha();                                                                              // 82
                                                                                             // 83
  function setupMocha(){                                                                     // 84
    if (! process.env.IS_MIRROR)                                                             // 85
      return;                                                                                // 86
    // console.log("Enabling MochaWeb.testOnly");                                            // 87
    //only when mocha has been explicity enabled (in a mirror)                               // 88
    //do we run the tests                                                                    // 89
    MochaWeb.testOnly = function(callback){                                                  // 90
      callback();                                                                            // 91
    }                                                                                        // 92
                                                                                             // 93
    global.chai = Npm.require("chai");                                                       // 94
    // enable stack trace with line numbers with assertions                                  // 95
    global.chai.Assertion.includeStack = true;                                               // 96
    global.mocha = new Mocha({ui: "bdd", reporter: MochaWeb.MeteorCollectionTestReporter});  // 97
    console.log("SETUP GLOBALS");                                                            // 98
    setupGlobals();                                                                          // 99
  }                                                                                          // 100
                                                                                             // 101
  function setupGlobals(){                                                                   // 102
    //basically a direct copy from meteor/packages/meteor/dynamics_nodejs.js                 // 103
    //except the wrapped function has an argument (mocha distinguishes                       // 104
    //asynchronous tests from synchronous ones by the "length" of the                        // 105
    //function passed into it, before, etc.)                                                 // 106
    var moddedBindEnvironment = function (func, onException, _this) {                        // 107
      if (!Fiber.current)                                                                    // 108
        throw new Error(noFiberMessage);                                                     // 109
                                                                                             // 110
      var boundValues = _.clone(Fiber.current._meteor_dynamics || []);                       // 111
                                                                                             // 112
      if (!onException || typeof(onException) === 'string') {                                // 113
        var description = onException || "callback of async function";                       // 114
        onException = function (error) {                                                     // 115
          Meteor._debug(                                                                     // 116
            "Exception in " + description + ":",                                             // 117
            error && error.stack || error                                                    // 118
          );                                                                                 // 119
        };                                                                                   // 120
      }                                                                                      // 121
                                                                                             // 122
      //note the callback variable present here                                              // 123
      return function (callback) {                                                           // 124
        var args = _.toArray(arguments);                                                     // 125
                                                                                             // 126
        var runWithEnvironment = function () {                                               // 127
          var savedValues = Fiber.current._meteor_dynamics;                                  // 128
          try {                                                                              // 129
            // Need to clone boundValues in case two fibers invoke this                      // 130
            // function at the same time                                                     // 131
            Fiber.current._meteor_dynamics = _.clone(boundValues);                           // 132
            var ret = func.apply(_this, args);                                               // 133
          } catch (e) {                                                                      // 134
            onException(e);                                                                  // 135
          } finally {                                                                        // 136
            Fiber.current._meteor_dynamics = savedValues;                                    // 137
          }                                                                                  // 138
          return ret;                                                                        // 139
        };                                                                                   // 140
                                                                                             // 141
        if (Fiber.current)                                                                   // 142
          return runWithEnvironment();                                                       // 143
        Fiber(runWithEnvironment).run();                                                     // 144
      };                                                                                     // 145
    };                                                                                       // 146
                                                                                             // 147
                                                                                             // 148
    var mochaExports = {};                                                                   // 149
    mocha.suite.emit("pre-require", mochaExports);                                           // 150
    //console.log(mochaExports);                                                             // 151
                                                                                             // 152
    //patch up describe function so it plays nice w/ fibers                                  // 153
    global.describe = function (name, func){                                                 // 154
      mochaExports.describe(name, Meteor.bindEnvironment(func, function(err){throw err; })); // 155
    };                                                                                       // 156
                                                                                             // 157
    //In Meteor, these blocks will all be invoking Meteor code and must                      // 158
    //run within a fiber. We must therefore wrap each with something like                    // 159
    //bindEnvironment. The function passed off to mocha must have length                     // 160
    //greater than zero if we want mocha to run it asynchronously. That's                    // 161
    //why it uses the moddedBindEnivronment function described above instead                 // 162
                                                                                             // 163
    //We're actually having mocha run all tests asynchronously. This                         // 164
    //is because mocha cannot tell when a synchronous fiber test has                         // 165
    //finished, because the test runner runs outside a fiber.                                // 166
                                                                                             // 167
    //It is possible that the mocha test runner could be run from within a                   // 168
    //fiber, but it was unclear to me how that could be done without                         // 169
    //forking mocha itself.                                                                  // 170
                                                                                             // 171
    global['it'] = function (name, func){                                                    // 172
      wrappedFunc = function(callback){                                                      // 173
        if (func.length == 0){                                                               // 174
          func();                                                                            // 175
          callback();                                                                        // 176
        }                                                                                    // 177
        else {                                                                               // 178
          func(callback);                                                                    // 179
        }                                                                                    // 180
      }                                                                                      // 181
                                                                                             // 182
      boundWrappedFunction = moddedBindEnvironment(wrappedFunc, function(err){               // 183
        throw err;                                                                           // 184
      });                                                                                    // 185
                                                                                             // 186
      mochaExports['it'](name, boundWrappedFunction);                                        // 187
    };                                                                                       // 188
                                                                                             // 189
    ["before", "beforeEach", "after", "afterEach"].forEach(function(testFunctionName){       // 190
      global[testFunctionName] = function (func){                                            // 191
        wrappedFunc = function(callback){                                                    // 192
          if (func.length == 0){                                                             // 193
            func();                                                                          // 194
            callback();                                                                      // 195
          }                                                                                  // 196
          else {                                                                             // 197
            func(callback);                                                                  // 198
          }                                                                                  // 199
        }                                                                                    // 200
                                                                                             // 201
        boundWrappedFunction = moddedBindEnvironment(wrappedFunc, function(err){             // 202
          throw err;                                                                         // 203
        });                                                                                  // 204
        mochaExports[testFunctionName](boundWrappedFunction);                                // 205
      }                                                                                      // 206
    });                                                                                      // 207
  }                                                                                          // 208
  function copyTestsToMirror(file){                                                          // 209
    Meteor.call("resetReports", {framework: "mocha"}, function(){                            // 210
      var relativeDest = file.relativePath.split(path.sep).splice(1).join(path.sep);         // 211
      var mirrorPath = path.join(process.env.PWD, ".meteor", "local", ".mirror");            // 212
      var dest = path.join(mirrorPath, relativeDest);                                        // 213
      mkdirp.sync(dest);                                                                     // 214
      var cmd = "cp " +  file.absolutePath + " " + dest;                                     // 215
      childProcess.exec(cmd, function(err){                                                  // 216
        if (err) {                                                                           // 217
          console.error(err);                                                                // 218
        }                                                                                    // 219
      });                                                                                    // 220
    });                                                                                      // 221
  }                                                                                          // 222
                                                                                             // 223
  Meteor.startup(function(){                                                                 // 224
    VelocityTestFiles.find({targetFramework: 'mocha'}).observe({                             // 225
      added: copyTestsToMirror,                                                              // 226
      changed: copyTestsToMirror,                                                            // 227
      removed: copyTestsToMirror                                                             // 228
    });                                                                                      // 229
  })                                                                                         // 230
}                                                                                            // 231
                                                                                             // 232
///////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mike:mocha'] = {
  MochaWeb: MochaWeb,
  MeteorCollectionTestReporter: MeteorCollectionTestReporter
};

})();

//# sourceMappingURL=mike_mocha.js.map
