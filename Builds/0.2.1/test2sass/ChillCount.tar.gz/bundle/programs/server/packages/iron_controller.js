(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var _ = Package.underscore._;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var ReactiveDict = Package['reactive-dict'].ReactiveDict;
var Iron = Package['iron:core'].Iron;

/* Package-scope variables */
var Controller;

(function () {

//////////////////////////////////////////////////////////////////////////////////////
//                                                                                  //
// packages/iron:controller/lib/controller.js                                       //
//                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////
                                                                                    //
/*****************************************************************************/     // 1
/* Imports */                                                                       // 2
/*****************************************************************************/     // 3
var debug = Iron.utils.debug('iron:controller');                                    // 4
var Layout = Iron.Layout;                                                           // 5
                                                                                    // 6
/*****************************************************************************/     // 7
/* Private */                                                                       // 8
/*****************************************************************************/     // 9
var bindData = function (value, thisArg) {                                          // 10
  return function () {                                                              // 11
    return (typeof value === 'function') ? value.apply(thisArg, arguments) : value; // 12
  };                                                                                // 13
};                                                                                  // 14
                                                                                    // 15
/*****************************************************************************/     // 16
/* Controller */                                                                    // 17
/*****************************************************************************/     // 18
Controller = function (options) {                                                   // 19
  var self = this;                                                                  // 20
  this.options = options || {};                                                     // 21
  this._layout = this.options.layout || new Layout(this.options);                   // 22
  this._layout.setController(this);                                                 // 23
                                                                                    // 24
  // grab the event map from the Controller constructor which was                   // 25
  // set if the user does MyController.events({...});                               // 26
  this._layout.events(this.constructor._eventMap, this);                            // 27
                                                                                    // 28
  this.init(options);                                                               // 29
};                                                                                  // 30
                                                                                    // 31
/**                                                                                 // 32
 * Set or get the layout's template and optionally its data context.                // 33
 */                                                                                 // 34
Controller.prototype.layout = function (template, options) {                        // 35
  var result = this._layout.template(template);                                     // 36
                                                                                    // 37
  // check whether options has a data property                                      // 38
  if (options && (_.has(options, 'data')))                                          // 39
    this._layout.data(bindData(options.data, this));                                // 40
                                                                                    // 41
  return result;                                                                    // 42
};                                                                                  // 43
                                                                                    // 44
/**                                                                                 // 45
 * Render a template into a region of the layout.                                   // 46
 */                                                                                 // 47
Controller.prototype.render = function (template, options) {                        // 48
  if (options && (typeof options.data !== 'undefined'))                             // 49
    options.data = bindData(options.data, this);                                    // 50
  return this._layout.render(template, options);                                    // 51
};                                                                                  // 52
                                                                                    // 53
/**                                                                                 // 54
 * Begin recording rendered regions.                                                // 55
 */                                                                                 // 56
Controller.prototype.beginRendering = function (onComplete) {                       // 57
  return this._layout.beginRendering(onComplete);                                   // 58
};                                                                                  // 59
                                                                                    // 60
/*****************************************************************************/     // 61
/* Controller Static Methods */                                                     // 62
/*****************************************************************************/     // 63
/**                                                                                 // 64
 * Inherit from Controller.                                                         // 65
 *                                                                                  // 66
 * Note: The inheritance function in Meteor._inherits is broken. Static             // 67
 * properties on functions don't get copied.                                        // 68
 */                                                                                 // 69
Controller.extend = function (props) {                                              // 70
  return Iron.utils.extend(this, props);                                            // 71
};                                                                                  // 72
                                                                                    // 73
Controller.events = function (events) {                                             // 74
  this._eventMap = events;                                                          // 75
  return this;                                                                      // 76
};                                                                                  // 77
                                                                                    // 78
/*****************************************************************************/     // 79
/* Global Helpers */                                                                // 80
/*****************************************************************************/     // 81
                                                                                    // 82
/**                                                                                 // 83
 * Returns the nearest controller for a template instance. You can call this        // 84
 * function from inside a template helper.                                          // 85
 *                                                                                  // 86
 * Example:                                                                         // 87
 * Template.MyPage.helpers({                                                        // 88
 *   greeting: function () {                                                        // 89
 *    var controller = Iron.controller();                                           // 90
 *    return controller.get('greeting');                                            // 91
 *   }                                                                              // 92
 * });                                                                              // 93
 */                                                                                 // 94
Iron.controller = function () {                                                     // 95
  var view = UI.getView();                                                          // 96
                                                                                    // 97
  if (!view)                                                                        // 98
    throw new Error("No view found.");                                              // 99
                                                                                    // 100
  while (view) {                                                                    // 101
    // find the first view that has a controller assigned to it.                    // 102
    // if we find one, return its value reactively so that if it                    // 103
    // changes, any helpers that use it will be invalidated on the                  // 104
    // change.                                                                      // 105
    if (view.__dynamicTemplate__ && view.__dynamicTemplate__.hasController())       // 106
      return view.__dynamicTemplate__.getController();                              // 107
    else                                                                            // 108
      view = view.parentView;                                                       // 109
  }                                                                                 // 110
                                                                                    // 111
  debug("No Iron.controller()");                                                    // 112
  return null;                                                                      // 113
};                                                                                  // 114
                                                                                    // 115
/*****************************************************************************/     // 116
/* Namespacing */                                                                   // 117
/*****************************************************************************/     // 118
Iron.Controller = Controller;                                                       // 119
                                                                                    // 120
//////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////
//                                                                                  //
// packages/iron:controller/lib/controller_server.js                                //
//                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////
                                                                                    //
Controller.prototype.init = function () {};                                         // 1
                                                                                    // 2
// futures somehow. but not clear exactly what this means.                          // 3
Controller.prototype.wait = function () {                                           // 4
  throw new Error('Not implemented on server yet.');                                // 5
};                                                                                  // 6
                                                                                    // 7
// is future ready?                                                                 // 8
Controller.prototype.ready = function () {                                          // 9
  throw new Error('Not implemented on server yet.');                                // 10
};                                                                                  // 11
                                                                                    // 12
//////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['iron:controller'] = {};

})();

//# sourceMappingURL=iron_controller.js.map
