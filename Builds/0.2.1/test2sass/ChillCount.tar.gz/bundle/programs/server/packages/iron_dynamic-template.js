(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var _ = Package.underscore._;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var ReactiveVar = Package['reactive-var'].ReactiveVar;
var Iron = Package['iron:core'].Iron;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var DynamicTemplate, findFirstLookupHostWithProperty;

(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/iron:dynamic-template/version_conflict_error.js                                                       //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
if (Package['cmather:iron-dynamic-template']) {                                                                   // 1
  throw new Error("\n\n\
    Sorry! The cmather:iron-{x} packages were migrated to the new package system with the wrong name, and you have duplicate copies.\n\
    You can see which cmather:iron-{x} packages have been installed by using this command:\n\n\
    > meteor list\n\n\
    Can you remove any installed cmather:iron-{x} packages like this:\
    \n\n\
    > meteor remove cmather:iron-core\n\
    > meteor remove cmather:iron-router\n\
    > meteor remove cmather:iron-dynamic-template\n\
    > meteor remove cmather:iron-dynamic-layout\n\
    \n\
    The new packages are named iron:{x}. For example:\n\n\
    > meteor add iron:router\n\n\
    Sorry for the hassle, but thank you!\
    \n\n\
  ");                                                                                                             // 17
                                                                                                                  // 18
}                                                                                                                 // 19
                                                                                                                  // 20
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/iron:dynamic-template/dynamic_template.js                                                             //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/*****************************************************************************/                                   // 1
/* Imports */                                                                                                     // 2
/*****************************************************************************/                                   // 3
var debug = Iron.utils.debug('iron:dynamic-template');                                                            // 4
var assert = Iron.utils.assert;                                                                                   // 5
var camelCase = Iron.utils.camelCase;                                                                             // 6
                                                                                                                  // 7
/*****************************************************************************/                                   // 8
/* Private */                                                                                                     // 9
/*****************************************************************************/                                   // 10
var typeOf = function (value) {                                                                                   // 11
  return Object.prototype.toString.call(value);                                                                   // 12
};                                                                                                                // 13
                                                                                                                  // 14
/*****************************************************************************/                                   // 15
/* DynamicTemplate */                                                                                             // 16
/*****************************************************************************/                                   // 17
                                                                                                                  // 18
/**                                                                                                               // 19
 * Render a component to the page whose template and data context can change                                      // 20
 * dynamically, either from code or from helpers.                                                                 // 21
 *                                                                                                                // 22
 */                                                                                                               // 23
DynamicTemplate = function (options) {                                                                            // 24
  this.options = options = options || {};                                                                         // 25
  this._template = options.template;                                                                              // 26
  this._defaultTemplate = options.defaultTemplate;                                                                // 27
  this._content = options.content;                                                                                // 28
  this._data = options.data;                                                                                      // 29
  this._templateDep = new Tracker.Dependency;                                                                     // 30
  this._dataDep = new Tracker.Dependency;                                                                         // 31
  this._hasControllerDep = new Tracker.Dependency;                                                                // 32
  this._hooks = {};                                                                                               // 33
  this._eventMap = null;                                                                                          // 34
  this._eventHandles = null;                                                                                      // 35
  this._eventThisArg = null;                                                                                      // 36
  this._controller = new ReactiveVar;                                                                             // 37
  this.name = options.name || this.constructor.name || 'DynamicTemplate';                                         // 38
                                                                                                                  // 39
  // has the Blaze.View been created?                                                                             // 40
  this.isCreated = false;                                                                                         // 41
                                                                                                                  // 42
  // has the Blaze.View been destroyed and not created again?                                                     // 43
  this.isDestroyed = false;                                                                                       // 44
};                                                                                                                // 45
                                                                                                                  // 46
/**                                                                                                               // 47
 * Get or set the template.                                                                                       // 48
 */                                                                                                               // 49
DynamicTemplate.prototype.template = function (value) {                                                           // 50
  if (arguments.length === 1 && value !== this._template) {                                                       // 51
    this._template = value;                                                                                       // 52
    this._templateDep.changed();                                                                                  // 53
    return;                                                                                                       // 54
  }                                                                                                               // 55
                                                                                                                  // 56
  if (arguments.length > 0)                                                                                       // 57
    return;                                                                                                       // 58
                                                                                                                  // 59
  this._templateDep.depend();                                                                                     // 60
                                                                                                                  // 61
  // do we have a template?                                                                                       // 62
  if (this._template)                                                                                             // 63
    return (typeof this._template === 'function') ? this._template() : this._template;                            // 64
                                                                                                                  // 65
  // no template? ok let's see if we have a default one set                                                       // 66
  if (this._defaultTemplate)                                                                                      // 67
    return (typeof this._defaultTemplate === 'function') ? this._defaultTemplate() : this._defaultTemplate;       // 68
};                                                                                                                // 69
                                                                                                                  // 70
/**                                                                                                               // 71
 * Get or set the default template.                                                                               // 72
 *                                                                                                                // 73
 * This function does not change any dependencies.                                                                // 74
 */                                                                                                               // 75
DynamicTemplate.prototype.defaultTemplate = function (value) {                                                    // 76
  if (arguments.length === 1)                                                                                     // 77
    this._defaultTemplate = value;                                                                                // 78
  else                                                                                                            // 79
    return this._defaultTemplate;                                                                                 // 80
};                                                                                                                // 81
                                                                                                                  // 82
/**                                                                                                               // 83
 * Clear the template and data contexts.                                                                          // 84
 */                                                                                                               // 85
DynamicTemplate.prototype.clear = function () {                                                                   // 86
  //XXX do we need to clear dependencies here too?                                                                // 87
  this._template = undefined;                                                                                     // 88
  this._data = undefined;                                                                                         // 89
  this._templateDep.changed();                                                                                    // 90
};                                                                                                                // 91
                                                                                                                  // 92
/**                                                                                                               // 93
 * Get or set the data context.                                                                                   // 94
 */                                                                                                               // 95
DynamicTemplate.prototype.data = function (value) {                                                               // 96
  if (arguments.length === 1 && value !== this._data) {                                                           // 97
    this._data = value;                                                                                           // 98
    this._dataDep.changed();                                                                                      // 99
    return;                                                                                                       // 100
  }                                                                                                               // 101
                                                                                                                  // 102
  this._dataDep.depend();                                                                                         // 103
  return typeof this._data === 'function' ? this._data() : this._data;                                            // 104
};                                                                                                                // 105
                                                                                                                  // 106
/**                                                                                                               // 107
 * Create the view if it hasn't been created yet.                                                                 // 108
 */                                                                                                               // 109
DynamicTemplate.prototype.create = function (options) {                                                           // 110
  var self = this;                                                                                                // 111
                                                                                                                  // 112
  if (this.isCreated) {                                                                                           // 113
    throw new Error("DynamicTemplate view is already created");                                                   // 114
  }                                                                                                               // 115
                                                                                                                  // 116
  this.isCreated = true;                                                                                          // 117
  this.isDestroyed = false;                                                                                       // 118
                                                                                                                  // 119
  var templateVar = ReactiveVar(null);                                                                            // 120
                                                                                                                  // 121
  var view = Blaze.View('DynamicTemplate', function () {                                                          // 122
    var thisView = this;                                                                                          // 123
                                                                                                                  // 124
    // create the template dependency here because we need the entire                                             // 125
    // dynamic template to re-render if the template changes, including                                           // 126
    // the Blaze.With view.                                                                                       // 127
    var template = templateVar.get();                                                                             // 128
                                                                                                                  // 129
    return Blaze.With(function () {                                                                               // 130
      // NOTE: This will rerun anytime the data function invalidates this                                         // 131
      // computation OR if created from an inclusion helper (see note below) any                                  // 132
      // time any of the argument functions invlidate the computation. For                                        // 133
      // example, when the template changes this function will rerun also. But                                    // 134
      // it's probably generally ok. The more serious use case is to not                                          // 135
      // re-render the entire template every time the data context changes.                                       // 136
      var result = self.data();                                                                                   // 137
                                                                                                                  // 138
      if (typeof result !== 'undefined')                                                                          // 139
        // looks like data was set directly on this dynamic template                                              // 140
        return result;                                                                                            // 141
      else                                                                                                        // 142
        // return the first parent data context that is not inclusion arguments                                   // 143
        return DynamicTemplate.getParentDataContext(thisView);                                                    // 144
    }, function () {                                                                                              // 145
      // NOTE: When DynamicTemplate is used from a template inclusion helper                                      // 146
      // like this {{> DynamicTemplate template=getTemplate data=getData}} the                                    // 147
      // function below will rerun any time the getData function invalidates the                                  // 148
      // argument data computation.                                                                               // 149
      var tmpl = null;                                                                                            // 150
                                                                                                                  // 151
      // is it a template name like "MyTemplate"?                                                                 // 152
      if (typeof template === 'string') {                                                                         // 153
        tmpl = Template[template];                                                                                // 154
                                                                                                                  // 155
        if (!tmpl)                                                                                                // 156
          // as a fallback double check the user didn't actually define                                           // 157
          // a camelCase version of the template.                                                                 // 158
          tmpl = Template[camelCase(template)];                                                                   // 159
                                                                                                                  // 160
        if (!tmpl) {                                                                                              // 161
          tmpl = Blaze.With({                                                                                     // 162
            msg: "Couldn't find a template named " + JSON.stringify(template) + " or " + JSON.stringify(camelCase(template))+ ". Are you sure you defined it?"
          }, function () {                                                                                        // 164
            return Template.__DynamicTemplateError__;                                                             // 165
          });                                                                                                     // 166
        }                                                                                                         // 167
      } else if (typeOf(template) === '[object Object]') {                                                        // 168
        // or maybe a view already?                                                                               // 169
        tmpl = template;                                                                                          // 170
      } else if (typeof self._content !== 'undefined') {                                                          // 171
        // or maybe its block content like                                                                        // 172
        // {{#DynamicTemplate}}                                                                                   // 173
        //  Some block                                                                                            // 174
        // {{/DynamicTemplate}}                                                                                   // 175
        tmpl = self._content;                                                                                     // 176
      }                                                                                                           // 177
                                                                                                                  // 178
      return tmpl;                                                                                                // 179
    });                                                                                                           // 180
  });                                                                                                             // 181
                                                                                                                  // 182
  view.onViewCreated(function () {                                                                                // 183
    this.autorun(function () {                                                                                    // 184
      templateVar.set(self.template());                                                                           // 185
    });                                                                                                           // 186
  });                                                                                                             // 187
                                                                                                                  // 188
  // wire up the view lifecycle callbacks                                                                         // 189
  _.each(['onViewCreated', 'onViewReady', '_onViewRendered', 'onViewDestroyed'], function (hook) {                // 190
    view[hook](function () {                                                                                      // 191
      // "this" is the view instance                                                                              // 192
      self._runHooks(hook, this);                                                                                 // 193
    });                                                                                                           // 194
  });                                                                                                             // 195
                                                                                                                  // 196
  view._onViewRendered(function () {                                                                              // 197
    // avoid inserting the view twice by accident.                                                                // 198
    self.isInserted = true;                                                                                       // 199
                                                                                                                  // 200
    if (view.renderCount !== 1)                                                                                   // 201
      return;                                                                                                     // 202
                                                                                                                  // 203
    self._attachEvents();                                                                                         // 204
  });                                                                                                             // 205
                                                                                                                  // 206
  view._templateInstance = new Blaze.TemplateInstance(view);                                                      // 207
  view.templateInstance = function () {                                                                           // 208
    // Update data, firstNode, and lastNode, and return the TemplateInstance                                      // 209
    // object.                                                                                                    // 210
    var inst = view._templateInstance;                                                                            // 211
                                                                                                                  // 212
    inst.data = Blaze.getData(view);                                                                              // 213
                                                                                                                  // 214
    if (view._domrange && !view.isDestroyed) {                                                                    // 215
      inst.firstNode = view._domrange.firstNode();                                                                // 216
      inst.lastNode = view._domrange.lastNode();                                                                  // 217
    } else {                                                                                                      // 218
      // on 'created' or 'destroyed' callbacks we don't have a DomRange                                           // 219
      inst.firstNode = null;                                                                                      // 220
      inst.lastNode = null;                                                                                       // 221
    }                                                                                                             // 222
                                                                                                                  // 223
    return inst;                                                                                                  // 224
  };                                                                                                              // 225
                                                                                                                  // 226
  this.view = view;                                                                                               // 227
  view.__dynamicTemplate__ = this;                                                                                // 228
                                                                                                                  // 229
  var controller = Deps.nonreactive(function () {                                                                 // 230
    return self.getController();                                                                                  // 231
  });                                                                                                             // 232
                                                                                                                  // 233
  if (controller)                                                                                                 // 234
    DynamicTemplate.registerLookupHost(view, controller);                                                         // 235
                                                                                                                  // 236
  //XXX change to this.constructor.name?                                                                          // 237
  view.name = this.name;                                                                                          // 238
  return view;                                                                                                    // 239
};                                                                                                                // 240
                                                                                                                  // 241
/**                                                                                                               // 242
 * Destroy the dynamic template, also destroying the view if it exists.                                           // 243
 */                                                                                                               // 244
DynamicTemplate.prototype.destroy = function () {                                                                 // 245
  if (this.isCreated) {                                                                                           // 246
    Blaze.remove(this.view);                                                                                      // 247
    this.view = null;                                                                                             // 248
    this.isDestroyed = true;                                                                                      // 249
    this.isCreated = false;                                                                                       // 250
  }                                                                                                               // 251
};                                                                                                                // 252
                                                                                                                  // 253
/**                                                                                                               // 254
 * View lifecycle hooks.                                                                                          // 255
 */                                                                                                               // 256
_.each(['onViewCreated', 'onViewReady', '_onViewRendered', 'onViewDestroyed'], function (hook) {                  // 257
  DynamicTemplate.prototype[hook] = function (cb) {                                                               // 258
    var hooks = this._hooks[hook] = this._hooks[hook] || [];                                                      // 259
    hooks.push(cb);                                                                                               // 260
    return this;                                                                                                  // 261
  };                                                                                                              // 262
});                                                                                                               // 263
                                                                                                                  // 264
DynamicTemplate.prototype._runHooks = function (name, view) {                                                     // 265
  var hooks = this._hooks[name] || [];                                                                            // 266
  var hook;                                                                                                       // 267
                                                                                                                  // 268
  for (var i = 0; i < hooks.length; i++) {                                                                        // 269
    hook = hooks[i];                                                                                              // 270
    // keep the "thisArg" pointing to the view, but make the first parameter to                                   // 271
    // the callback teh dynamic template instance.                                                                // 272
    hook.call(view, this);                                                                                        // 273
  }                                                                                                               // 274
};                                                                                                                // 275
                                                                                                                  // 276
DynamicTemplate.prototype.events = function (eventMap, thisInHandler) {                                           // 277
  var self = this;                                                                                                // 278
                                                                                                                  // 279
  this._detachEvents();                                                                                           // 280
  this._eventThisArg = thisInHandler;                                                                             // 281
                                                                                                                  // 282
  var boundMap = this._eventMap = {};                                                                             // 283
                                                                                                                  // 284
  for (var key in eventMap) {                                                                                     // 285
    boundMap[key] = (function (key, handler) {                                                                    // 286
      return function (e) {                                                                                       // 287
        var data = Blaze.getData(e.currentTarget);                                                                // 288
        if (data == null) data = {};                                                                              // 289
        var tmplInstance = self.view.templateInstance();                                                          // 290
        return handler.call(thisInHandler || this, e, tmplInstance, data);                                        // 291
      }                                                                                                           // 292
    })(key, eventMap[key]);                                                                                       // 293
  }                                                                                                               // 294
                                                                                                                  // 295
  this._attachEvents();                                                                                           // 296
};                                                                                                                // 297
                                                                                                                  // 298
DynamicTemplate.prototype._attachEvents = function () {                                                           // 299
  var self = this;                                                                                                // 300
  var thisArg = self._eventThisArg;                                                                               // 301
  var boundMap = self._eventMap;                                                                                  // 302
  var view = self.view;                                                                                           // 303
  var handles = self._eventHandles;                                                                               // 304
                                                                                                                  // 305
  if (!view)                                                                                                      // 306
    return;                                                                                                       // 307
                                                                                                                  // 308
  var domrange = view._domrange;                                                                                  // 309
                                                                                                                  // 310
  if (!domrange)                                                                                                  // 311
    throw new Error("no domrange");                                                                               // 312
                                                                                                                  // 313
  var attach = function (range, element) {                                                                        // 314
    _.each(boundMap, function (handler, spec) {                                                                   // 315
      var clauses = spec.split(/,\s+/);                                                                           // 316
      // iterate over clauses of spec, e.g. ['click .foo', 'click .bar']                                          // 317
      _.each(clauses, function (clause) {                                                                         // 318
        var parts = clause.split(/\s+/);                                                                          // 319
        if (parts.length === 0)                                                                                   // 320
          return;                                                                                                 // 321
                                                                                                                  // 322
        var newEvents = parts.shift();                                                                            // 323
        var selector = parts.join(' ');                                                                           // 324
        handles.push(Blaze._EventSupport.listen(                                                                  // 325
          element, newEvents, selector,                                                                           // 326
          function (evt) {                                                                                        // 327
            if (! range.containsElement(evt.currentTarget))                                                       // 328
              return null;                                                                                        // 329
            var handlerThis = self._eventThisArg || this;                                                         // 330
            var handlerArgs = arguments;                                                                          // 331
            return Blaze._withCurrentView(view, function () {                                                     // 332
              return handler.apply(handlerThis, handlerArgs);                                                     // 333
            });                                                                                                   // 334
          },                                                                                                      // 335
          range, function (r) {                                                                                   // 336
            return r.parentRange;                                                                                 // 337
          }));                                                                                                    // 338
      });                                                                                                         // 339
    });                                                                                                           // 340
  };                                                                                                              // 341
                                                                                                                  // 342
  if (domrange.attached)                                                                                          // 343
    attach(domrange, domrange.parentElement);                                                                     // 344
  else                                                                                                            // 345
    domrange.onAttached(attach);                                                                                  // 346
};                                                                                                                // 347
                                                                                                                  // 348
DynamicTemplate.prototype._detachEvents = function () {                                                           // 349
  _.each(this._eventHandles, function (h) { h.stop(); });                                                         // 350
  this._eventHandles = [];                                                                                        // 351
};                                                                                                                // 352
                                                                                                                  // 353
var attachEventMaps = function (range, element, eventMap, thisInHandler) {                                        // 354
  _.each(eventMap, function (handler, spec) {                                                                     // 355
    var clauses = spec.split(/,\s+/);                                                                             // 356
    // iterate over clauses of spec, e.g. ['click .foo', 'click .bar']                                            // 357
    _.each(clauses, function (clause) {                                                                           // 358
      var parts = clause.split(/\s+/);                                                                            // 359
      if (parts.length === 0)                                                                                     // 360
        return;                                                                                                   // 361
                                                                                                                  // 362
      var newEvents = parts.shift();                                                                              // 363
      var selector = parts.join(' ');                                                                             // 364
      handles.push(Blaze._EventSupport.listen(                                                                    // 365
        element, newEvents, selector,                                                                             // 366
        function (evt) {                                                                                          // 367
          if (! range.containsElement(evt.currentTarget))                                                         // 368
            return null;                                                                                          // 369
          var handlerThis = thisInHandler || this;                                                                // 370
          var handlerArgs = arguments;                                                                            // 371
          return Blaze._withCurrentView(view, function () {                                                       // 372
            return handler.apply(handlerThis, handlerArgs);                                                       // 373
          });                                                                                                     // 374
        },                                                                                                        // 375
        range, function (r) {                                                                                     // 376
          return r.parentRange;                                                                                   // 377
        }));                                                                                                      // 378
    });                                                                                                           // 379
  });                                                                                                             // 380
};                                                                                                                // 381
                                                                                                                  // 382
/**                                                                                                               // 383
 * Insert the Layout view into the dom.                                                                           // 384
 */                                                                                                               // 385
DynamicTemplate.prototype.insert = function (options) {                                                           // 386
  options = options || {};                                                                                        // 387
                                                                                                                  // 388
  if (this.isInserted)                                                                                            // 389
    return;                                                                                                       // 390
  this.isInserted = true;                                                                                         // 391
                                                                                                                  // 392
  var el = options.el || document.body;                                                                           // 393
  var $el = $(el);                                                                                                // 394
                                                                                                                  // 395
  if ($el.length === 0)                                                                                           // 396
    throw new Error("No element to insert layout into. Is your element defined? Try a Meteor.startup callback."); // 397
                                                                                                                  // 398
  if (!this.view)                                                                                                 // 399
    this.create(options);                                                                                         // 400
                                                                                                                  // 401
  Blaze.render(this.view, $el[0], options.nextNode, options.parentView);                                          // 402
                                                                                                                  // 403
  return this;                                                                                                    // 404
};                                                                                                                // 405
                                                                                                                  // 406
/**                                                                                                               // 407
 * Reactively return the value of the current controller.                                                         // 408
 */                                                                                                               // 409
DynamicTemplate.prototype.getController = function () {                                                           // 410
  return this._controller.get();                                                                                  // 411
};                                                                                                                // 412
                                                                                                                  // 413
/**                                                                                                               // 414
 * Set the reactive value of the controller.                                                                      // 415
 */                                                                                                               // 416
DynamicTemplate.prototype.setController = function (controller) {                                                 // 417
  var didHaveController = !!this._hasController;                                                                  // 418
  this._hasController = (typeof controller !== 'undefined');                                                      // 419
                                                                                                                  // 420
  if (didHaveController !== this._hasController)                                                                  // 421
    this._hasControllerDep.changed();                                                                             // 422
                                                                                                                  // 423
  // this will not invalidate an existing view so this lookup host                                                // 424
  // will only be looked up on subsequent renderings.                                                             // 425
  if (this.view)                                                                                                  // 426
    DynamicTemplate.registerLookupHost(this.view, controller);                                                    // 427
                                                                                                                  // 428
  return this._controller.set(controller);                                                                        // 429
};                                                                                                                // 430
                                                                                                                  // 431
/**                                                                                                               // 432
 * Reactively returns true if the template has a controller and false otherwise.                                  // 433
 */                                                                                                               // 434
DynamicTemplate.prototype.hasController = function () {                                                           // 435
  this._hasControllerDep.depend();                                                                                // 436
  return this._hasController;                                                                                     // 437
};                                                                                                                // 438
                                                                                                                  // 439
/*****************************************************************************/                                   // 440
/* DynamicTemplate Static Methods */                                                                              // 441
/*****************************************************************************/                                   // 442
                                                                                                                  // 443
/**                                                                                                               // 444
 * Get the first parent data context that are not inclusion arguments                                             // 445
 * (see above function). Note: This function can create reactive dependencies.                                    // 446
 */                                                                                                               // 447
DynamicTemplate.getParentDataContext = function (view) {                                                          // 448
  // start off with the parent.                                                                                   // 449
  view = view.parentView;                                                                                         // 450
                                                                                                                  // 451
  while (view) {                                                                                                  // 452
    if (view.name === 'with' && !view.__isTemplateWith)                                                           // 453
      return view.dataVar.get();                                                                                  // 454
    else                                                                                                          // 455
      view = view.parentView;                                                                                     // 456
  }                                                                                                               // 457
                                                                                                                  // 458
  return null;                                                                                                    // 459
};                                                                                                                // 460
                                                                                                                  // 461
                                                                                                                  // 462
/**                                                                                                               // 463
 * Get inclusion arguments, if any, from a view.                                                                  // 464
 *                                                                                                                // 465
 * Uses the __isTemplateWith property set when a parent view is used                                              // 466
 * specificially for a data context with inclusion args.                                                          // 467
 *                                                                                                                // 468
 * Inclusion arguments are arguments provided in a template like this:                                            // 469
 * {{> yield "inclusionArg"}}                                                                                     // 470
 * or                                                                                                             // 471
 * {{> yield region="inclusionArgValue"}}                                                                         // 472
 */                                                                                                               // 473
DynamicTemplate.getInclusionArguments = function (view) {                                                         // 474
  var parent = view && view.parentView;                                                                           // 475
                                                                                                                  // 476
  if (!parent)                                                                                                    // 477
    return null;                                                                                                  // 478
                                                                                                                  // 479
  if (parent.__isTemplateWith)                                                                                    // 480
    return parent.dataVar.get();                                                                                  // 481
                                                                                                                  // 482
  return null;                                                                                                    // 483
};                                                                                                                // 484
                                                                                                                  // 485
/**                                                                                                               // 486
 * Given a view, return a function that can be used to access argument values at                                  // 487
 * the time the view was rendered. There are two key benefits:                                                    // 488
 *                                                                                                                // 489
 * 1. Save the argument data at the time of rendering. When you use lookup(...)                                   // 490
 *    it starts from the current data context which can change.                                                   // 491
 * 2. Defer creating a dependency on inclusion arguments until later.                                             // 492
 *                                                                                                                // 493
 * Example:                                                                                                       // 494
 *                                                                                                                // 495
 *   {{> MyTemplate template="MyTemplate"                                                                         // 496
 *   var args = DynamicTemplate.args(view);                                                                       // 497
 *   var tmplValue = args('template');                                                                            // 498
 *     => "MyTemplate"                                                                                            // 499
 */                                                                                                               // 500
DynamicTemplate.args = function (view) {                                                                          // 501
  return function (key) {                                                                                         // 502
    var data = DynamicTemplate.getInclusionArguments(view);                                                       // 503
                                                                                                                  // 504
    if (data) {                                                                                                   // 505
      if (key)                                                                                                    // 506
        return data[key];                                                                                         // 507
      else                                                                                                        // 508
        return data;                                                                                              // 509
    }                                                                                                             // 510
                                                                                                                  // 511
    return null;                                                                                                  // 512
  };                                                                                                              // 513
};                                                                                                                // 514
                                                                                                                  // 515
/**                                                                                                               // 516
 * Inherit from DynamicTemplate.                                                                                  // 517
 */                                                                                                               // 518
DynamicTemplate.extend = function (props) {                                                                       // 519
  return Iron.utils.extend(this, props);                                                                          // 520
};                                                                                                                // 521
                                                                                                                  // 522
/**                                                                                                               // 523
 * Register a lookupHost for a view. This allows components and controllers                                       // 524
 * to participate in the Blaze.prototype.lookup chain.                                                            // 525
 */                                                                                                               // 526
DynamicTemplate.registerLookupHost = function (target, host) {                                                    // 527
  assert(typeof target == 'object', 'registerLookupHost requires the target to be an object');                    // 528
  assert(typeof host == 'object', 'registerLookupHost requires the host to be an object');                        // 529
  target.__lookupHost__ = host;                                                                                   // 530
};                                                                                                                // 531
                                                                                                                  // 532
/**                                                                                                               // 533
 * Returns true if the target is a lookup host and false otherwise.                                               // 534
 */                                                                                                               // 535
DynamicTemplate.isLookupHost = function (target) {                                                                // 536
  return !!(target && target.__lookupHost__);                                                                     // 537
};                                                                                                                // 538
                                                                                                                  // 539
/*                                                                                                                // 540
 * Returns the lookup host for the target or undefined if it doesn't exist.                                       // 541
 */                                                                                                               // 542
DynamicTemplate.getLookupHost = function (target) {                                                               // 543
  return target && target.__lookupHost__;                                                                         // 544
};                                                                                                                // 545
                                                                                                                  // 546
/*****************************************************************************/                                   // 547
/* UI Helpers */                                                                                                  // 548
/*****************************************************************************/                                   // 549
                                                                                                                  // 550
if (typeof Template !== 'undefined') {                                                                            // 551
  UI.registerHelper('DynamicTemplate', new Template('DynamicTemplateHelper', function () {                        // 552
    var args = DynamicTemplate.args(this);                                                                        // 553
                                                                                                                  // 554
    return new DynamicTemplate({                                                                                  // 555
      data: function () { return args('data'); },                                                                 // 556
      template: function () { return args('template'); },                                                         // 557
      content: this.templateContentBlock                                                                          // 558
    }).create();                                                                                                  // 559
  }));                                                                                                            // 560
                                                                                                                  // 561
  /**                                                                                                             // 562
   * Find a lookup host with a state key and return it reactively if we have                                      // 563
   * it.                                                                                                          // 564
   */                                                                                                             // 565
  UI.registerHelper('get', function (key) {                                                                       // 566
    var view = Blaze.getView();                                                                                   // 567
    var host;                                                                                                     // 568
                                                                                                                  // 569
    while (view) {                                                                                                // 570
      if (host = DynamicTemplate.getLookupHost(view)) {                                                           // 571
        return host.state && host.state.get(key);                                                                 // 572
      } else {                                                                                                    // 573
        view = view.parentView;                                                                                   // 574
      }                                                                                                           // 575
    }                                                                                                             // 576
                                                                                                                  // 577
    return undefined;                                                                                             // 578
  });                                                                                                             // 579
}                                                                                                                 // 580
                                                                                                                  // 581
/*****************************************************************************/                                   // 582
/* Namespacing */                                                                                                 // 583
/*****************************************************************************/                                   // 584
Iron.DynamicTemplate = DynamicTemplate;                                                                           // 585
                                                                                                                  // 586
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/iron:dynamic-template/blaze_overrides.js                                                              //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/*****************************************************************************/                                   // 1
/* Imports */                                                                                                     // 2
/*****************************************************************************/                                   // 3
var assert = Iron.utils.assert;                                                                                   // 4
                                                                                                                  // 5
/*****************************************************************************/                                   // 6
/* Private */                                                                                                     // 7
/*****************************************************************************/                                   // 8
findFirstLookupHostWithProperty = function (view, prop) {                                                         // 9
  assert(view instanceof Blaze.View, "view must be a Blaze.View");                                                // 10
                                                                                                                  // 11
  var host;                                                                                                       // 12
                                                                                                                  // 13
  while (view) {                                                                                                  // 14
    if ((host = DynamicTemplate.getLookupHost(view)) && host[prop])                                               // 15
      return host;                                                                                                // 16
    else                                                                                                          // 17
      view = view.parentView;                                                                                     // 18
  }                                                                                                               // 19
                                                                                                                  // 20
  return undefined;                                                                                               // 21
};                                                                                                                // 22
                                                                                                                  // 23
/*****************************************************************************/                                   // 24
/* Blaze Overrides */                                                                                             // 25
/*****************************************************************************/                                   // 26
/**                                                                                                               // 27
 * Adds ability to inject lookup hosts into views that can participate in                                         // 28
 * property lookup. For example, iron:controller or iron:component could make                                     // 29
 * use of this to add methods into the lookup chain. If the property is found,                                    // 30
 * a function is returned that either returns the property value or the result                                    // 31
 * of calling the function (bound to the __lookupHost__).                                                         // 32
 */                                                                                                               // 33
var origLookup = Blaze.View.prototype.lookup;                                                                     // 34
Blaze.View.prototype.lookup = function (name /*, args */) {                                                       // 35
  var lookupHost = findFirstLookupHostWithProperty(Blaze.getView(), name);                                        // 36
  if (lookupHost) {                                                                                               // 37
    return function callLookupHostProperty (/* args */) {                                                         // 38
      var val = lookupHost[name];                                                                                 // 39
      var args = [].slice.call(arguments);                                                                        // 40
      return (typeof val === 'function') ? val.apply(lookupHost, args) : val;                                     // 41
    }                                                                                                             // 42
  } else {                                                                                                        // 43
    return origLookup.apply(this, arguments);                                                                     // 44
  }                                                                                                               // 45
};                                                                                                                // 46
                                                                                                                  // 47
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['iron:dynamic-template'] = {};

})();

//# sourceMappingURL=iron_dynamic-template.js.map
