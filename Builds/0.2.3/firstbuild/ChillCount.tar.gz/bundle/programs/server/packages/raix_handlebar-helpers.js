(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var Helpers;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['raix:handlebar-helpers'] = {
  Helpers: Helpers
};

})();

//# sourceMappingURL=raix_handlebar-helpers.js.map
