(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['richsilv:semantic-ui-sass'] = {};

})();

//# sourceMappingURL=richsilv_semantic-ui-sass.js.map
