(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mrt:accounts-ui-bootstrap-3'] = {};

})();

//# sourceMappingURL=mrt_accounts-ui-bootstrap-3.js.map
